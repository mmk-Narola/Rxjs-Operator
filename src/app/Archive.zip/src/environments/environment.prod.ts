export const environment = {
  production: true,
  APIEndpoint: 'http://175.41.182.101:5000/api/v1/'
};
