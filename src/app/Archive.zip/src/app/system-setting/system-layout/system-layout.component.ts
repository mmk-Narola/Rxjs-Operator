import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-layout',
  templateUrl: './system-layout.component.html',
  styleUrls: ['./system-layout.component.scss']
})
export class SystemLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
