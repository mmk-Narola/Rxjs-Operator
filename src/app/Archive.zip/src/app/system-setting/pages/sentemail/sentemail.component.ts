import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SystemSettingsService } from '../../../shared/services/systemSetting/system-settings.service';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { takeUntil, startWith, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { UtilityService } from '../../../shared/utility/utility.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-sentemail',
  templateUrl: './sentemail.component.html',
  styleUrls: ['./sentemail.component.scss']
})
export class SentemailComponent implements OnInit {
  @ViewChild(Table) primeNGTable: Table;
  emailsList: any[];
  private _unsubscribe = new Subject<boolean>();
  page: number = 0;
  totalCount: any;
  action: any;
  searchTerms$ = new Subject<string>();
  countries: any[];
  countryId: number = null;

  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private SystemSettingsService: SystemSettingsService,
    private commonService: CommonServiceService,
    private confirmationService: ConfirmationService,
  ) { }

  ngOnInit() {
    this.initiateSearch();
    this.getCountry();
  }

  onAddemail() {
    this.router.navigate(['../new-email'], { relativeTo: this.activateRoute })
  }

  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      switchMap((term: string) => this.SystemSettingsService.getAllEmailSearch(this.page, term
      ))
    ).subscribe((success: any) => {
      this.emailsList = success.data.results;
      this.totalCount = success.data.total;
      this.utilityService.resetPage();
    })
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {

      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          console.log("entered");
          this.SystemSettingsService.deleteEmail(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {

              this.getAllEmail(this.page);
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });
    }

    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../edit-email', id], { relativeTo: this.activateRoute })
    }
  }

  getAllEmail(page) {
    this.SystemSettingsService.getAllEmail(page).subscribe(
      (success: any) => {
        this.emailsList = success.data.results;

        this.totalCount = success.data.total;
      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }

  getAllEmailSearch(page, countryId) {
    this.SystemSettingsService.getAllEmailSearch(page, countryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        this.emailsList = success.data.results;
        this.totalCount = success.data.total;
        this.utilityService.resetPage();
      })
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  onChange(deviceValue) {
    if (deviceValue) {
      this.countryId = deviceValue;
    }
    else {
    }

    this.getAllEmailSearch(this.page, this.countryId);
  }
}
