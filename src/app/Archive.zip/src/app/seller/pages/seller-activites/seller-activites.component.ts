import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-activites',
  templateUrl: './seller-activites.component.html',
  styleUrls: ['./seller-activites.component.scss']
})
export class SellerActivitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
