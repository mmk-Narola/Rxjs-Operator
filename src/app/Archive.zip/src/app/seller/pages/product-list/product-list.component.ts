import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UtilityService } from '../../../shared/utility/utility.service';
import { SellerService } from '../../../shared/services/Sellers/seller.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';

interface Country {
  _id: string,
  country: string
}
interface seller {
  _id: string,
  seller: string
}

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  productList: any;
  page: number = null;
  private _unsubscribe = new Subject<boolean>();
  countryId: number = null;
  sellerId: number = null;
  countryValue: any = null;
  sellerValue: any = null;
  statusValue: any = null;
  countries: Country[];
  sellerList: any[];
  approveStatus: any = null
  approvedStatusList: string[];
  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private sellerService: SellerService,
    public utilityService: UtilityService,
    public commonService: CommonServiceService
  ) { }

  ngOnInit() {
    this.getCountry();
    this.getSeller();
    this.approvedStatusList = ['Approved', 'Pending', 'Rejected']
    this.getAllproductListSearch(null, null, null, null)
  }

  getAllProductsList() {
    this.sellerService.getProductList().subscribe(
      (success: any) => {
        this.productList = success.data.results;
      },
      error => {
        this.productList.resetPage();
      }
    );
  }

  getDropDownValueList(event, id) {
    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../edit-product-list', id], { relativeTo: this.activateRoute })
    }
  }

  onChange(deviceValue) {
    if (deviceValue) {
      this.countryId = deviceValue;
      this.router.navigate(['seller/product-list'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, statusId: this.approveStatus } })
    }
    else {
    }
    this.getAllproductListSearch(this.page, this.countryValue, this.sellerValue, this.approveStatus);
  }

  onChangeseller(deviceValue) {
    console.log(deviceValue);
    if (deviceValue) {
      this.sellerId = deviceValue;
      this.router.navigate(['seller/product-list'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, statusId: this.approveStatus } })
    }
    else {
    }
    this.getAllproductListSearch(this.page, this.countryValue, this.sellerValue, this.approveStatus);
  }

  onChangestatus(deviceValue) {
    console.log(deviceValue);
    if (deviceValue) {
      this.approveStatus = deviceValue;
      this.router.navigate(['seller/product-list'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, statusId: this.approveStatus } })
    }
    else {
    }
    this.getAllproductListSearch(this.page, this.countryValue, this.sellerValue, this.approveStatus);
  }

  getAllproductListSearch(page, countryId, sellerId, statusId) {
    this.sellerService.getAllproductListSearch(page, countryId, sellerId, statusId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        this.productList = success.data.results;
        this.utilityService.resetPage();
      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  getSeller() {
    this.commonService.getSeller().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.sellerList = success.data;
      },
      error => {
      }
    )
  }
}
