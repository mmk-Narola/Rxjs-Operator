import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SellerRoutingModule } from './seller-routing.module';

import { SellerLayoutComponent } from './seller-layout/seller-layout.component';
import { SellerListingComponent } from './pages/seller-listing/seller-listing.component';
import { SellerActivitesComponent } from './pages/seller-activites/seller-activites.component';
import { SellerPayoutComponent } from './pages/seller-payout/seller-payout.component';
import { AddSellerComponent } from './pages/seller-listing/add-seller/add-seller.component';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { UpdateProductListComponent } from './pages/product-list/update-product-list/update-product-list.component';
import { SharedModule } from '../shared/shared.module';
import { CKEditorModule } from 'ckeditor4-angular';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { TagInputModule } from 'ngx-chips';
import { ButtonModule } from 'primeng/button';
import { FileUploadModule } from 'ng2-file-upload';
import { MultiSelectModule } from 'primeng/multiselect';
import { RequiredIfDirective } from './pages/product-list/update-product-list/required-if.directive';

@NgModule({
  imports: [
    CommonModule,
    SellerRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
    AngularMultiSelectModule,
    NgxDatatableModule,
    TableModule,
    DropdownModule,
    TagInputModule,
    ButtonModule,
    FileUploadModule,
    MultiSelectModule
  ],
  declarations: [SellerLayoutComponent, SellerListingComponent, SellerActivitesComponent, SellerPayoutComponent, AddSellerComponent, ProductListComponent, UpdateProductListComponent, RequiredIfDirective]
})
export class SellerModule { }
