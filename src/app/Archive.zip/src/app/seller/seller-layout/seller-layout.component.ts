import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-layout',
  templateUrl: './seller-layout.component.html',
  styleUrls: ['./seller-layout.component.scss']
})
export class SellerLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
