import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skill-layout',
  templateUrl: './skill-layout.component.html',
  styleUrls: ['./skill-layout.component.scss']
})
export class SkillLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
