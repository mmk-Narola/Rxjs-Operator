import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilityService } from '../../../shared/utility/utility.service';
import { ConfirmationService, LazyLoadEvent } from 'primeng/api';
import { takeUntil, startWith, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ManufactureService } from '../../../shared/services/catalogue/manufacture.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { ToastrService } from 'ngx-toastr';


interface Action {
  name: string,
  code: string
}
@Component({
  selector: 'app-parent-category',
  templateUrl: './parent-category.component.html',
  styleUrls: ['./parent-category.component.scss']
})
export class ParentCategoryComponent implements OnInit {
  page: number = null;
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;
  supplyList: any[];
  totalCount: any;
  searchTerms$ = new Subject<string>();
  searchBar: any = "";
  private _unsubscribe = new Subject<boolean>();
  action: any;
  countries: any[];
  countryId: number = null;
  categoriesList: any;
  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private manufactureService: ManufactureService,
    private commonService: CommonServiceService,
    private confirmationService: ConfirmationService,
    private toastr: ToastrService,
  ) { }

  setStatus(id: Number, adminStatus: Number) {

    let statusData = { id, adminStatus }

    this.manufactureService.updateparentCategoryStatus(statusData).subscribe(
      (success: any) => {

        this.ngOnInit()
      })
  }
  ngOnInit() {
    this.initiateSearch();
    this.getCountry();
  }
  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      // switch to new search observable each time the term changes
      switchMap((term: string) => this.manufactureService.getAllParentCategorysSearch(this.page, term, this.countryId
      ))
    ).subscribe((success: any) => {
      this.categoriesList = success.data.results;
      this.totalCount = success.data.total;
      this.utilityService.resetPage();
    })
  }

  filterGlobal(searchTerm) {
    // indexing starts from 0 in primeng
    this.primeNGTable.first = 0;
    this.page = 0;
    this.searchTerms$.next(searchTerm);
  }
  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
        this.toastr.error(error.error.message);

      }
    )
  }
  getAllParentCategory(page) {

    this.manufactureService.getAllParentCategory(page).subscribe(
      (success: any) => {
        this.categoriesList = success.data.results;
        this.totalCount = success.data.total;
      },
      error => {
        this.toastr.error(error.error.message);

        this.utilityService.resetPage();
      }
    );
  }
  getAllParentCategorysSearch(page, searchBar, countryId) {

    this.manufactureService.getAllParentCategorysSearch(page, searchBar, countryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        this.categoriesList = success.data.results;
        this.totalCount = success.data.total;
        this.utilityService.resetPage();
      })
  }
  getDropDownValue(event, id) {

    if (event.currentTarget.firstChild.data === 'Delete') {

      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.manufactureService.deleteParentCategory(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.getAllParentCategory(this.page);
            },
            error => {
              this.toastr.error(error.error.message);

            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });

    }
    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../edit-parent-category', id], { relativeTo: this.activateRoute })
    }
  }

  onChange(deviceValue) {
    if (deviceValue) {

      this.countryId = deviceValue;
    }
    this.getAllParentCategorysSearch(this.page, this.searchBar, this.countryId);
  }
  onAddParentCategories() {
    this.router.navigate(['../new-parent-categories'], { relativeTo: this.activateRoute })
  }
}
