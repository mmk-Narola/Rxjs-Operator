import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryOriginComponent } from './country-origin.component';

describe('CountryOriginComponent', () => {
  let component: CountryOriginComponent;
  let fixture: ComponentFixture<CountryOriginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountryOriginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryOriginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
