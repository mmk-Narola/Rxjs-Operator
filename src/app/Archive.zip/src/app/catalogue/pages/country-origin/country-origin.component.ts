import { Component, OnInit } from '@angular/core';
import { CountryOriginService } from '../../../shared/services/catalogue/country-origin.service';
import { UtilityService } from '../../../shared/utility/utility.service';
import { ConfirmationService } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-country-origin',
  templateUrl: './country-origin.component.html',
  styleUrls: ['./country-origin.component.scss']
})
export class CountryOriginComponent implements OnInit {
  countryOriginList: any[];
  private _unsubscribe = new Subject<boolean>();
  action: any;
  countryDetailsData: any
  countryName: any;
  page: number = null;
  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private countryOriginService: CountryOriginService,
    private utilityService: UtilityService,
    private confirmationService: ConfirmationService
  ) { }

  ngOnInit() {
    this.getAllCountryOrigins(this.page)
    this.countryOriginService.getCountryInfo();
  }
  setStatus(id: Number, adminStatus: Number, countryName: any) {
    countryName = this.countryOriginService.countryIdMap.get(id)
    let statusData = { id, adminStatus, countryName }
    this.countryOriginService.updateCountryStatus(statusData).subscribe(
      (success: any) => {
        this.ngOnInit()
      })
  }

  getAllCountryOrigins(page) {
    this.countryOriginService.getAllCountryOrigins(this.page).subscribe(
      (success: any) => {

        this.countryOriginList = success.data.results;
      },
      error => {

        this.utilityService.resetPage();
      }
    );
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {

      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.countryOriginService.deleteCountryOrigin(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.getAllCountryOrigins(this.page);
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });

    }
    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['/catalogues/edit-country-origin', id], { relativeTo: this.activateRoute })
    }
  }
}
