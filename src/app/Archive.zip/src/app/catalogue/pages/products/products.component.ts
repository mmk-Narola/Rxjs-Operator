import { Component, OnInit, ViewChild } from '@angular/core';
import { Validators, FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgbTabsetConfig } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UtilityService } from '../../../shared/utility/utility.service';
import { CategoryService } from '../../../shared/services/catalogue/category.service';
import { ProductService } from '../../../shared/services/catalogue/product.service';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { takeUntil, startWith, debounceTime, distinctUntilChanged, switchMap, timeout } from 'rxjs/operators';
import { LazyLoadEvent, ConfirmationService } from 'primeng/api';
import { ExcelServiceService } from '../../../shared/services/excel-service.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { NgbModal, ModalDismissReasons, NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import * as XLSX from 'xlsx';
import Swal from 'sweetalert2/dist/sweetalert2.js';

interface Country {
  _id: string,
  country: string
}
interface seller {
  _id: string,
  seller: string
}
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
  animations: [
    trigger('rowExpansionTrigger', [
      state('void', style({
        transform: 'translateX(-10%)',
        opacity: 0
      })),
      state('active', style({
        transform: 'translateX(0)',
        opacity: 1
      })),
      transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
  ],
  providers: [NgbTabsetConfig, NgbAccordionConfig]
})

export class ProductsComponent implements OnInit {

  productTitle: string;
  addProductForm: FormGroup;
  VariantForm: FormGroup;
  isSubmittedaddProductForm: boolean = false;
  productValue: any;
  // private _unsubscribe = new Subject<boolean>();
  titles: string[];
  editMode = false;
  id: number;
  addProductFormDetails: any;
  product: any;
  variantDetails: any;
  countries: Country[];
  sellerList: any[];
  CategoryListdata: any[];
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;

  // Real time search
  searchTerms$ = new Subject<string>();
  searchBar: any = "";
  private _unsubscribe = new Subject<boolean>();
  page: number = null;
  totalCount: any;
  productList: any;
  exportData: any[];
  exportAll = "false";
  countryId: number = null;
  sellerId: number = null;
  categoryId: number = null;
  exportAllData: any[];
  productListExport: any;
  action: any;
  variantlist: any;
  providers: any;
  closeResult: string;
  display: boolean = false;
  VariantData: any;
  willDownload = false;
  variants: any;
  valueList: any;
  adminStatus: string;
  list: any;
  countryValue: any = null;
  categoryValue: any = null;
  sellerValue: any = null;
  currentFilter: any;
  Dataid: any;
  productExportData: any;
  isReadOnly = true;
  fileName: any;
  datastring: any;
  file: any
  hideProductButton: boolean = false

  constructor(config: NgbTabsetConfig, private router: Router,
    private activateRoute: ActivatedRoute,
    public utilityService: UtilityService,
    private categoryService: CategoryService,
    private ProductService: ProductService,
    private modalService: NgbModal,
    private toastr: ToastrService,
    private confirmationService: ConfirmationService,
    private commonService: CommonServiceService,
    private excelService: ExcelServiceService,) {
    // customize default values of tabsets used by this component tree
    // config.justify = 'center';
    config.type = 'pills';
  }
  setStatus(id: Number, adminStatus: Number) {

    let statusData = { id, adminStatus }

    this.ProductService.updateproductStatus(statusData).subscribe(
      (success: any) => {

        this.ngOnInit()
      })
  }
  setStatusVariant(id: Number, adminStatus: Number) {

    let statusData = { id, adminStatus }

    this.ProductService.updateVariant(statusData).subscribe(
      (success: any) => {

        this.ngOnInit()
      })
  }
  ngOnInit() {
    this.currentFilter = window.location.search;
    // this.activateRoute.queryParams.subscribe(response =>{
    //   if(response.countryId){
    //     this.countryValue= response.countryId;
    //   }
    //   if(response.categoryId){
    //     this.categoryValue= response.categoryId;
    //   }
    //   if(response.sellerId){
    //     this.sellerValue= response.sellerId;
    //   }
    // })   
    this.VariantForm = new FormGroup({
      "variant": new FormControl(null, Validators.required),
      "quantity": new FormControl(null, Validators.required),
      "sellPrice": new FormControl(null, Validators.required),
      "sellerFee": new FormControl(null, Validators.required),
      "MRP": new FormControl(null, Validators.required),
      "walletPrice": new FormControl(null),
    });
    this.exportData = [];
    this.exportAllData = [];
    this.initiateSearch();
    this.getCountry();
    this.getSeller();
    this.getCategoryList();
  }


  onVariantFormSubmit() {
    console.log(this.VariantForm.value);
    let data = {
      id: this.id,
      productName: this.VariantForm.controls.variant.value,
      sellPrice: this.VariantForm.controls.sellPrice.value,
      walletPrice: this.VariantForm.controls.walletPrice.value,
      MRP: this.VariantForm.controls.MRP.value,
      "sellerProducts": [{
        id: this.Dataid,
        productName: this.VariantForm.controls.variant.value,
        quantity: this.VariantForm.controls.quantity.value
        // sellerFee: this.VariantForm.controls.sellerFee.value,
      }],
    }
    if (this.VariantForm.controls.MRP.value != 0) {
      this.ProductService.updateVariant(data).pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.toastr.success('Variant Updated Successfully!');
          this.router.navigate(['/catalogues/products']);
          this.display = false;
          this.getAllproduct(this.page);
        },
        error => {
          this.toastr.error(error.error.message);
        }
      )
    }
    else {
      this.toastr.error("Price can not be 0");
    }
  }
  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      // switch to new search observable each time the term changes
      switchMap((term: string) => this.ProductService.getAllproductSearch(this.page, term, this.exportAll, this.countryValue, this.sellerValue, this.categoryValue
      ))
    ).subscribe((success: any) => {
      this.productList = success.data.results;
      this.totalCount = success.data.total;
      this.utilityService.resetPage();
    })
  }
  getAllproductSearch(page, searchBar, exportAll, countryId, sellerId, categoryId) {
    this.ProductService.getAllproductSearch(page, searchBar, exportAll, countryId, sellerId, categoryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {

        if (exportAll == "true") {
          this.productListExport = [];

          this.productListExport = success.data.results;
          var i = this.productListExport.length;
          this.productListExport.forEach((element, index) => {
            console.log(element);
            console.log(index);
            if (element.adminStatus == '1') {
              this.adminStatus = "Active";
            }
            else {
              this.adminStatus = "Inactive";
            }

            if (element.manufactureDetail == null)
              element.manufactureDetail = {
                manufacturerName: "",
                id: ""
              }

            if (element.sellerDetail == null)
              element.sellerDetail = {
                sellerName: "",
                id: ""
              }

            this.exportAllData.push({
              Tag: "product",
              S_No: index,
              ProductCode: element.PNCDE != null ? element.PNCDE : element.PNCDE = "",
              ProductId: element.id != null ? element.id : element.id = "",
              Product_Name: element.productName != null ? element.productName : element.productName = "",
              price: element.MRP != null ? element.MRP : element.MRP = "",
              Brand_name: element.manufactureDetail.manufacturerName,
              Seller: element.sellerDetail.sellerName,
              Is_Variant: element.isPackage != null ? element.isPackage : element.isPackage = "",
              Admin_Status: this.adminStatus != null ? element.adminStatus : element.adminStatus = "",
            })
            console.log(element.productVariants)
            this.variantlist = element.productVariants;
            console.log(this.variantlist);
            for (var j = 0; j < this.variantlist.length; j++) {
              console.log(this.variantlist[j])
              if (element.id == this.variantlist[j].productId) {
                console.log(this.variantlist[j].productId);
                this.exportAllData.push({
                  Tag: "variant",
                  // ProductID:this.variantlist[j].productId,
                  varainID: this.variantlist[j].id,
                  varaintName: this.variantlist[j].variant,
                  Stock: this.variantlist[j].quantity,
                  variant_price: this.variantlist[j].MRP,
                  Variant_Refrence: this.variantlist[j].isQuote
                })

              }

            }
          })
          this.excelService.exportAsExcelFile(this.exportAllData, 'Product List')
          this.exportAll = "false"
          this.exportAllData = [];
        }
        else {

          this.productList = success.data.results;
          this.totalCount = success.data.total;
          this.utilityService.resetPage();
        }
      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }
  getAllproduct(page) {
    var data = [];
    this.ProductService.getAllproduct(page).subscribe(
      (success: any) => {
        console.log(success);
        this.productList = success.data.results;
        console.log(this.productList);
      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }
  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {

      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.ProductService.deleteProduct(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.getAllproduct(this.page);
              this.productList = this.productList.filter((item: any) => {
                return id !== item.countryId
              })
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });
    }
    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../edit-product', id], { relativeTo: this.activateRoute })
    }
  }

  loadDataLazy(event: LazyLoadEvent) {

    this.page = event.first / 10;

    //if there is a search term present in the search bar, then paginate with the search term
    if (!this.searchBar && !this.countryId) {

      this.getAllproduct(this.page);
    }
    else if (!this.countryId) {

      this.getAllproduct(this.page);
    }
    else {
      this.getAllproductSearch(this.page, this.searchBar, this.exportAll, this.countryValue, this.sellerValue, this.categoryValue);
    }
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }
  getSeller() {
    this.commonService.getSeller().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.sellerList = success.data;
      },
      error => {
      }
    )
  }
  getCategoryList() {
    this.commonService.getCategoryList().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.CategoryListdata = success.data;
      },
      error => {
      }
    )
  }
  onChange(deviceValue) {
    if (deviceValue) {
      this.countryId = deviceValue;
      this.router.navigate(['catalogues/products/'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, categoryId: this.categoryId } })
    }
    else {
    }

    this.getAllproductSearch(this.page, this.searchBar, this.exportAll, this.countryValue, this.sellerValue, this.categoryValue);
  }
  onChangeseller(deviceValue) {
    console.log(deviceValue);
    if (deviceValue) {
      this.sellerId = deviceValue;
      this.router.navigate(['catalogues/products/'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, categoryId: this.categoryId } })
    }
    else {
    }

    this.getAllproductSearch(this.page, this.searchBar, this.exportAll, this.countryValue, this.sellerValue, this.categoryValue);

  }
  onChangecategory(deviceValue) {
    if (deviceValue) {
      this.categoryId = deviceValue;
      this.router.navigate(['catalogues/products/'], { queryParams: { sellerId: this.sellerId, countryId: this.countryId, categoryId: this.categoryId } })
    }
    else {
    }
    this.getAllproductSearch(this.page, this.searchBar, this.exportAll, this.countryValue, this.sellerValue, this.categoryValue);
  }
  filterGlobal(searchTerm) {
    this.primeNGTable.first = 0;
    this.searchTerms$.next(searchTerm);
  }

  exportAsXLSX() {
    this.ProductService.getProductListForExport(this.countryId, this.sellerId, this.categoryId, null).pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.productExportData = success.data.results;
        this.productExportData.forEach((element, index) => {
          element.is_variant == 0 ? element.is_variant = "false" : element.is_variant = "true"
          element.Admin_Status == 1 ? element.Admin_Status = "Active" : element.Admin_Status = "Inactive"
          this.exportData.push({
            S_No: index,
            ProductCode: element.ProductCode != null ? element.ProductCode : element.ProductCode = "",
            ProductId: element.ProductId != null ? element.ProductId : element.ProductId = "",
            Product_Name: element.productName != null ? element.productName : element.productName = "",
            price: element.price != null ? element.price : element.price = "",
            Brand_name: element.brand != null ? element.brand : element.brand = "",
            Is_Variant: element.is_variant != null ? element.is_variant : element.is_variant = "",
            Admin_Status: element.Admin_Status != null ? element.Admin_Status : element.Admin_Status = "",
          })
        })
        this.excelService.exportAsExcelFile(this.exportData, 'Product List')
        this.exportData = [];
      },
      error => {
      }
    )

    // this.exportAll = "true"
    // this.getAllproductSearch(this.page, this.searchBar, this.exportAll, this.countryId, this.sellerId, this.categoryId);

  }
  exportAsXLSXMacro() {
    //  this.excelService.exportAsExcelFile(this.exportData, 'Bulk_Upload_file_Toolv1')
  }

  getDropDownvariantValue1(event, id) {
    this.id = id;
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        console.log(id);
        this.ProductService.deletevariant(id).pipe(takeUntil(this._unsubscribe)).subscribe(
          (success: any) => {
            console.log(success);
            this.getAllproduct(this.page);
            this.productList = this.productList.filter((item: any) => {
              console.log(this.productList);
              return id !== item.countryId
            })
          },
          error => {
          }
        )
      },
      reject: () => {
        this.action = null;
      }
    });
  }

  getDropDownvariantValue2(event, id) {
    this.id = id;
    console.log(event);
    console.log(id);
    this.ProductService.getvariantDetails(id).pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        console.log(success);
        this.VariantData = success.data;
        console.log(this.VariantData);
        this.Dataid = this.VariantData.sellerProducts[0].id;
        this.patchForm(this.VariantData);
        this.display = true;
      },
      error => {
        this.toastr.error(error.error.message)
      }
    )
  }

  patchForm(item) {
    console.log(item);
    this.VariantForm.controls.variant.patchValue(item.productName);
    this.VariantForm.controls.quantity.patchValue(item.sellerProducts[0].quantity);
    this.VariantForm.controls.sellPrice.patchValue(item.sellPrice);
    this.VariantForm.controls.MRP.patchValue(item.MRP);
    this.VariantForm.controls.walletPrice.patchValue(item.walletPrice);
  }

  open(content) {
    this.fileName = ''
    this.modalService
      .open(content, { ariaLabelledBy: "modal-basic-title", backdrop: 'static', keyboard: false })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;

        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  fileProgress(ev) {
    this.file = ev.target.files[0];
    this.fileName = this.file.name;
    this.convertData();
  }

  convertData() {
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();

    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      console.log(jsonData);
      const dataString = JSON.stringify(jsonData);
      this.datastring = dataString;
      console.log(dataString)
    }
    reader.readAsBinaryString(this.file);
  }

  bulkUpdate() {
    this.ProductService.bulkUpdate(this.datastring).pipe(takeUntil(this._unsubscribe)).subscribe(
      (response) => {
        console.log(response);
        this.toastr.success('File Upload Successfully!');
      },
      error => {
        console.log(error);
        this.toastr.error('File not uploaded!');
      }
    )
  }

  syncAlgolia() {
    Swal.fire({
      title: 'Are you sure?',
      type: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.ProductService.syncAlgolia().subscribe(
          (success) => {
            this.toastr.info("Products have successfully synced to Algolia!")
          },
          (error) => {
          }
        )
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        return;
      }
    })
    return true;
  }
}
