import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalogue-layout',
  templateUrl: './catalogue-layout.component.html',
  styleUrls: ['./catalogue-layout.component.scss']
})
export class CatalogueLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
