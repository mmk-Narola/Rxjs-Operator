export class CountryModel {
    id:any
    itemName:any
}