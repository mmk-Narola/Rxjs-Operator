export class Home{
    productName:any;
    productId:any;
    sellerId:any;
    sellerid:any;
    sellerName:any;
    price:any;
    MRP:any;
    quantity:any;
    total:any;
    lotNumber:any;
    expiryDate:any;
    orderProductStatus:any;
    discount:any;
    pncode:any;
    sellerfee:any;
   
}







