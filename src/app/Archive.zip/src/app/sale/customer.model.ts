export class CutomerModel {
    Email:any
    customerId:any
    customerName:any
    mobileNumber:any
    firstName:any
    clinicName:any
    title:any
    lastName:any
    customerAddress:any
}