import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SaleRoutingModule } from './sale-routing.module';
import { SaleLayoutComponent } from '../sale/sale-layout/sale-layout.component';
import { QuotationComponent } from './pages/quotation/quotation.component';
import { SharedModule } from '../../app/shared/shared.module';
import { AddQuotationComponent } from './pages/add-quotation/add-quotation.component';
import { InprogressComponent } from './pages/inprogress/inprogress.component';
import { CompletedComponent } from './pages/completed/completed.component';
import { RejectedComponent } from './pages/rejected/rejected.component';
import { CKEditorModule } from 'ckeditor4-angular';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';

import { FileUploadModule } from 'ng2-file-upload';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TableModule } from 'primeng/table';
import {DropdownModule} from 'primeng/dropdown';
import {ButtonModule} from 'primeng/button';
import { AddRowDirective } from './pages/add-quotation/add-row.directive';
import { RequiredIfDirective } from './pages/add-quotation/required-if.directive';
import { TagInputModule } from 'ngx-chips';
import {OrderLayoutComponent} from './order-layout/order-layout.component';
import { OrdersComponent } from './pages/orders/orders.component';
import {SearchfilterPipe} from '../shared/pipes/searchfilter.pipe';
import { AddEditOrdersComponent } from './components/add-edit-orders/add-edit-orders.component';
import {Resolver} from '../shared/resolver/resolver';
import {PaysectionComponent} from './components/paysection/paysection.component';
import { PrintQuotationComponent } from './pages/print-quotation/print-quotation.component';
import {NgxPrintModule} from 'ngx-print';
import { SellerProductInfoComponent } from './components/seller-product-info/seller-product-info.component';
import { ModAddEditOrdersComponent } from './components/mod-add-edit-orders/mod-add-edit-orders.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AbandonedCartsComponent } from './components/abandoned-carts/abandoned-carts.component';
import { ViewAbandonedCartsComponent } from './pages/view-abandoned-carts/view-abandoned-carts.component';
import { ViewUserRequestComponent } from './pages/view-user-request/view-user-request.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    SaleRoutingModule,
    SelectDropDownModule,
    NgxPrintModule,
    CKEditorModule,
    AngularMultiSelectModule,
    NgxDatatableModule,
    TableModule,
    DropdownModule,
    TagInputModule,
    ButtonModule,
    FileUploadModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  providers:[Resolver],
  declarations: [OrderLayoutComponent, OrdersComponent, AddEditOrdersComponent,
    SaleLayoutComponent,PaysectionComponent,
    SaleLayoutComponent,QuotationComponent,RequiredIfDirective, AddRowDirective,AddQuotationComponent, InprogressComponent, CompletedComponent, RejectedComponent
    ,SearchfilterPipe, PrintQuotationComponent, SellerProductInfoComponent, ModAddEditOrdersComponent, AbandonedCartsComponent, ViewAbandonedCartsComponent, ViewUserRequestComponent,]
})
export class SaleModule { }
