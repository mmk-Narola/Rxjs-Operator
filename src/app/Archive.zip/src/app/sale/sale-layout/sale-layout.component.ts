import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-layout',
  templateUrl: './sale-layout.component.html',
  styleUrls: ['./sale-layout.component.scss']
})
export class SaleLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
