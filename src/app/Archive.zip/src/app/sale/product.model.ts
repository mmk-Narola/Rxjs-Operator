export class product{
    
    productnames:any;
    pncode:any;
    sellerName:any;
    quantity:any;
    price:any;
    total:any;
    lot:any;
    expirydate:any;
    counter:any;
    productStatus:any
}