import { Component, OnInit, ɵConsole } from '@angular/core';
import { CountryService } from '../../../shared/services/country.service';
import { ProductService } from '../../../shared/services/catalogue/product.service';
import { ToastrService } from 'ngx-toastr';
import { product } from '../../product.model';
import { PaymentDetailService } from '../../../shared/services/sale/payment-detail.service';
import { CustomerService } from '../../../shared/services/customers/customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CutomerModel } from '../../customer.model';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { CountryModel } from '../../country.model';
import { Home } from '../../home.model';
interface City {
  name: string;
  code: string;
}
@Component({
  selector: 'app-add-edit-orders',
  templateUrl: './add-edit-orders.component.html',
  styleUrls: ['./add-edit-orders.component.scss']
})

export class AddEditOrdersComponent implements OnInit {

  url: any;
  data: any
  home = new Home();
  dataarray = []
  customerModel: any = [];
  countryModel: any;// CountryModel[];
  href: any;
  orderId: any;
  selectedCountryId: any;

  sub
  page
  selectedCity: any;

  cities = [
    { name: 'New York', code: 'NY' },
    { name: 'Rome', code: 'RM' },
    { name: 'London', code: 'LDN' },
    { name: 'Istanbul', code: 'IST' },
    { name: 'Paris', code: 'PRS' }
  ];
  constructor(private countryService: CountryService,
    private toastr: ToastrService,
    private productService: ProductService,
    public paymentService: PaymentDetailService,
    private customerService: CustomerService,
    private route: ActivatedRoute,
    private router: Router,
    private service: CommonServiceService
  ) {
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.page = +params['page'] || 0;
        console.log(this.page, "page it is")
      });
    this.href = this.router.url;
    console.log(this.href)

    console.log("edit active", this.editDisplay)
    this.orderId = this.route.snapshot.paramMap.get("id")
    if (this.href == `/orders/edit-order/${this.orderId}` || this.href == `/sale/edit-order/${this.orderId}`) {
      this.orderId = this.route.snapshot.paramMap.get("id")
      console.log("order id", this.orderId)
      this.paymentService.param = this.route.snapshot.paramMap.get("id")
      console.log("order id", this.paymentService.param)
      this.fetchOrderDetails = this.route.snapshot.data['order']
      console.log(this.fetchOrderDetails, "order fetched ddetails")
      //this.getAllCustomers()
      this.assignData(this.fetchOrderDetails)
      this.getProductData()
      this.getProductStatus()
      this.paymentService.editActive = true;
      //this.paymentService.showDisplay =false
    } else {
      this.paymentService.editActive = false
      this.COUNTRYID = 38
      //this.paymentService.showDisplay = true
    }
    this.paymentService.payType = localStorage.getItem(this.orderId)
    if (this.paymentService.payType == 'prepaid' || this.paymentService.payType == 'partial payment') {
      console.log(" false ??")
      this.paymentService.showDisplay = false
    } else {
      this.paymentService.showDisplay = true
    }
  }
  editDisplay: boolean = false
  cols: any[];
  product = new product();
  fetchOrderDetails: any

  back() {
    this.router.navigate(['./sale/orders'])
  }
  addFieldHome() {
    this.home = new Home()
    this.dataarray.push(this.home)
  }
  removeHome(index) {
    this.dataarray.splice(index)
  }
  employee: any;
  employees = [
    { "id": 1, "name": "kiran", "department": "Account" },
    { "id": 2, "name": "john", "department": "Sales" },
    { "id": 3, "name": "frank", "department": "Hr" },
  ];
  employeesResult = [];

  onSaveOrder(val) {

  }
  ngOnInit() {
    this.selectedCity = this.cities[3]
    console.log("selected >>>>>>>", this.selectedCity)
    //localStorage.removeItem('method-of-pay')
    this.paymentService.datas.orderDate = new Date().toISOString().split('T')[0];
    this.product = new product();
    this.dataarray.push(this.home)
    Promise.all([this.getAllCountries(),
    this.getAllProductsData()
    ]);

  }
  ngOnDestroy() {
    //  localStorage.removeItem(this.orderId);
    //localStorage.removeItem('method-of-pay')

  }
  productStatus: any
  getProductStatus() {
    this.paymentService.getSingleProductStatus()
      .subscribe((response) => {
        this.productStatus = response;
        this.productStatus = this.productStatus.response.result
        console.log("status is ", this.productStatus)
      }, (error) => {
        console.log(error)
      })
  }
  cancelTable: boolean = false
  cancelDataTable: any;
  getProductData() {
    this.paymentService.getSingleProductDetail(this.paymentService.param)
      .subscribe((response) => {
        let data: any = response;
        data = data.response.result;
        console.log(data, "data for data array")
        this.dataarray = data
        this.employeesResult = this.dataarray
        /* to do logic if this.dataarray.length =  
        calculate the length first 
        then */
        if (localStorage.getItem('order-status') == 'Cancelled') {
          this.dataarray.forEach((elem) => {
            if (elem.orderProductStatus === 'Cancelled') {
              console.log(elem, ">>>>>>")
              this.dataarray = this.dataarray.filter(o => o.orderProductStatus === 'Cancelled');
              this.paymentService.cancelDetails(this.orderId)
                .subscribe((response) => {
                  this.cancelDataTable = response;
                  this.cancelDataTable = this.cancelDataTable.response.result;
                  console.log(this.cancelDataTable)
                  this.cancelTable = true
                })

              console.log(this.dataarray, 'cacnelledddd')
            }
          })
        } else if (localStorage.getItem('order-status') == 'Out of Stock') {
          this.dataarray.forEach((elem) => {
            if (elem.orderProductStatus === 'Out of Stock') {
              this.dataarray = this.dataarray.filter(o => o.orderProductStatus === 'Out of Stock');
              console.log(this.dataarray, "out of stock data")
            }
          })
        } else {
          this.dataarray;
          console.log(this.dataarray)
        }

        //var cancelArr =  data.productData.filter(o => o.orderProductStatus === 'Cancelled');
        console.log(this.dataarray, "array of products")
        this.employeesResult = this.dataarray
      }, (error) => {
        console.log(error);
      })
  }

  shallowCopy(data) {
    this.summaryData = JSON.parse(JSON.stringify(data));
    this.summaryData = this.summaryData.filter(o => o.orderProductStatus !== 'In Stock')
    if (this.summaryData.length < 1) {
      this.summaryMesg = true
    }
    console.log(this.summaryData, "order status")
  }
  summaryData: any;
  summaryMesg = false;
  totalAmountWithTax
  ORDERNO: any;
  ORDER_TYPE: any;
  DELTYPE: any;
  assignData(data) {
    console.log('yeah', data)
    data = data.response.result[0];
    this.DELTYPE = data.delieveryType
    console.log("delievery data ?", this.DELTYPE)
    this.ORDERNO = data.orderNo;
    this.ORDER_TYPE = this.ORDERNO.substring(0, 3)
    console.log('order data', this.ORDER_TYPE)
    this.paymentService.taxDetailsData.taxCode = 5
    //this.paymentService.paymentSettleArray.push(data.methodOfPayment)
    this.COUNTRYID = data.countryid;
    this.paymentService.codAmount = data.methodOfPayment.cod
    //this.paymentService.cod.chequeno = data.methodOfPayment
    this.paymentService.taxDetailsData.delieveryCharge = parseFloat(data.delieveryCharge)
    this.paymentService.taxDetailsData.card = data.methodOfPayment.card
    this.paymentService.taxDetailsData.wallet = data.methodOfPayment.wallet
    this.paymentService.taxDetailsData.delieveryType = data.delieveryType
    this.paymentService.taxDetailsData.taxCode = data.taxCode;
    this.paymentService.taxDetailsData.total = parseInt(data.totalAmountWithTax)
    this.paymentService.taxDetailsData.productTotal = parseInt(data.productTotal)
    this.paymentService.taxDetailsData.taxAmount = parseInt(data.tax)
    this.paymentService.taxDetailsData.taxpercent = 10
    this.paymentService.billingAddress.billingStreetName = data.billingStreetName
    this.paymentService.billingAddress.billingBuildingName = data.billingBuildingName
    this.paymentService.billingAddress.billingBlockNo = data.billingBlockNo
    this.paymentService.billingAddress.billingBlockNo = data.billingBlockNo
    this.paymentService.billingAddress.billingUnitNo = data.billingUnitNo
    this.paymentService.billingAddress.billingPostcode = data.billingPostcode
    this.paymentService.billingAddress.billingClinicName = data.billingClinicName
    this.paymentService.shippingAddress.shippingClinicName = data.shippingClinicName
    this.paymentService.shippingAddress.shippingBuildingName = data.shippingBuildingName
    this.paymentService.shippingAddress.shippingBlockNo = data.shippingBlockNo
    this.paymentService.shippingAddress.shippingFloorNo = data.shippingFloorNo
    this.paymentService.shippingAddress.shippingUnitNo = data.shippingUnitNo
    this.paymentService.shippingAddress.shippingStreetName = data.shippingStreetName
    this.paymentService.shippingAddress.shippingPostcode = data.shippingPostcode
    this.paymentService.shippingAddress.shippingClinicName = data.shippingClinicName
    this.paymentService.datas.orderDate = data.orderDate
    this.paymentService.datas.customerId = data.customerId
    this.paymentService.orderData.orderDetails.customerId = data.customerId
    this.paymentService.datas.Email = data.Email
    this.paymentService.datas.customerId = data.customerId
    this.paymentService.datas.mobileNumber = data.mobileNumber
    this.paymentService.datas.customerName = data.customerId
    this.custID = this.paymentService.datas.customerName
    console.log("country name issssssssss", this.custID)
    console.log("pincode is", data.billingPostcode)


    // this.countryModel.some((elem)=>{
    //   if(elem.)
    // })
    this.paymentService.datas.country = parseInt(data.countryid)
    this.paymentService.datas.orderStatusComments = data.orderStatusComments;
    this.paymentService.datas.orderNo = data.orderNo
    this.paymentService.datas.groupName = data.groupName;
    console.log(typeof this.paymentService.datas.country, "idd???")
    localStorage.setItem('method-of-pay', JSON.stringify(data.methodOfPayment))
    this.getWalletData(this.custID)
  }


  /* 
  *get all customers 
  */
  custID: any;
  customerData: any
  getAllCustomers(countryId) {
    this.customerService.getCountryCustomers(countryId)
      .subscribe((response) => {
        this.customerData = response;
        this.customerData = this.customerData.data.results
        this.customerModel = this.customerData;
        if (this.paymentService.editActive == true) {
          this.customerModel.some((elem) => {
            if (elem.customerId == this.paymentService.datas.customerName) {
              this.paymentService.datas.customerName = elem
              this.custID = this.paymentService.datas.customerName.customerId
              console.log("customer id is ", this.custID)
            }
            // this.paymentService.datas.customerName =

          })
        }
        console.log(this.customerModel)
      }, (error) => {
        this.toastr.error(error.message)
      })
  }

  getWalletData(id) {
    this.paymentService.getWalletDetails(id)
      .subscribe((response) => {
        this.paymentService.walletData = response
        this.paymentService.walletData = this.paymentService.walletData.data.wallet
      })

  }

  /* 
  *customer selection make
  */

  customerDataChangeDetect(value) {
    console.log(value)
    this.paymentService.getWalletDetails(value.customerId)
      .subscribe((response) => {
        this.paymentService.walletData = response
        this.paymentService.walletData = this.paymentService.walletData.data.wallet

        console.log(this.paymentService.walletData)
      })
    this.customerModel.some((elem) => {
      if (value.customerId == elem.customerId) {
        console.log('enter')
        console.log(elem)
        this.paymentService.datas.Email = elem.Email
        this.paymentService.datas.customerId = elem.customerId
        console.log(this.paymentService.datas.customerId)
        this.paymentService.datas.mobileNumber = elem.mobileNumber
        //this.paymentService.datas.customerName = elem.firstName + ' ' + ' ' + elem.lastName
        this.paymentService.datas.customerName = value.customerId
        this.paymentService.billingAddress.billingClinicName = elem.clinicName
        this.paymentService.shippingAddress.shippingClinicName = elem.clinicName
      } else {
        return false;
      }

    })

  }
  /* 
  *this method will fetch all the countries 
  */
  countriesData: any
  getAllCountries() {
    this.service.getCountry().subscribe((response) => {
      this.countryService.countriesName = response;
      this.countryService.countriesName = this.countryService.countriesName.data
      this.countriesData = this.countryService.countriesName
      this.countryModel = this.countriesData;

      console.log("country model is,", this.countryModel)
      if (this.editDisplay == false) {
        this.detectCountry(38)
        this.COUNTRYID = 38
      }
    }, (error) => {
      this.toastr.error(error.message)
    })
  }
  countryName: any
  countryid: any
  contid: any;
  COUNTRYID: any;

  countryDisplay = false;
  detectCountry(value) {
    console.log("value is", value)
    this.COUNTRYID = value
    this.countryModel.some((elem) => {
      if (elem.id == value) {
        this.paymentService.datas.country = elem

        console.log("value of elem is", elem)
        this.paymentService.datas.billingCountryName = elem.itemName
        this.paymentService.datas.countryid = elem.id
        this.contid = elem.id
        console.log("id is ", this.paymentService.datas.countryid)
        this.countryName = elem.itemName
        this.countryid = elem.id
        this.countryDisplay = true
      } else {
        return false
      }
      //return false;
    })
    if (!this.orderId) {
      this.paymentService.getDeliveryDetails(value).subscribe((response) => {
        console.log(response, "delievery data");
        localStorage.setItem("delievery", JSON.stringify(response))
        let deliveryType: any = response;
        let data: any = response;
        // console.log("DATA ")
        // this.COUNTRYID = data.data.countryId
        // console.log("country id is", this.COUNTRYID)
        this.getAllProductsData()
        deliveryType = deliveryType.data.title
        this.paymentService.taxDetailsData.delieveryType = deliveryType;
        this.paymentService.taxDetailsData.delieveryCharge = data.data.deliveryCharge;

      })
    } else {
      this.paymentService.getDeliveryDetails(value).subscribe((response) => {
        console.log(response, "delievery data, else block");
        //localStorage.setItem("delievery",JSON.stringify(response))
        let deliveryType: any = response;


        deliveryType = deliveryType.data.Detail
        console.log("else delievery data is", deliveryType)
        deliveryType.some((elem) => {
          if (elem.title == this.DELTYPE) {
            console.log("yeah")
            this.paymentService.taxDetailsData.delieveryType = elem.id
          }
        })
        // this.paymentService.taxDetailsData.delieveryType = deliveryType;
        // this.paymentService.taxDetailsData.delieveryCharge = data.data.deliveryCharge;

      })

    }

  }
  /* 
  * this method will fetch all the product details 
  */
  productData: any;

  getAllProductsData() {
    this.productService.getAllRegisteredProducts(this.COUNTRYID).subscribe((response) => {
      console.log(response);
      // this.productData = response;
      // this.productData = this.productData.data.results
      this.productData = response
      this.productData = this.productData.data
      console.log(">>>>> products data", this.productData)
    }, (error) => {
      this.toastr.error(error.message)
    })
  }
  detectChangeProduct(value, v1) {
    console.log(value, "value");
    console.log(v1, "vidss")
    this.productData.some((elem) => {


      if (elem.productId == value) {
        console.log("elem", elem)
        console.log("elem id", elem.sellerProducts[0].id)
        //this.dataarray[v1].sellerId = elem.sellerProducts[0].id
        this.dataarray[v1].pncode = elem.PNCDE
        this.dataarray[v1].productName = elem.productName
        this.dataarray[v1].productId = elem.productId
        this.dataarray[v1].sellerName = elem.sellerProducts[0].sellerDetail.sellerName
        this.dataarray[v1].price = parseInt(elem.MRP)
        this.dataarray[v1].orderProductStatus = 'In Stock'
        this.dataarray[v1].discount = 0;
        this.dataarray[v1].sellerfee = elem.sellerProducts[0].sellerFee;
        console.log(elem.sellerProducts[0].sellerFee)
        this.dataarray[v1].total = this.dataarray[v1].price * this.dataarray[v1].quantity
      }
    })
  }
  searchProduct(event, v1): void {
    console.log(event.query, v1)
    // if(event.length > 0){
    this.employeesResult = this.productData.filter(c => c.productName.startsWith(event.query));
    console.log(this.employeesResult)
    this.dataarray[v1].productName = this.employeesResult[0].productName
    this.dataarray[v1].pncode = this.employeesResult[0].PNCDE
    this.dataarray[v1].sellerId = this.employeesResult[0].sellerProducts.id
    this.dataarray[v1].sellerId = this.employeesResult[0].sellerProducts.id
    this.dataarray[v1].sellerName = this.employeesResult[0].sellerDetail.sellerName
    this.dataarray[v1].sellerfee = this.employeesResult[0].sellerProducts[0].sellerFee;
    this.dataarray[v1].price = parseInt(this.employeesResult[0].MRP)
    this.dataarray[v1].discount = 0;
    this.dataarray[v1].orderProductStatus = 'In Stock'
    // } else {
    console.log("enter here")
    //}


  }
  changeProductStatus(value, v1) {
    let tempTotal = []
    this.dataarray[v1].orderProductStatus = value
    this.dataarray.forEach((elem) => {
      if (elem.orderProductStatus == 'In Stock') {
        tempTotal.push(elem.total)
      }
    })

    var sum = tempTotal.reduce(function (a, b) {
      return a + b;
    }, 0);
    this.paymentService.taxDetailsData.productTotal = sum
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal * 10 / 100
    this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal
  }

  quantityDetectChange(value, vl) {
    let tempTotal = []
    this.dataarray[vl].total = this.dataarray[vl].price * value
    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.total)
    })
    var sum = tempTotal.reduce(function (a, b) {
      return a + b;
    }, 0);
    this.paymentService.taxDetailsData.productTotal = sum
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal * 10 / 100
    this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal
  }

  detectChangePrice(value, vl) {
    let tempTotal = []
    this.dataarray[vl].total = this.dataarray[vl].quantity * value
    var sum = tempTotal.reduce(function (a, b) {
      return a + b;
    }, 0);
    this.paymentService.taxDetailsData.productTotal = sum
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal * 10 / 100
    this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal
  }

  paymentSection = async () => {
    this.paymentService.datas.shippingBlockNo = this.paymentService.shippingAddress.shippingBlockNo
    this.paymentService.datas.shippingBuildingName = this.paymentService.shippingAddress.shippingBuildingName
    this.paymentService.datas.shippingClinicName = this.paymentService.shippingAddress.shippingClinicName
    this.paymentService.datas.shippingFloorNo = this.paymentService.shippingAddress.shippingFloorNo
    this.paymentService.datas.shippingPostcode = this.paymentService.shippingAddress.shippingPostcode
    this.paymentService.datas.shippingStreetName = this.paymentService.shippingAddress.shippingStreetName
    this.paymentService.datas.shippingUnitNo = this.paymentService.shippingAddress.shippingUnitNo
    this.paymentService.datas.billingClinicName = this.paymentService.billingAddress.billingClinicName
    this.paymentService.datas.billingBuildingName = this.paymentService.billingAddress.billingBuildingName
    this.paymentService.datas.billingBlockNo = this.paymentService.billingAddress.billingBlockNo
    this.paymentService.datas.billingFloorNo = this.paymentService.billingAddress.billingFloorNo
    this.paymentService.datas.billingUnitNo = this.paymentService.billingAddress.billingUnitNo
    this.paymentService.datas.billingStreetName = this.paymentService.billingAddress.billingStreetName
    this.paymentService.datas.billingPostcode = this.paymentService.billingAddress.billingPostcode
    this.paymentService.datas.paymenttype = this.paymentService.paySelectByUser;
    console.log("service mode of payment is", this.paymentService.datas.paymenttype);
    this.paymentService.orderRecordTable = this.dataarray;
    localStorage.setItem('order-table', JSON.stringify(this.paymentService.orderRecordTable))
    this.customerModel.some((elem) => {
      if (elem.customerId == this.paymentService.orderData.orderDetails.customerId) {
        this.paymentService.orderData.orderDetails.customerName = elem.firstName + ' ' + elem.lastName
      } else {
        return false
      }
      // return false;
    })
    if (this.paymentService.editActive == false) {
      console.log('enter here ?')
      this.paymentService.orderData = {
        "orderDetails": this.paymentService.datas,
        "productData": this.dataarray,
        "walletPayment": {
          taxCode: this.paymentService.taxDetailsData.taxCode,
          tax: 10,
          delieveryType: this.paymentService.taxDetailsData.delieveryType,
          totalAmountWithTax: this.paymentService.taxDetailsData.total,//this.paymentService.taxDetailsData.delieveryCharge,
          "wallet": 0,
          "card": 0,
          "cod": 0,
          "userpreference": "not mentioned",
          "amountSettled": "false",
          "delieveryCharge": 3.50
          // "delieveryCharge":this.paymentService.taxDetailsData.delieveryCharge
        }
      }

      console.log('tottttal', this.paymentService.taxDetailsData.total)
      console.log(this.paymentService.taxDetailsData.delieveryCharge)
      this.paymentService.taxDetailsData.total = this.paymentService.orderData.walletPayment.totalAmountWithTax
      console.log("dddd", this.paymentService.orderData.walletPayment.totalAmountWithTax);
      console.log("dddd", typeof this.paymentService.orderData.walletPayment.totalAmountWithTax);
      console.log("total amount for new order", this.paymentService.taxDetailsData.total)
      console.log("delievry charge", this.paymentService.taxDetailsData.delieveryCharge)
      console.log("delievry charge type of", typeof this.paymentService.taxDetailsData.delieveryCharge)

      this.customerModel.some((elem) => {
        if (elem.customerId == this.paymentService.orderData.orderDetails.customerId) {
          this.paymentService.orderData.orderDetails.customerName = elem.firstName + ' ' + elem.lastName
        } else {
          return false
        }
        // return false;
      })
      console.log(this.paymentService.orderData);
      this.router.navigate(['/sale/pay-section'])
    }

    if (this.paymentService.editActive == true && this.ORDER_TYPE === "BRD") {
      console.log("yeyeyeyey", this.dataarray)
      let checkDifferentStatus = []
      this.dataarray.forEach((elem) => {
        if (elem.orderProductStatus != 'In Stock') {
          checkDifferentStatus.push(elem)
        }
      })
      if (checkDifferentStatus.length > 0) {
        this.toastr.info("All Product status should be In stock ")
      } else {
        this.paymentService.orderData = {
          "orderDetails": this.paymentService.datas,
          "productData": this.dataarray,
          "walletPayment": {
            taxCode: this.paymentService.taxDetailsData.taxCode,
            tax: 10,
            delieveryType: this.paymentService.taxDetailsData.delieveryType,
            totalAmountWithTax: this.paymentService.taxDetailsData.total + parseFloat(this.paymentService.taxDetailsData.delieveryCharge),
            "wallet": this.paymentService.taxDetailsData.wallet,
            "card": this.paymentService.taxDetailsData.card,
            "cod": this.paymentService.taxDetailsData.cod,
            "userpreference": "not mentioned",
            "amountSettled": this.paymentService.taxDetailsData.amountSettled
          }
        }
        this.router.navigate(['/sale/pay-section'], { queryParams: { order: this.orderId } })
      }
    }
    if (this.paymentService.editActive == true && this.ORDER_TYPE !== "BRD") {
      console.log('or enter here ?')
      console.log(this.dataarray, ">>>>>")
      this.paymentService.OutRecord = JSON.parse(JSON.stringify(this.dataarray));
      this.paymentService.OutRecord = this.dataarray.filter(o => o.orderProductStatus === 'Out of Stock');
      console.log("out record is", this.paymentService.OutRecord)
      this.paymentService.orderData = {
        "orderDetails": this.paymentService.datas,
        "productData": this.dataarray,
        "walletPayment": {
          taxCode: this.paymentService.taxDetailsData.taxCode,
          tax: 10,
          delieveryType: this.paymentService.taxDetailsData.delieveryType,
          totalAmountWithTax: this.paymentService.taxDetailsData.total + parseFloat(this.paymentService.taxDetailsData.delieveryCharge),
          "wallet": this.paymentService.taxDetailsData.wallet,
          "card": this.paymentService.taxDetailsData.card,
          "cod": this.paymentService.taxDetailsData.cod,
          "userpreference": "not mentioned",
          "amountSettled": this.paymentService.taxDetailsData.amountSettled
        }
      }
      this.settlePayment();
      if (this.paymentService.payType == 'prepaid' || this.paymentService.payType == 'partial payment') {
        // console.log('entering here to prepaid')
        //this.settlePayment();
      } else {
        this.router.navigate(['/sale/pay-section'], { queryParams: { order: this.orderId } })
        //this.router.navigate(['../sale/pay-section'])
      }
      // this.settlePayment();
    }
    // localStorage.setItem('orderdata',JSON.stringify(this.paymentService.orderData))
    this.paymentService.taxDetailsData.productTotal = this.paymentService.taxDetailsData.productTotal
    localStorage.setItem('payment-section', JSON.stringify(this.paymentService.taxDetailsData))
    // console.log( this.paymentService.orderData,'>>>>>>>')   
  }
  computeData: any = {
    methodOfPayment: {
      card: null,
      wallet: null,
      cod: null
    }
  };
  settlePayment = async () => {
    this.computeData.tax = this.paymentService.orderData.walletPayment.tax;
    this.computeData.methodOfPayment.card = this.paymentService.orderData.walletPayment.card;
    this.computeData.methodOfPayment.wallet = this.paymentService.orderData.walletPayment.wallet;

    let inStockArr = await this.dataarray.filter(o => o.orderProductStatus === 'In Stock');
    console.log('in stock is ', inStockArr);
    let cancelArr = await this.dataarray.filter(o => o.orderProductStatus === 'Cancelled');
    let outStock = await this.dataarray.filter(o => o.orderProductStatus === 'Out of Stock');
    console.log("outstock is ", outStock);
    /* to do out of stock */

    if (inStockArr.length > 0) {
      let tempArr = [];
      inStockArr.forEach((elem) => {
        tempArr.push(elem.productId);
      });
      console.log('computing tax', this.computeData.tax)
      var calTax = await this.calculateTax(inStockArr, this.computeData.tax);
      console.log("taxxxx is", calTax)
      console.log("taxxxx is", parseFloat(this.paymentService.taxDetailsData.delieveryCharge))
      this.computeData.totalAmountWithTax = calTax + parseFloat(this.paymentService.taxDetailsData.delieveryCharge);
      console.log("amount with tax", this.computeData.totalAmountWithTax)
      console.log("amount in wallet", this.paymentService.orderData.walletPayment.wallet)
      await this.amountSettle(parseFloat(this.paymentService.orderData.walletPayment.wallet), parseFloat(this.paymentService.orderData.walletPayment.card), parseFloat(this.paymentService.orderData.walletPayment.cod))

      var cancelTrans = await this.checkCancel(cancelArr);
      var outTrans = await this.checkCancel(outStock);
      this.paymentService.orderData.walletPayment.card = this.computeData.methodOfPayment.card
      this.paymentService.orderData.walletPayment.wallet = this.computeData.methodOfPayment.wallet
      console.log(this.paymentService.orderData, '--------------------------------')

      localStorage.setItem('orderdata', JSON.stringify(this.paymentService.orderData))
      let data = {
        cod: this.paymentService.orderData.walletPayment.cod || 0,
        card: this.paymentService.orderData.walletPayment.card,
        wallet: this.paymentService.orderData.walletPayment.wallet
      }
      localStorage.setItem('method-of-pay', JSON.stringify(data))
      this.router.navigate(['/sale/pay-section'], { queryParams: { order: this.orderId } })

    } else {
      this.showCancelDisplay = true;
      this.toastr.info(`No active order will remain in case you 
    tried to move this item to Canceled/Out of Stock state , hence , you may cancel the order. `)

    }
  }

  showCancelDisplay = false
  /* no instock material cancel the order */
  cancelOrder() {
    console.log(this.paymentService.orderData, "caancel summary")
    this.paymentService.cancelOrder(this.orderId, this.paymentService.orderData)
      .subscribe((response) => {
        console.log(response);
        this.toastr.show('Ordered cancelled successfully')
        this.router.navigate(['./orders/orders'])
      }, (error) => {
        console.log(error)
        this.toastr.error(error)
      })

  }

  calculateTax = (arr, tax) => {
    var productTotal = arr.reduce(function (prev, cur) {
      return prev + cur.total;
    }, 0);
    this.computeData.productTotal = productTotal;
    let totalAmountWithTax = productTotal * tax / 100;
    totalAmountWithTax = totalAmountWithTax + productTotal
    return totalAmountWithTax;
  }

  amountSettle = (wallet, card, cod) => {
    var amount = wallet + card + cod;
    if (this.computeData.totalAmountWithTax != amount) {
      this.computeData.amountSettled = false;
      this.paymentService.taxDetailsData.amountSettled = "false"
    } else {
      this.computeData.amountSettled = true;
      this.paymentService.taxDetailsData.amountSettled = "true"
    }
    return;
  }
  cancelData: any = {};
  /* check for cancel products */
  checkCancel = async (cancelArr) => {
    console.log("check cancel array", cancelArr)
    let tempArr = [];
    cancelArr.forEach((elem) => {
      tempArr.push(elem.productId);
    });
    this.cancelData.listOfProductIds = JSON.stringify(tempArr);
    console.log("tax send?", this.computeData.tax)
    var calTax = await this.calculateCancelTax(cancelArr, this.computeData.tax);
    console.log("tax calculated", calTax)
    this.cancelData.totalAmountWithTax = calTax + parseFloat(this.paymentService.taxDetailsData.delieveryCharge);

    let refund = await this.refundAmount(this.cancelData);
    console.log(refund, 'refund ?');
    return refund;
  }
  /* refund process */
  refundAmount = async (cancelData) => {
    if (parseFloat(this.computeData.methodOfPayment.wallet) >= parseFloat(this.computeData.methodOfPayment.card)) {
      if (parseFloat(this.computeData.methodOfPayment.wallet) <= parseFloat(cancelData.totalAmountWithTax)) {
        let difference = cancelData.totalAmountWithTax - parseFloat(this.computeData.methodOfPayment.wallet)
        this.computeData.methodOfPayment.card = parseFloat(this.computeData.methodOfPayment.card) - difference
        this.computeData.methodOfPayment.card = this.computeData.methodOfPayment.card + parseFloat(this.paymentService.taxDetailsData.delieveryCharge)
        this.computeData.methodOfPayment.wallet = 0
        return this.computeData;
      } if (parseFloat(this.computeData.methodOfPayment.wallet) >= parseFloat(cancelData.totalAmountWithTax)) {
        this.computeData.methodOfPayment.wallet = parseFloat(this.computeData.methodOfPayment.wallet) - parseFloat(cancelData.totalAmountWithTax)
        this.computeData.methodOfPayment.wallet = this.computeData.methodOfPayment.wallet + parseFloat(this.paymentService.taxDetailsData.delieveryCharge)
        return this.computeData
      }
    } else {
      if (parseFloat(this.computeData.methodOfPayment.card) <= parseFloat(cancelData.totalAmountWithTax)) {
        let difference = cancelData.totalAmountWithTax - parseFloat(this.computeData.methodOfPayment.card)
        this.computeData.methodOfPayment.wallet = parseFloat(this.computeData.methodOfPayment.wallet) - difference
        this.computeData.methodOfPayment.wallet = this.computeData.methodOfPayment.wallet + parseFloat(this.paymentService.taxDetailsData.delieveryCharge)
        this.computeData.methodOfPayment.card = 0
        return this.computeData;
      }
      if (parseFloat(this.computeData.methodOfPayment.card) >= parseFloat(cancelData.totalAmountWithTax)) {
        this.computeData.methodOfPayment.card = parseFloat(this.computeData.methodOfPayment.card) - parseFloat(cancelData.totalAmountWithTax)
        this.computeData.methodOfPayment.card = this.computeData.methodOfPayment.card + parseFloat(this.paymentService.taxDetailsData.delieveryCharge)
        return this.computeData
      }
    }
  }
  /* for cancel */
  calculateCancelTax = async (arr, tax) => {
    var productTotal = arr.reduce(function (prev, cur) {
      return prev + cur.total;
    }, 0);
    this.cancelData.productTotal = productTotal;
    let totalAmountWithTax = productTotal * tax / 100;
    totalAmountWithTax = totalAmountWithTax + productTotal
    return totalAmountWithTax;
  }

  getCountryDetail(e) {
    this.selectedCountryId = e.value;
    this.service.getCountryParams(this.selectedCountryId);
    this.service.getMaxLength();
    this.getAllCustomers(e.value)
  }

}
