import { Component, OnInit } from '@angular/core';
import { PaymentDetailService } from '../../../shared/services/sale/payment-detail.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-paysection',
  templateUrl: './paysection.component.html',
  styleUrls: ['./paysection.component.scss']
})
export class PaysectionComponent implements OnInit {
  sub
  page
  constructor(public service: PaymentDetailService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    this.sub = this.route
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        this.page = +params['order'] || 0;
        console.log(this.page, ",,,,page it is ?????")
      });
     
      this.service.delieveryData =JSON.parse(localStorage.getItem("delievery"))
      this.service.delieveryData = this.service.delieveryData.data.Detail
      console.log("del data",this.service.delieveryData)
      this.service.orderData = JSON.parse(localStorage.getItem('orderdata'))
      this.service.taxDetailsData =JSON.parse(localStorage.getItem('payment-section'))
      console.log(this.service.taxDetailsData,"yeah")
      console.log("yeahhhh change amount",   this.service.orderData)
      this.service.taxDetailsData.total = this.service.orderData.walletPayment.totalAmountWithTax
      this.service.taxDetailsData.productTotal = this.service.taxDetailsData.productTotal //+ this.service.taxDetailsData.taxAmount
      console.log("pay section product total is",this.service.taxDetailsData.productTotal)
      this.service.orderRecordTable = JSON.parse(localStorage.getItem('order-table'))
      if (this.page > 0 ) {
        console.log("enter , in section")
        let methodOfPay:any = JSON.parse(localStorage.getItem('method-of-pay'))
        console.log("method of payment is",methodOfPay)
        this.service.codAmount = methodOfPay.cod || 0
        console.log(this.service.taxDetailsData.card, "cod amount")
        // this.paymentService.cod.chequeno = data.methodOfPayment
        this.service.taxDetailsData.card = methodOfPay.card
        this.service.taxDetailsData.wallet = this.service.orderData.walletPayment.card
      } else {
        console.log("new statement",this.service.delieveryData[0])
        this.service.taxDetailsData.delieveryType = this.service.delieveryData[0].id
        this.service.taxDetailsData.delieveryCharge = this.service.delieveryData[0].deliveryCharge
        this.service.taxDetailsData.total = this.service.taxDetailsData.total + parseFloat(this.service.taxDetailsData.delieveryCharge )
        console.log("delievery charge is",this.service.taxDetailsData.delieveryCharge )
      }


    console.log(this.service.orderData)
  }
  getWalletData(id){
    this.service.getWalletDetails(id)
    .subscribe((response)=>{
     this.service.walletData = response
     this.service.walletData = this.service.walletData.data.wallet
    })
 
  }
  back() {
    if (this.page) {
      this.router.navigate([`/sale/edit-order/${this.page}`])
    } else {
      this.router.navigate([`/sale/new-order`])
    }

  }

  ngOnDestroy(){
     this.service.orderData.walletPayment.wallet = null;
     this.service.orderData.walletPayment.card = null;
     localStorage.removeItem('payment-section')
     localStorage.removeItem('orderdata')
     //localStorage.removeItem('method-of-pay')
     localStorage.removeItem('order-table')
  }

  ngOnInit() {
    console.log("payment detail service ??",this.service.taxDetailsData.delieveryType)
    
    if (this.service.editActive == true) {
      
      if (this.service.payType) {

        this.service.modeOfPay = "prepaid";
        
      } else {

        this.service.modeOfPay = "cod";
        

      }
    } else {
      
      this.service.modeOfPay = "prepaid"
      this.service.paySelectByUser = "prepaid"
      this.service.orderData.orderDetails.paymenttype = "prepaid"
      
    }


    Promise.all([this.getAllBanks(), this.getAllModes()])
  }

  getAllModes() {
    this.service.getAllModeOfPayment()
      .subscribe((response) => {
        this.service.usrePaymentType = response;
        this.service.usrePaymentType = this.service.usrePaymentType.response.result
        console.log(this.service.usrePaymentType);
      })
  }
  getAllBanks() {
    this.service.getAllBankNames()
      .subscribe((response) => {
        this.service.bankDetailsFromDb = response;
        this.service.bankDetailsFromDb = this.service.bankDetailsFromDb.response.result
        console.log(this.service.bankDetailsFromDb);
      })
  }

  detectPaymentType(value) {
    console.log(value);
    if (value == 'prepaid') {
    
      this.service.paySelectByUser = value;
      this.service.orderData.orderDetails.paymenttype = this.service.paySelectByUser;
      // this.service.datas.paymenttype = 
      this.service.orderData.walletPayment.cod = null;
    }
    //  else if (value == 'cod') {
    //   this.service.paySelectByUser = value
    //   this.service.orderData.orderDetails.paymenttype = this.service.paySelectByUser;
    //   //this.service.datas.paymenttype = this.service.paySelectByUser;
    //   this.service.orderData.walletPayment.cod = this.service.taxDetailsData.total
    // }
  }
  submit() {

   
    if (this.service.codAmount == undefined || this.service.codAmount == null){
      
      this.service.codAmount = 0
    }
    // console.log(this.service.taxDetailsData.total, "total amount")
    if ((this.service.orderData.walletPayment.wallet == null || this.service.orderData.walletPayment.wallet == 0 || this.service.orderData.walletPayment.wallet == undefined ) && (this.service.orderData.walletPayment.card == null ||this.service.orderData.walletPayment.card == 0 || this.service.orderData.walletPayment.card == undefined ) && (this.service.codAmount == null || this.service.codAmount == 0 || this.service.codAmount == undefined)){
      this.toastr.error("Add valid enteries in payment options")
      return
    }
    
     
     let productTotal = this.service.orderData.walletPayment.wallet + this.service.orderData.walletPayment.card + this.service.codAmount 
     //console.log("product total",productTotal) 
     if (this.service.taxDetailsData.total != productTotal){
       // console.log("checked")
        this.toastr.error(`The amount should be equal to the toal amount i.e. ${this.service.taxDetailsData.total}`)
        return
      }
    
    if (this.service.OutRecord.length > 0){
      this.service.outStockOrder(this.service.OutRecord)
      .subscribe((response)=>{
        this.toastr.success("Out of stock order inserted successfully")
      },(error)=>{
        this.toastr.error("Issues while inserting out stock data")
        console.log(error)
      })
    }
    this.service.taxDetailsData.cod = this.service.codAmount
    this.service.orderData.walletPayment.cod = this.service.codAmount
    this.service.orderData.walletPayment.delieveryType = this.service.taxDetailsData.delieveryType
    // console.log(this.service.cod, "cod data");
    // console.log(this.service.orderData.walletPayment.card , "card ?")
    console.log(JSON.stringify(this.service.orderData));
    let siteType = 'admin'
    console.log("edit active status",this.service.editActive)
    if (this.service.editActive == false) {
      
      if (this.service.codAmount > 0 && (this.service.orderData.walletPayment.card > 0 ||this.service.orderData.walletPayment.wallet > 0 )){
        console.log('y')
        this.service.orderData.orderDetails.paymenttype = "partial payment"
        //console.log("partial")
      }
      
      else if (this.service.codAmount > 0 && (this.service.orderData.walletPayment.card == null ||this.service.orderData.walletPayment.wallet == null )) {
        this.service.orderData.orderDetails.paymenttype = "credit"
        if (this.service.codAmount != this.service.taxDetailsData.total  ){
          this.toastr.info("Cod amount is not entered correctly") 
          return;
        }
      }else if (this.service.codAmount > 0 && (this.service.orderData.walletPayment.card <= 0 ||this.service.orderData.walletPayment.wallet <= 0 )) {
        this.service.orderData.orderDetails.paymenttype = "credit"
        if (this.service.codAmount != this.service.taxDetailsData.total  ){
          this.toastr.info("Cod amount is not entered correctly") 
          return
        }
      } 
     
      if (this.service.orderData.walletPayment.wallet > this.service.walletData) {
          this.toastr.error(`Your amount in wallet is less , can't go ahead with the payment,Kindly reduce the amount to ${this.service.walletData}`)
          return
        }
        
        this.service.delieveryData.some((elem)=>{
          if(elem.id == this.service.taxDetailsData.delieveryType){
            // this.paymentService.taxDetailsData.delieveryCharge = elem.deliveryCharge
            this.service.taxDetailsData.delieveryType = elem.title
            // this.paymentService.taxDetailsData.delieveryType = elem.id
          }
        })
      this.service.orderData.walletPayment.delieveryCharge = this.service.taxDetailsData.delieveryCharge
      this.service.orderData.walletPayment.totalAmountWithTax = this.service.taxDetailsData.total
      this.service.orderData.walletPayment.delieveryType = this.service.finalDelType
      this.service.orderData.orderDetails.country = this.service.orderData.orderDetails.country.itemName
      console.log("removed country",JSON.stringify(this.service.orderData.orderDetails))
      this.service.insertNewOrder(this.service.orderData, siteType, null)
        .subscribe((response) => {
          let mesg: any = response;
          mesg = mesg.response.result.orderId
          //console.log(mesg)
          this.toastr.success('New Order with ID ' + ' ' + mesg + ' is created successfully!');
          // this.service.orderData.walletPayment.wallet = null;
          // this.service.orderData.walletPayment.card = null;
          if ( this.service.orderData.walletPayment.wallet > 0 ){
            this.deductBalance()
            this.router.navigate(['/sale/orders'])
          } else {
            this.router.navigate(['/sale/orders'])
          }
          
         
        }, (error) => {
          console.log(error);
        })
    } 
    if (this.service.editActive == true) {
      console.log("update")
      // this.service.orderData.walletPayment.chequeno = this.service.cod.chequeno
      // this.service.orderData.walletPayment.bankname = this.service.cod.bankname
      // this.service.orderData.walletPayment.codreceivedate = this.service.cod.codreceivedate
      console.log(JSON.stringify(this.service.orderData),"update order details")
      this.service.updateOrder(this.service.orderData, this.service.param)
        .subscribe((response) => {
          let mesg: any = response
          let backorder: any = response
          backorder = backorder.response.backOrderData.orderId;
          mesg = mesg.response.status
          if (mesg === 200) {
            this.toastr.info(`Order Updated successfully with back order ID is ${backorder}`)
            this.service.orderData.walletPayment.wallet = null;
            this.service.orderData.walletPayment.card = null;
            this.router.navigate(['/sale/orders'])
          }
          console.log(response)
          //this.router.navigate(['./orders/orders'])
        }, (error) => {
          console.log(error);
        })
    }
   }

   deductBalance(){
     let walletData = {
      "customerId":this.service.orderData.orderDetails.customerId,
      "amountDebit":this.service.orderData.walletPayment.wallet ,
      "amountCredit":0,
      "message":"deducted for placing the new order",
      "type":"Wallet",
      "txnSource":"Admin",
      "txnSourceId":0
  }
     this.service.deductWalletAmount(this.service.orderData.orderDetails.customerId,walletData)
     .subscribe((response)=>{
      console.log(response)
       this.toastr.success("Wallet updated")
     },(error)=>{
       console.log(error)
       this.toastr.error("Issues while updating wallet, Kindly reach out to support team")
     })

   }
}
