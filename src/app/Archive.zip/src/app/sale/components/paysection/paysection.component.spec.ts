import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaysectionComponent } from './paysection.component';

describe('PaysectionComponent', () => {
  let component: PaysectionComponent;
  let fixture: ComponentFixture<PaysectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaysectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaysectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
