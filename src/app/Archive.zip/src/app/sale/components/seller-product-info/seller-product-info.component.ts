import { Component, OnInit } from '@angular/core';
import {PaymentDetailService} from '../../../shared/services/sale/payment-detail.service';
@Component({
  selector: 'app-seller-product-info',
  templateUrl: './seller-product-info.component.html',
  styleUrls: ['./seller-product-info.component.scss']
})
export class SellerProductInfoComponent implements OnInit {

  constructor(public service : PaymentDetailService) { }

  ngOnInit() {
    this.getAllOutStockData()
  }
  products:any;
  getAllOutStockData(){
    this.service.getAllOutStockOrderProducts()
    .subscribe((response)=>{
      this.products = response;
      this.products = this.products.response.result
      console.log(this.products)
    },(error)=>{
      console.log(error)
    })
  }
  getOrderDetail(outId){
    console.log(outId)
    this.products.some((elem)=>{
      console.log(elem)
      if (elem.outOfStockId == outId ){
        if (elem.orderProductStatus == 'Out of Stock'){
          console.log('change status to in stock')
          elem.orderProductStatus = 'In Stock'
        } else if (elem.orderProductStatus = 'In Stock') {
          elem.orderProductStatus = 'Out of Stock'
          console.log('change status to out stock')

        }
        
      }
    })
  }
}
