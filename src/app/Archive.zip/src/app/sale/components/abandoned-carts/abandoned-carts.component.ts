import { Component, OnInit } from '@angular/core';
import { Table } from 'primeng/table';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { AbandonedCartsService } from '../../../shared/services/sale/abandoned-carts.service';
import { pairwise, takeUntil, filter } from 'rxjs/operators';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { DropdownModule } from 'primeng/dropdown';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-abandoned-carts',
  templateUrl: './abandoned-carts.component.html',
  styleUrls: ['./abandoned-carts.component.scss']
})
export class AbandonedCartsComponent implements OnInit {

  abandonedcarts: any = [];
  private _unsubscribe = new Subject<boolean>();
  currentDate: any;
  countries: any;
  countriesData = [];
  constructor(
    private toastr: ToastrService,
    public abandonedCartService: AbandonedCartsService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    public datepipe: DatePipe,
    private commonService: CommonServiceService,
  ) { }

  ngOnInit() {
    Promise.all([this.OnAbandonedCarts()]);
    this.getCountry()
  }

  OnAbandonedCarts() {
    this.abandonedCartService.abandonedCarts()
      .subscribe((response) => {
        let data: any = response;
        data = data.data
        this.abandonedcarts = data;
        this.abandonedcarts.map(i => {
          i.fullName = i.customerDetail.title + " " +
            i.customerDetail.firstName + " " +
            i.customerDetail.lastName;
        })
        this.abandonedcarts.map(i => {
          let todayDate = new Date();
          let sentOnDate = new Date(i.added_date);
          sentOnDate.setDate(sentOnDate.getDate());
          let differenceInTime = todayDate.getTime() - sentOnDate.getTime();
          let differenceInDays = Math.floor(differenceInTime / (1000 * 3600 * 24));
          i.abandonedDays = differenceInDays;

        })

        for (let x in this.abandonedcarts) {
          if (Object.keys(this.abandonedcarts[x].country).length > 0) {
            this.abandonedcarts[x]['countryName'] = this.abandonedcarts[x].country.countryName;
          }

        }

        //console.log(JSON.stringify(this.abandonedcarts))
      }, (error) => {
        console.log(error)
        this.toastr.error("Some error occured")
      })
  }

  OnViewCartDetail(customerId) {
    this.router.navigate([`../view-abandoned-cart`, customerId], { relativeTo: this.activateRoute });
  }

  arrayOfStringsToArrayOfObjects(arr: any[]) {
    const newArray = [];
    if (arr != []) {
      arr.forEach(element => {
        newArray.push({
          label: element.itemName,
          value: element.id
        });
      });
    }
    return newArray;
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = this.arrayOfStringsToArrayOfObjects(success.data);

        for (const key in this.countries) {
          let value = this.countries[key].label.toString()
          this.countriesData.push({ 'label': value, 'value': value });
        }

        //
      },
      error => {
      }
    )
  }

  clearSelection(dropdown) {
    dropdown.updateSelectedOption(null);
  }

  convertToOrder(customerId) {
    let siteType = "admin"
    var customerID = customerId
    console.log(customerID)
    this.abandonedCartService.onConvertToOrder(customerID)
      .subscribe((response) => {
        let msg: any = response;
        msg = msg.response.result.orderNo
        this.toastr.success('New Order ' + msg + ' is created successfully!');
        this.router.navigate(['/sale/orders'])

      }, (error) => {
        console.log(error);
      })
  }

}
