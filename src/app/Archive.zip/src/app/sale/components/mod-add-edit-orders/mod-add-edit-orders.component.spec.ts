import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModAddEditOrdersComponent } from './mod-add-edit-orders.component';

describe('ModAddEditOrdersComponent', () => {
  let component: ModAddEditOrdersComponent;
  let fixture: ComponentFixture<ModAddEditOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModAddEditOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModAddEditOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
