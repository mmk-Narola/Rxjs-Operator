import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../../../shared/services/customers/customer.service';
import { ProductService } from '../../../shared/services/catalogue/product.service';
import { PaymentDetailService } from '../../../shared/services/sale/payment-detail.service';
import { Home } from '../../home.model';
import { product } from '../../product.model';
import { WalletService } from '../../../shared/services/wallet/wallet.service';
import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";
import { NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import { formatDate } from '@angular/common';
import { NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { BaseService } from '../../../shared/services/base.service';
import { isDifferent } from '@angular/core/src/render3/util';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Component({
  selector: 'app-mod-add-edit-orders',
  templateUrl: './mod-add-edit-orders.component.html',
  styleUrls: ['./mod-add-edit-orders.component.scss'],
  providers: [NgbModalConfig, NgbModal, NgbAccordionConfig],
})

export class ModAddEditOrdersComponent implements OnInit {
  closeResult = "";
  lastItem: any;
  lastIndex: any;
  ngTaxAmount: any;
  discountedAmount: any;
  editOnCOD = true;
  dataArrayOnEdit = [];
  backorderId: any;
  displayTableMsg = false;
  couponEntered = '';
  displayPaymentLink = false;
  promoCodeId = null;
  promoCodeStatus = '';
  couponStatus = false;
  couponAppliedStatus = false;
  readonlyLengthBased = true;
  CurrentTime: any;
  today = new Date();
  readOnlyCustomerCountry: any;
  getOrderId: any;
  genPaymentLink: any;
  paymentModeArray: any = [];
  enableFields = false;
  getCancelledIndex = [];
  paymentDetailArray: any;
  checkINV = false;
  checkSOR = false;
  showAddEdit: boolean;
  paymentMethodArray: any = [];
  isPayLater = false;
  ngDeliveryCharge: any;
  ngDiscountCharge: any;
  ngTaxRate: any;
  ngTaxCode: any;
  ngDeliveryChargeId: any;
  adminComment: string;
  deliveryInstruction: string;
  paymentMethod: number;
  isCodMethod = true;
  paymentBalance: any;
  selectedMethodPayment = "cod";
  toBeDeleted = [];
  previousOrderTotal: any;
  currenySymbol: any;
  cancelledProducts = [];
  cancelledProductArray = [];
  outofstockProductArray = [];
  orderRefundArray = [];
  home = new Home();
  dataarray = []
  orderData: any = {}
  product = new product();
  orderType: any // this will tell if the order is new or edit
  fetchOrderDetails: any;
  breadCrumbTitle: any;
  orderNoDisplay: boolean = false;
  editMode: boolean = false
  promoCodeEntered: boolean = false
  promoCodeAllowed: boolean = true;
  selectedDeliveryType: any;
  idx: any;
  encodedIdForCredit: any;
  creditNoteLink: any;
  selectedTax: any
  tIdx: any
  paymentMode = [
    { name: "STRIPE" },
    { name: "NET-BANKING" },
    { name: "CASH" }
  ];
  paymentItem: any
  customerIdForPayment: any
  orderIdForPayment: any
  paymentSuccessful: boolean = false
  amountForPayment: any
  isStripeNetBanking: boolean = false
  incompletePaymentId: boolean = false
  isArchivedValue: boolean = false
  orderStatusValue: any
  isCashPaymentMode: boolean = false
  manualPaymentMode: boolean = false
  isPartiallyPaidOrder: boolean = false;
  isDisableReward: boolean = false;
  disableRewardRegCustomer: boolean = false;
  private _unsubscribe = new Subject<boolean>();
  selectedProductQuantity: number
  productOutOfStock: boolean = true;
  clickedOnSave: boolean = false
  clickedOnYes: boolean = false
  clickedOnCancel: boolean = false
  productId: number
  billingStateList = [];
  isDeliveryBtnClicked: boolean = false;

  config = {
    displayKey: "productName", //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: "auto", //auto //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
    placeholder: "Select Product", // text to be displayed when no item is selected defaults to Select,
    customComparator: () => { }, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
    limitTo: 8, // number thats limits the no of options displayed in the UI (if zero, options will not be limited)
    moreText: "more", // text to be displayed whenmore than one items are selected like Option 1 + 5 more
    noResultsFound: "No results found!", // text to be displayed when no items are found while searching
    searchOnKey: "productName", // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
  };


  constructor(
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private customerService: CustomerService,
    private service: CommonServiceService,
    public paymentService: PaymentDetailService,
    private productService: ProductService,
    private router: Router,
    private walletService: WalletService,
    private modalService: NgbModal,
    private baseService: BaseService,
    private commonService: CommonServiceService
  ) {

    this.orderType = this.route.snapshot.paramMap.get("id")
    this.showAddEdit = true;
    this.CurrentTime = formatDate(this.today, 'yyyy-MM-dd hh:mm:ss', 'en-US', '+0530');


    if (this.orderType == "new") {
      this.paymentService.isActive = false
      this.editMode = false;
      this.commonService.countryEditable = true
      this.commonService.onNewOrder();
      this.orderData.orderDate = new Date().toISOString().split('T')[0]
      this.display = false;
      this.displayTableMsg = false;
      this.breadCrumbTitle = "Create New Order"
      this.checkSOR = true;
      this.paymentService.editActive = false;
      this.editOnCOD = false;
      this.readOnlyCustomerCountry = false;

    } else {
      this.editMode = true
      this.fetchOrderDetails = this.route.snapshot.data['order']
      if (this.route.snapshot.data['order'].response.result[0].promocode == null)
        this.promoCodeEntered = false
      else
        this.promoCodeEntered = true
      this.displayTableMsg = true;
      this.assignData(this.fetchOrderDetails)
      this.getProductData()
      this.getProductStatus()
      this.onGeneratePaymentLink(); // added on 16-june-21
      this.paymentService.editActive = true;
      this.editReadDisplay = true
      this.breadCrumbTitle = `Order Number ${this.orderType}`
      this.orderNoDisplay = true
      this.enableFields = true;
      this.downloadCreditNote();
    }
  }

  productStatus: any
  getProductStatus() {
    this.paymentService.getSingleProductStatus()
      .subscribe((response) => {
        this.productStatus = response;
        this.productStatus = this.productStatus.response.result
      }, (error) => {
        console.log(error)
      })
  }

  open(content) {
    this.getAllProductsData();
    this.defaultValuesForStock();
    this.productSelected = false;
    this.modalService
      .open(content, { ariaLabelledBy: "modal-basic-title", backdrop: 'static', keyboard: false })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;

        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );

  }

  confirmBox() {
    this.commonService.fieldValidations()
    if (!this.isDeliveryBtnClicked) {
      this.toastr.error("Please click on calculate button for delivery charges");
      return
    }
    if (this.selectedMethodPayment == "wallet") {
      this.promoCodeAllowed = false;
      if (parseFloat(this.orderData.total) > parseFloat(this.paymentBalance)) {
        Swal.fire({
          title: 'Alert!',
          text: 'Remaining total amount ' + ((parseFloat(this.orderData.total) - parseFloat(this.paymentBalance)).toFixed(2)).toString() + ' will be considered as COD',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Proceed',
          cancelButtonText: 'Cancel'
        }).then((result) => {
          if (result.value) {
            this.submit()
          } else if (result.dismiss === Swal.DismissReason.cancel) {
            return;
          }
        })

      } else if (this.commonService.emptyFieldsCheck()) {
        this.submit();
      }

    } else if (this.commonService.emptyFieldsCheck()) {
      this.submit();
    }

  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }

  }

  getProductData() {

    let response = this.fetchOrderDetails.response.result[0].orderProducts
    var data: any = response;
    /* check if form is in edit mode and retrieve the data for products */
    if (this.orderType != "new") {
      this.commonService.cancelledOrder = false;
      this.commonService.countryEditable = false
      let initialValue = 0;
      data = response
      this.dataarray = data
      this.showAddEdit = false;
      this.commonService.onNewOrder();
      let sum = this.dataarray.reduce(function (total, currentValue) {
        return (parseFloat(total) + parseFloat(currentValue.total)).toFixed(2);
      }, initialValue);
      this.orderData.productTotal = parseFloat(sum).toFixed(2)
    } if (localStorage.getItem('order-status') == "Cancelled") {
      this.commonService.cancelledOrder = true;
      this.dataarray = this.dataarray.filter(o => o.orderProductStatus === 'Cancelled');
      this.editReadDisplay = true;
      this.display = false;
      return;
    }
    return response;
  }

  cloneOrderData: any;
  orderStatus: any;
  editReadDisplay: boolean = false;
  cancelDisplay: boolean = false;
  ORDER_STATUS: any;

  // this assignData is for edit
  assignData(data: any) {
    data = data.response.result[0]
    this.customerService.getCustomerId(data.customerId).pipe(takeUntil(this._unsubscribe))
      .subscribe((success: any) => {
        (success.data.isDisableReward) ? this.disableRewardRegCustomer = true : this.disableRewardRegCustomer = false;
      })
    if ((data.orderTransactions[0].methodOfPayment.hasOwnProperty("cod") && data.orderTransactions[0].methodOfPayment.hasOwnProperty("wallet")) || data.paymentMode.length == 0)
      this.isPartiallyPaidOrder = true
    else
      this.isPartiallyPaidOrder = false
    this.orderStatusValue = data.orderStatus
    this.isArchivedValue = data.isArchived;
    (data.isDisableReward) ? this.isDisableReward = true : this.isDisableReward = false

    this.cloneOrderData = { ...data }

    if (Object.keys(data.orderTransactions[0].methodOfPayment).length > 0) {
      if (data.orderTransactions[0].methodOfPayment.hasOwnProperty('cod')) {
        if (data.orderTransactions[0].methodOfPayment.cod > 0) {
          this.displayPaymentLink = true;

        }
      }
    }
    if (Object.keys(data.orderTransactions[0].methodOfPayment).length == 1) {
      if (data.orderTransactions[0].methodOfPayment.hasOwnProperty('cod')) {
        this.readOnlyCustomerCountry = false;
        this.editOnCOD = false;
      } else {
        this.readOnlyCustomerCountry = true;
        this.editOnCOD = true;
      }
    } else {
      this.readOnlyCustomerCountry = true;
    }

    if (data.cancelOrder) {
      for (let x of data.cancelOrder) {
        for (let y of x.orderProducts) {
          this.cancelledProductArray.push(y);
        }
      }
    }

    if (data.backOrder) {
      for (let x of data.backOrder) {
        for (let y of x.orderProducts) {
          this.outofstockProductArray.push(y)
        }
      }
    }

    this.orderRefundArray = data.orderRefunds

    if (data.backOrder.length > 0) {
      this.backorderId = data.backOrder[0].orderId;
    }

    this.showAddEdit = false;
    this.getOrderId = data.orderId
    this.orderIdForPayment = data.orderId
    if (data.billingPostcode) {
      this.onBillingPincodeChange(data.billingPostcode, true, data.countryid);
    }
    // this.paymentDetailArray = data.methodOfPayment
    this.paymentDetailArray = data.orderTransactions[0].methodOfPayment

    for (const key in this.paymentDetailArray) {
      if (this.paymentDetailArray.hasOwnProperty(key)) {

        let value = this.paymentDetailArray[key];
        if (Math.floor(value) !== 0) {
          if (key == "paylater") {
            this.isPayLater = true;
          }
          if (key == "cod") {
            this.promoCodeAllowed = true;
            this.paymentMethodArray.push({ "method": key, "value": parseFloat(value).toFixed(2), "type": "Pending" });
            this.commonService.cancelledOrder = false
          } else {
            this.promoCodeAllowed = false;
            this.paymentMethodArray.push({ "method": key, "value": parseFloat(value).toFixed(2), "type": "Paid" });
          }
        }
      }
    }

    for (let x of data.paymentMode) {
      this.paymentModeArray.push(x);
    }

    if (data.paymenttype == "paylater") {
      this.payLaterActive = true
      this.paylaterDisplay = true
      this.otherDisplay = false
    }

    this.orderData.orderNo = data.orderNo
    this.orderStatus = this.orderData.orderNo.substring(0, 3);

    if (this.orderStatus == "INV") {
      this.checkINV = true;
    }

    if (this.orderStatus == "BRD") {
      this.display = true;
      this.checkINV = true;
    } else if (this.orderStatus == "SOR") {
      this.display = true;
      this.checkSOR = true;
    }
    this.ORDER_STATUS = data.orderStatus
    // if (this.ORDER_STATUS != "Delivered" && this.ORDER_STATUS != "Shipped" && this.ORDER_STATUS != "Out of Stock" && this.ORDER_STATUS != "Cancelled") {
    //   this.ORDER_STATUS = "In Stock"
    // }

    // added on 8-6-21
    if (data.orderTransactions[0].productTotal == 0) {
      data.orderTransactions[0].totalAmountWithTax = parseFloat("0.0")
      data.orderTransactions[0].discount = parseFloat("0.0")
      data.orderTransactions[0].tax = parseFloat("0.0")
      data.orderTransactions[0].delieveryCharge = parseFloat("0.0")
      data.orderTransactions[0].taxamount = parseFloat("0.0")
    }
    this.couponEntered = data.promocode
    this.orderData.Email = data.Email
    this.orderData.delieveryCharge = parseFloat(data.orderTransactions[0].delieveryCharge)
    if (this.orderData.delieveryCharge && this.orderData.delieveryCharge >= 0) {
      this.isDeliveryBtnClicked = true;
    } else {
      this.isDeliveryBtnClicked = false;
    }

    this.paymentService.ChangeCustomerName({
      billingAdd: {
        pincode: data.billingPostcode,
        state: this.paymentService.billingAddress.billingState,
        city: this.paymentService.billingAddress.billingCity,
        countryId: data.countryid
      },
      delivaryAdd: {
        pincode: this.paymentService.shippingAddress.shippingPostcode,
        state: this.paymentService.shippingAddress.shippingState,
        city: this.paymentService.shippingAddress.shippingCity,
        countryId: data.countryid
      }
    } || {});

    this.orderData.delieveryType = data.orderTransactions[0].delieveryType
    this.orderData.card = parseFloat(data.orderTransactions[0].methodOfPayment.card)
    this.orderData.wallet = parseFloat(data.orderTransactions[0].methodOfPayment.wallet)
    this.orderData.cod = parseFloat(data.orderTransactions[0].methodOfPayment.cod)
    this.orderData.customerId = data.customerId
    this.customerIdForPayment = data.customerId
    this.orderData.mobileNumber = data.mobileNumber
    this.paymentService.shippingAddress.shippingClinicName = data.shippingClinicName
    this.paymentService.billingAddress.billingClinicName = data.billingClinicName
    this.paymentService.billingAddress.billingBlockNo = data.billingBlockNo
    this.paymentService.billingAddress.billingBuildingName = data.billingBuildingName
    this.paymentService.billingAddress.billingFloorNo = data.billingFloorNo
    this.paymentService.billingAddress.billingStreetName = data.billingStreetName
    this.paymentService.billingAddress.billingUnitNo = data.billingUnitNo
    this.paymentService.billingAddress.billingState = data.billingState
    this.paymentService.billingAddress.billingCity = data.billingCity
    this.paymentService.shippingAddress.shippingPostcode = data.shippingPostcode
    this.paymentService.shippingAddress.shippingBuildingName = data.shippingBuildingName
    this.paymentService.shippingAddress.shippingFloorNo = data.shippingFloorNo
    this.paymentService.shippingAddress.shippingStreetName = data.shippingStreetName
    this.paymentService.shippingAddress.shippingUnitNo = data.shippingUnitNo
    this.paymentService.shippingAddress.shippingState = data.shippingState
    this.paymentService.shippingAddress.shippingCity = data.shippingCity
    this.paymentService.billingAddress.billingPostcode = data.billingPostcode
    this.orderData.deliveryInstruction = data.deliveryInstruction
    this.orderData.adminComment = data.adminComment
    this.orderData.total = parseFloat(data.orderTransactions[0].totalAmountWithTax)
    this.amountForPayment = this.orderData.total
    this.orderData.productTotal = parseFloat(data.orderTransactions[0].productTotal) //pending change
    this.orderData.taxpercent = parseFloat(data.orderTransactions[0].tax)
    this.orderData.country = data.countryid
    this.orderData.taxCode = parseInt(data.orderTransactions[0].taxCode)
    this.orderData.discount = data.orderTransactions[0].discount
    this.orderData.orderDate = new Date(data.orderDate).toISOString().split('T')[0]
    this.orderData.taxAmount = parseFloat(data.orderTransactions[0].taxamount)
    this.orderData.customPONumber = data.customPONumber,
      this.orderData.paymentTermDays = data.paymentTermDays,
      this.cancelDisplay = true;
    this.totalTaxDisplay = true
    this.getWalletBalance(data.customerId);
    this.getPaylaterAndWalletBalance(data.customerId)
    this.previousOrderTotal = this.orderData.total;

  }
  payLaterActive: boolean = false;
  otherDisplay: boolean = true;
  paylaterDisplay: boolean = false;
  dueDate: any = null;
  productSelected: boolean = false;

  ngOnInit() {
    this.paymentItem = {
      "paymentMode": "",
      "referenceId": "",
      "orderId": "",
      "customerId": "",
      "amount": ""
    }
    this.isStripeNetBanking = false
    this.commonService.valueChanged = false
    this.product = new product();
    // this.dataarray.push(this.home)
    Promise.all([this.getAllCountries(), this.getAllCustomers(1), this.getAllProductsData()
    ])
    this.incompletePaymentId = false
  }
  /* this function will get all the countries*/


  countryData: any;
  countryDisplay: boolean = true;
  getAllCountries() {
    this.service.getCountry().subscribe((response) => {
      this.countryData = response;
      this.countryData = this.countryData.data

      if (this.orderType != "new") {
        //orderData.country
        this.countryData.some((elem) => {
          if (this.orderData.country == elem.id) {
            this.orderData.country = elem
            this.getDeleiveryData(elem.id)
            this.fillTaxWithCountry(elem)
          }
        })
      }
    }, (error) => {
      this.toastr.error(error.message)
    })
  }
  /* get all delievery data */
  delieveryData: any
  getDeleiveryData(countryid) {
    this.commonService.getCountryInfo();
    this.commonService.selectedCountry = countryid;
    this.commonService.maxLength = this.commonService.countryMaxLenMap.get(countryid)
    this.commonService.getMaxLength();
    this.countryData.some((elem) => {
      if (elem.id == countryid) {
        this.delieveryData = elem.deliveryCharge //this.delieveryData.data.Detail
        if (this.orderType == "new") {
          for (var i = 0; i < this.delieveryData.length; i++) {
            if (this.delieveryData[i].isDefault == 1) {
              this.selectedDeliveryType = this.delieveryData[i].title
              this.orderData.delieveryType = this.selectedDeliveryType
              this.idx = i;
            }
          }
        }
        if (this.orderType == "new") {
          this.ngDeliveryCharge = parseFloat(this.delieveryData[this.idx]['deliveryCharge'] || 0.00);
          this.orderData.delieveryCharge = parseFloat(this.delieveryData[this.idx]['deliveryCharge'] || 0.00)
          this.orderData.delieveryType = parseInt(this.delieveryData[this.idx]['id'])
        }

      }
    })
  }

  /* get all customer data */
  customerData: any;
  getAllCustomers(countryId) {
    this.customerService.getCountryCustomers(null, countryId) // (0)
      .subscribe((response) => {
        this.customerData = response;
        this.customerData = this.customerData.data.results
        this.customerData.map(i => {
          i.fullName = i.title + " " + i.firstName + " " + i.lastName + " " + " - " + i.Email
        })
        if (this.orderType != "new") {
          this.customerData.some((elem) => {
            if (elem.customerId == this.orderData.customerId) {
              this.orderData.customerName = elem
            }
          })
        }

      }, (error) => {
        this.toastr.error(error.message)
      })
  }
  /* this section will get all product data */
  productData: any;
  getAllProductsData() {
    /* to do country id */
    this.productService.getAllRegisteredProducts(this.countryId).subscribe((response) => {
      this.productData = response
      this.productData = this.productData.data
    }, (error) => {
      this.toastr.error(error.message)
    })
  }

  addFieldHome() {
    this.home = new Home()
    this.dataarray.push(this.home)
    this.lastItem = this.dataarray[this.dataarray.length - 1];
    this.lastIndex = this.dataarray.length - 1;
    this.readonlyLengthBased = false;
    this.isDeliveryBtnClicked = false;
  }

  delete() {
    let tempTotal = [];
    // if (!this.toBeDeleted.length) {
    //   alert('Choose at least one!');
    // } else if (this.toBeDeleted.length === this.dataarray.length) {
    //     alert('You cannot delete all rows')
    // } 

    this.dataarray = this.dataarray.filter((currentValue, index, arr) => !this.toBeDeleted.includes(index));

    this.findTaxData()
    // added
    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.total);
    });
    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);
    // ends

    this.orderData.taxAmount = (((parseFloat(this.orderData.productTotal) +
      parseFloat(this.orderData.delieveryCharge) -
      parseFloat(this.orderData.discount)) *
      parseFloat(this.orderData.taxpercent)) / 100)

    this.orderData.total = (parseFloat(this.orderData.taxAmount) +
      parseFloat(this.orderData.delieveryCharge) +
      parseFloat(this.orderData.productTotal) -
      parseFloat(this.orderData.discount)).toFixed(2);


    // reset the array
    this.toBeDeleted = [];
    this.isDeliveryBtnClicked = false;
  }

  removeSelected(event, index) {
    // check if checkbox is checked, if so, push to array, else delete from array
    if (event.target.checked) {
      this.toBeDeleted.push(index)
    } else {
      const idx = this.toBeDeleted.indexOf(index);
      this.toBeDeleted.splice(idx, 1)
    }
  }


  encodedId(id) {
    return btoa(id);
  }

  onGeneratePaymentLink() {
    let encodedOrderId = this.encodedId(this.getOrderId);
    this.genPaymentLink = this.baseService.baseUrl + "paynow/" + (encodedOrderId).toString();
  }

  removeHomeField(idx) {
    // this.dataarray[this.lastIndex].pop();
    this.readonlyLengthBased = isNaN(this.orderData.length) ? true : false;

    let tempTotal = [];

    {
      this.dataarray.splice(this.lastIndex, 1)
      this.findTaxData()
      // added
      this.dataarray.forEach((elem) => {
        tempTotal.push(elem.total);
      });
      var sum = tempTotal.reduce(function (a, b) {
        return +a + +b;
      }, 0);

      // ends

      this.orderData.taxAmount = (((parseFloat(this.orderData.productTotal) +
        parseFloat(this.orderData.delieveryCharge) -
        parseFloat(this.orderData.discount)) *
        parseFloat(this.orderData.taxpercent)) / 100)

      this.orderData.total = (parseFloat(this.orderData.taxAmount) +
        parseFloat(this.orderData.delieveryCharge) +
        parseFloat(this.orderData.productTotal) -
        parseFloat(this.orderData.discount)).toFixed(2);
    }

    this.isDeliveryBtnClicked = false

  }
  removeHome(index) {

    this.readonlyLengthBased = isNaN(this.orderData.length) ? true : false;

    let tempTotal = [];
    {
      this.dataarray.splice(index, 1)
      this.findTaxData()
      // added
      this.dataarray.forEach((elem) => {
        tempTotal.push(elem.total);
      });
      var sum = tempTotal.reduce(function (a, b) {
        return +a + +b;
      }, 0);

      // ends

      this.orderData.taxAmount = (((parseFloat(this.orderData.productTotal) +
        parseFloat(this.orderData.delieveryCharge) -
        parseFloat(this.orderData.discount)) *
        parseFloat(this.orderData.taxpercent)) / 100)

      this.orderData.total = (parseFloat(this.orderData.taxAmount) +
        parseFloat(this.orderData.delieveryCharge) +
        parseFloat(this.orderData.productTotal) -
        parseFloat(this.orderData.discount)).toFixed(2);
    }
  }

  /* product quantity price change detection */
  detectChangeProduct(value, v1) {
    this.commonService.valueChanged = true
    this.onChangeRemovePromo();
    let tempTotal = [];
    this.productData.some((elem) => {
      if (elem.productId == value.value.productId) {
        this.dataarray[v1].quantity = 1
        this.dataarray[v1].price = parseFloat(elem.MRP)
        this.dataarray[v1].total = this.dataarray[v1].price.toFixed(2) * this.dataarray[v1].quantity.toFixed(2)
        this.dataarray[v1].discount = 0;
        this.dataarray[v1].productId = elem.productId
        this.dataarray[v1].orderProductStatus = 'In Stock'
        this.dataarray[v1].cancelReason = elem.cancelReason
        this.dataarray[v1].productName = elem.productName
        this.dataarray[v1].sellerName = elem.sellerProducts[0].sellerDetail.sellerName
        this.dataarray[v1].sellerId = elem.sellerProducts[0].sellerDetail.id
        this.dataarray[v1].sellerfee = elem.sellerProducts[0].sellerFee;
        this.dataarray[v1].shipped_at = null;
        this.dataarray[v1].delivery_at = null;
        this.dataarray[v1].pncode = elem.PNCDE
        this.dataarray[v1].type = "sub"
        this.selectedProductQuantity = elem.sellerProducts[0].quantity
        this.productId = this.dataarray[v1].productId
        if (elem.productName.length != 0)
          this.productSelected = true
        // added
        this.dataarray.forEach((elem) => {
          tempTotal.push(elem.total);
        });
        var sum = tempTotal.reduce(function (a, b) {
          return +a + +b;
        }, 0);
        sum = parseFloat(sum).toFixed(2);
        this.orderData.productTotal = sum;
        // ends
      }
    })
  }
  /* detect change price */
  detectChangePrice(value, vl) {
    this.commonService.valueChanged = true
    this.onChangeRemovePromo();
    value = parseFloat(value);
    let tempTotal = []
    this.dataarray[vl].total = (parseFloat(this.dataarray[vl].quantity) * parseFloat(value)).toFixed(2)
    //added
    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.total);
    });

    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);
    sum = parseFloat(sum).toFixed(2);
    this.orderData.productTotal = sum;
    //added ends
    this.paymentService.taxDetailsData.productTotal = sum;
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    // this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal * 10 / 100  // check this code
    // this.paymentService.taxDetailsData.taxAmount =   parseFloat(this.paymentService.taxDetailsData.taxAmount).toFixed(2)
    // this.paymentService.taxDetailsData.total = parseFloat(this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal).toFixed(2)
    // added this function
    // this.changeProductStatus(this.dataarray[vl].orderProductStatus, vl, {});
    this.onChangeBilling();
  }

  onChangePaymentMethod(event: any) {
    this.commonService.valueChanged = true
    this.paymentMethod = event.target.value;
    if (isNaN(this.orderData.total)) {
      this.orderData.total = 0.0
    }

    if (parseFloat(this.payLaterBalance) >= parseFloat(this.orderData.total)) {
      this.paylaterDisplay = true;
      this.payLaterActive = true;
    } else {
      this.paylaterDisplay = false;
      this.payLaterActive = false;
    }

    if (event.target.value === "cod") {
      this.isCodMethod = true;
      this.promoCodeAllowed = true;
      // this.orderData.cod = parseFloat(this.orderData.total);
    } else {
      this.isCodMethod = false;
    }

    if (event.target.value === "paylater") {
      this.promoCodeAllowed = false;
      if (isNaN(this.payLaterBalance)) {
        this.payLaterBalance = 0.0
      }

      if (parseFloat(this.payLaterBalance) >= parseFloat(this.orderData.total)) {
        this.paymentBalance = parseFloat(this.payLaterBalance).toFixed(2);
        // this.orderData.cod = 0.0
      }
      this.payLaterActive = true;
      if (this.payLaterActive == true) {
        // this.dueDate = new Date()
        // this.dueDate = this.dueDate.setDate(this.dueDate.getDate() + 90)
        // this.dueDate = new Date(this.dueDate)

      } else {
        // this.dueDate = null;
      }

    }

    if (event.target.value == "wallet") {
      this.promoCodeAllowed = false;
      if (isNaN(this.walletSummary)) {
        this.walletSummary = 0.0;
      }
      this.paymentBalance = parseFloat(this.walletSummary).toFixed(2);
      // this.paymentBalance = parseFloat(this.orderData.wallet).toFixed(2);
    }
  }

  /* quantity detection */
  quantityDetectChange(value, vl) {
    this.commonService.valueChanged = true
    this.onChangeRemovePromo();
    let tempTotal = []
    this.dataarray[vl].total = (parseFloat(this.dataarray[vl].price) * parseFloat(value)).toFixed(2)
    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.total)
    });
    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);
    sum = parseFloat(sum).toFixed(2);

    this.orderData.productTotal = sum; // added on 2 june 2021
    this.paymentService.taxDetailsData.productTotal = sum;
    this.paymentService.productDetailArray = this.dataarray;
    this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal * 10 / 100
    this.paymentService.taxDetailsData.taxAmount = parseFloat(this.paymentService.taxDetailsData.taxAmount).toFixed(2)
    this.paymentService.taxDetailsData.total = parseFloat(this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal).toFixed(2)
    this.onChangeBilling();
    this.isDeliveryBtnClicked = false;
  }

  /* simplify tax related data */
  findTaxData() {
    let initialValue = 0;
    let sum = this.dataarray.reduce(function (total, currentValue) {
      return total + currentValue.total;
    }, initialValue);
    this.orderData.productTotal = parseFloat(sum).toFixed(2)
    if (this.orderType == "new" && this.orderData.productTotal) {
      this.display = true;
    } else if (this.orderType == "new" && !this.orderData.productTotal) {
      this.display = false;
    }

  }

  showTotal() {
    if (this.taxCodeByUser && this.orderData.delieveryCharge) {
      this.totalTaxDisplay = true;
    } else {
      this.totalTaxDisplay = false;
    }
  }
  taxCodeByUser: any;
  totalTaxDisplay: boolean = false;

  taxChangeDetect(value) {
    this.commonService.valueChanged = true
    this.taxData.some((elem) => {
      if (elem.id == value) {
        this.orderData.taxpercent = parseFloat(elem.taxRate);
        if (this.orderData.delieveryCharge) {
          this.orderData.taxAmount = (((parseFloat(this.orderData.productTotal) + parseFloat(this.orderData.delieveryCharge) - parseFloat(this.orderData.discount)) * parseFloat(this.orderData.taxpercent)) / 100).toFixed(2) //+ this.orderData.delieveryCharge + this.orderData.taxpercent
          this.orderData.total = (parseFloat(this.orderData.taxAmount) + parseFloat(this.orderData.delieveryCharge) + parseFloat(this.orderData.productTotal) - parseFloat(this.orderData.discount)).toFixed(2);
          this.showTotal()
        }
        this.taxCodeByUser = elem.id;
      }
    })
    this.showTotal();

    this.onChangeBilling()
  }


  onChangeBilling() {

    var selectPaymentMethod = ((<HTMLInputElement>document.getElementById("paymentMethod")).value);
    var taxType = ((<HTMLInputElement>document.getElementById("taxType")).value);
    var deliveryType = ((<HTMLInputElement>document.getElementById("deliveryType")).value);

    if (taxType == "") {
      this.orderData.taxCode = 1
      this.orderData.taxpercent = 6
    }
    if (deliveryType == "") {
      this.orderData.delieveryType = 1
      this.orderData.delieveryCharge = 0.0
    }
    var discountVal = parseFloat((<HTMLInputElement>document.getElementById("discount")).value).toFixed(2);
    var taxValue = parseFloat((<HTMLInputElement>document.getElementById("tax")).value).toFixed(2);

    if (isNaN(parseFloat(discountVal))) {
      discountVal = '0.0'
      this.orderData.discount = 0.0
    }

    if (this.orderData.productTotal == 0.0) {
      this.orderData.delieveryCharge = 0.0;
      this.orderData.discount = 0.0
    }

    // else {
    //   this.orderData.delieveryCharge = ((<HTMLInputElement>document.getElementById("deliveryCharges")).value);
    // }
    this.orderData.taxAmount = (((parseFloat(this.orderData.productTotal) + parseFloat(this.orderData.delieveryCharge) - parseFloat(this.orderData.discount)) * parseFloat(this.orderData.taxpercent)) / 100).toFixed(2) //+ this.orderData.delieveryCharge + this.orderData.taxpercent
    this.orderData.total = (parseFloat(this.orderData.taxAmount) + parseFloat(this.orderData.delieveryCharge) + (parseFloat(this.orderData.productTotal) - parseFloat(this.orderData.discount))).toFixed(2)

    if (parseFloat(this.payLaterBalance) >= parseFloat(this.orderData.total)) {
      this.paylaterDisplay = true;
    } else {
      this.paylaterDisplay = false;
      this.paymentBalance = 0.0
      this.selectedMethodPayment = "cod";
      this.promoCodeAllowed = true;
    }
  }


  extractTax(data) {
    this.commonService.valueChanged = true
    this.delieveryData.some((elem) => {
      if (elem.id == data) {
        this.orderData.delieveryCharge = parseFloat(elem.deliveryCharge);
      }
    })

    if (isNaN(this.orderData.total)) {
      this.orderData.total = 0.0;
    }

    if (this.payLaterBalance >= this.orderData.total) {
      this.paylaterDisplay = true;
    }
    this.showTotal()
    this.onChangeBilling()
  }

  taxData: any;
  countryName: any;
  countryId: any;
  taxType: any;

  fillTaxWithCountry(data) {
    this.currenySymbol = data.countryCurrency.symbol;
    this.taxData = data.tax
    this.countryName = data.itemName
    this.countryId = data.id

    if (this.orderType == "new") {
      for (var j = 0; j < this.taxData.length; j++) {
        if (this.taxData[j].isDefault == 1) {
          this.selectedTax = this.taxData[j].taxCode
          this.orderData.taxCode = this.selectedTax
          this.tIdx = j;
        }
      }
    }

    if (this.orderType == "new") {
      if (this.taxData && this.taxData.length > 0) {
        this.orderData.taxCode = this.taxData[this.tIdx].id
        this.orderData.taxpercent = this.taxData[this.tIdx].taxRate
      }
    }
  }

  /* detect change in products */
  inStockArr: any;
  cancelArr: any;
  outStock: any;
  changeProductStatus(data, idx, obj) {
    this.commonService.valueChanged = true
    data = data.toLowerCase()

    if (data == "shipped") {
      this.commonService.cancelledOrder = false;
      this.dataarray[idx].shipped_at = this.CurrentTime;
    }

    if (data == "delivered") {
      this.commonService.cancelledOrder = false;
      this.dataarray[idx].delivery_at = this.CurrentTime;
    }

    if (data == "cancelled") {
      this.commonService.cancelledOrder = true;
      if (!this.getCancelledIndex.includes(idx)) {
        this.getCancelledIndex.push(idx);
      }
    }

    if (data == "cancelled" || data == "out of stock") {
      if (data == "out of stock") {
        if (this.cancelledProducts.includes(idx)) {
          this.dataarray[idx].cancelReason = null; // added on 10-6-21
          //delete this.getCancelledIndex[idx]; 
          this.getCancelledIndex = this.getCancelledIndex.filter(item => item !== idx); // // added on 10-6-21
          return;
        }
      }
      if (this.cancelledProducts.includes(idx)) {
        return;
      }
      else {
        this.cancelledProducts.push(idx);
        var sumTemp = parseFloat('0');
        sumTemp = parseFloat(obj.total);
        // for(let i = 0; i < this.dataarray.length; i++){
        //   for(let j = 0; j < this.cancelledProducts.length; j++){
        //     if(i == this.cancelledProducts[j]){
        //       debugger;
        //       sumTemp = parseFloat(this.dataarray[i].total);
        //     }
        //   }
        // }

        this.orderData.productTotal = (parseFloat(this.orderData.productTotal) - sumTemp).toFixed(2);

        if (this.orderData.productTotal < 0) {
          this.orderData.productTotal = 0.0
        }

        this.onChangeBilling();
      }
    } else {


      if (this.getCancelledIndex.includes(idx)) {
        this.getCancelledIndex = this.getCancelledIndex.filter(item => item !== idx);
      }

      if (this.dataarray[idx].cancelReason != null) {
        this.dataarray[idx].cancelReason = null;
      }

      if (this.cancelledProducts.includes(idx)) {
        this.cancelledProducts.forEach((element, index) => {
          if (element == idx) {
            this.orderData.productTotal = (parseFloat(this.orderData.productTotal) + parseFloat(this.dataarray[idx].total)).toFixed(2);
            delete this.cancelledProducts[index];
            //this.cancelledProducts = this.getCancelledIndex.filter(item => item !== index);
          }
        });
      }
      this.onChangeBilling();
    }

    this.inStockArr = this.dataarray.filter(o => o.orderProductStatus === 'In Stock');
    this.cancelArr = this.dataarray.filter(o => o.orderProductStatus === 'Cancelled');
    this.outStock = this.dataarray.filter(o => o.orderProductStatus === 'Out of Stock');
    // this.orderData.card = this.cloneOrderData.orderTransactions[0].methodOfPayment.card  // commented on on 04-6-21

    if (this.orderStatus == "BRD" && this.cancelArr.length == 0 && this.outStock.length == 0 && this.inStockArr.length > 0) {
      this.display = true;
    }

    if (this.orderStatus == "SOR") {
      this.display = true;
    }

    if (this.orderStatus == "BRD" && this.cancelArr.length > 0) {
      this.toastr.info(`Can't change the status to cancel as the order is back order.`)
      return;
    }
  }


  display: boolean = false

  cancelAllOrder() {
    let listOfProdIds: any = []
    for (const item of this.dataarray) {
      listOfProdIds.push(item.productId)
    }
    let data = {
      orderDetails: {
        Email: this.orderData.Email,
        mobileNumber: this.orderData.mobileNumber,
        billingClinicName: this.paymentService.billingAddress.billingClinicName,
        billingPostcode: this.paymentService.billingAddress.billingPostcode,
        billingBuildingName: this.paymentService.billingAddress.billingBuildingName,
        billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
        billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
        billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
        billingStreetName: this.paymentService.billingAddress.billingStreetName,
        billingState: this.paymentService.billingAddress.billingState,
        customerId: this.orderData.customerId,
        customerName: this.orderData.customerName.firstName + this.orderData.customerName.lastName,
        orderStatus: this.orderStatus || "Pending", // added on 19-5-21
        shippingClinicName: this.paymentService.shippingAddress.shippingClinicName,
        shippingBuildingName: this.paymentService.shippingAddress.shippingBuildingName,
        shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
        shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
        shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
        shippingStreetName: this.paymentService.shippingAddress.shippingStreetName,
        shippingState: this.paymentService.shippingAddress.shippingState,
        shippingCountry: this.countryName,
        country: this.countryName,
        //      paymenttype:paymenttype,
        countryid: this.countryId,
        shippingPostcode: this.paymentService.shippingAddress.shippingPostcode,
        orderDate: this.orderData.orderDate

      },
      productData: this.dataarray,
      walletPayment: {
        listOfProductIds: JSON.stringify(listOfProdIds),
        productTotal: this.orderData.productTotal,
        totalAmountWithTax: this.orderData.total,
        tax: this.orderData.taxpercent,
        taxCode: this.taxCodeByUser,
        delieveryType: this.orderData.delieveryType,
        delieveryCharge: this.orderData.delieveryCharge,
        userpreference: "not mentioned",
        methodOfPayment: {
          card: this.orderData.card,
          wallet: this.orderData.wallet,
          cod: this.orderData.cod,
        },
      }
    }
    this.paymentService.cancelOrderById(data, this.orderType)
      .subscribe((response) => {
        this.toastr.success("Order has been cancelled successfully!!")
        this.router.navigate(['/sale/orders'])
      }, (error) => {
        console.log(error)
      })

  }
  data
  /* refund process */
  refundAmount = (cancelTax) => {
    if (parseFloat(this.orderData.wallet) >= parseFloat(this.orderData.card)) {
      if (parseFloat(this.orderData.wallet) <= parseFloat(cancelTax)) {
        let difference = cancelTax - parseFloat(this.orderData.wallet)
        this.orderData.card = parseFloat(this.orderData.card) - difference
        this.orderData.card = this.orderData.card //+ parseFloat(this.orderData.delieveryCharge)
        this.orderData.wallet = 0
        //return this.computeData;
      } if (parseFloat(this.orderData.wallet) >= parseFloat(cancelTax)) {
        this.orderData.wallet = parseFloat(this.orderData.wallet) - parseFloat(cancelTax)
        this.orderData.wallet = this.orderData.wallet //+ parseFloat(this.orderData.delieveryCharge)
        //return this.computeData
      }
    } else {
      if (parseFloat(this.orderData.card) <= parseFloat(cancelTax)) {
        let difference = cancelTax - parseFloat(this.orderData.card)
        this.orderData.wallet = parseFloat(this.orderData.wallet) - difference
        this.orderData.wallet = this.orderData.wallet //+ parseFloat(this.orderData.delieveryCharge)
        this.orderData.card = 0
        //return this.computeData;
      }
      if (parseFloat(this.orderData.card) >= parseFloat(cancelTax)) {
        this.orderData.card = parseFloat(this.orderData.card) - parseFloat(cancelTax)
        this.orderData.card = this.orderData.card //+ parseFloat(this.orderData.delieveryCharge)
        //return this.computeData
      }
    }
  }
  calculateTax = (arr, tax) => {
    var productTotal = arr.reduce(function (prev, cur) {
      return prev + cur.total;
    }, 0);

    let totalAmountWithTax = productTotal * tax / 100;
    totalAmountWithTax = totalAmountWithTax + productTotal
    return totalAmountWithTax;
  }

  /* customer name change reflection */
  customerDataChangeDetect(data) {
    this.commonService.valueChanged = true
    this.orderData.customerId = data.customerId
    this.orderData.Email = data.Email
    this.orderData.mobileNumber = data.mobileNumber
    this.paymentService.billingAddress.billingClinicName = data.clinicName
    this.paymentService.billingAddress.billingBuildingName = data.buildingName
    this.paymentService.billingAddress.billingBlockNo = data.houseNo
    this.paymentService.billingAddress.billingFloorNo = data.floorNo
    this.paymentService.billingAddress.billingUnitNo = data.unitNo
    this.paymentService.billingAddress.billingStreetName = data.streetName
    this.paymentService.billingAddress.billingState = data.state
    this.paymentService.billingAddress.billingCity = data.city
    this.paymentService.billingAddress.billingPostcode = data.pincode
    this.paymentService.ChangeCustomerName({
      billingAdd: {
        pincode: data.pincode,
        state: this.paymentService.billingAddress.billingState,
        city: this.paymentService.billingAddress.billingCity,
        countryId: data.countryid
      },
      delivaryAdd: {
        pincode: data.customerAddress.zip,
        state: data.customerAddress.state,
        city: data.customerAddress.city,
        countryId: data.countryid
      }
    } || {});
    this.paymentService.shippingAddress.shippingClinicName = (data.customerAddress == null) ? "" : data.customerAddress.clinicName
    this.paymentService.shippingAddress.shippingBuildingName = (data.customerAddress == null) ? "" : data.customerAddress.buildingName
    this.paymentService.shippingAddress.shippingBlockNo = (data.customerAddress == null) ? "" : data.customerAddress.blockNo
    this.paymentService.shippingAddress.shippingFloorNo = (data.customerAddress == null) ? "" : data.customerAddress.floorNo
    this.paymentService.shippingAddress.shippingUnitNo = (data.customerAddress == null) ? "" : data.customerAddress.unitNo
    this.paymentService.shippingAddress.shippingStreetName = (data.customerAddress == null) ? "" : data.customerAddress.streetName
    this.paymentService.shippingAddress.shippingState = (data.customerAddress == null) ? "" : data.customerAddress.state
    this.paymentService.shippingAddress.shippingCity = (data.customerAddress == null) ? "" : data.customerAddress.city
    this.paymentService.shippingAddress.shippingPostcode = (data.customerAddress == null) ? "" : data.customerAddress.zip
    this.getWalletBalance(this.orderData.customerId)
    this.getPaylaterAndWalletBalance(this.orderData.customerId)
    this.commonService.billingPincode = data.pincode;

    if (this.paymentService.billingAddress['billingPostcode']) {
      this.onBillingPincodeChange(this.paymentService.billingAddress.billingPostcode, true, data.countryid);
    }

    if (data.isDisableReward) {
      this.disableRewardRegCustomer = true
      this.isDisableReward = true
    }
    else
      this.disableRewardRegCustomer = false
  }

  onBillingPincodeChange(event, isDefault, countryId) {
    return new Promise((resolve, reject) => {
      const pincode = isDefault ? event : event.target.value;
      this.paymentService.getStateByPincode(countryId, pincode).toPromise().then(res => {
        if (res && res['data'].length > 0) {
          this.billingStateList = res['data'];
        } else {
          this.billingStateList = [];
        }
        resolve(200);
      }).catch(err => { resolve(200); });
    });
  }

  payLaterBalance: any
  getPaylaterAndWalletBalance(id) {
    this.walletService.singleCustomerWhoUseWallet(id)
      .subscribe((response) => {
        this.payLaterBalance = response;
        this.payLaterBalance = this.payLaterBalance.data
        this.payLaterBalance = this.payLaterBalance.PAY32BNPL.pay32bnpl
      }, (error) => {
        console.log(error)
      })
  }

  walletSummary: any;
  getWalletBalance(customerId) {
    this.paymentService.getWalletDetails(customerId)
      .subscribe((response) => {
        this.walletSummary = response;
        this.walletSummary = parseFloat(this.walletSummary.data.wallet);
      }, (error) => {
        console.log(error)
      })
  }

  overlayDisplay: boolean = true
  submit() {

    // added on 18-may-21
    if (this.dataarray.length == 0) {
      this.toastr.error(
        "Please select a product before submitting",
        "Warning"
      );
      return;
    }

    if (this.orderData.total < 0) {
      this.toastr.error(
        "Total amount can't be negative",
        "Warning"
      );
      return;
    }


    // if wallet amount is zero, then user cannot place order
    var paymentMethod = ((<HTMLInputElement>document.getElementById("paymentMethod")).value);

    if (paymentMethod == "wallet") {


      if (this.paymentBalance <= 0) {
        this.toastr.error(
          "Not enough balance in wallet, please select another payment method.",
          "Warning"
        );
        return;
      }
    }

    this.overlayDisplay = false
    if (this.orderType == 'new') {
      this.insertNewOrder();
      this.router.navigate(['/sale/orders'])
      return;
    }
    // else if (this.orderType != 'new' && this.orderStatus == "BRD") {
    //   /* to do create the api to change the status */
    //   this.toastr.show("updating the back order status")
    //   this.updateStatusBackOrder();
    //   this.router.navigate(['/sale/orders'])
    //   return;
    // } 
    else {
      //this.toastr.show("Update the order")
      this.updateExistingOrder()
      this.router.navigate(['/sale/orders'])
      return;
    }
  }

  /* this function will update back order */
  updateStatusBackOrder() {
    this.paymentService.updateBackOrderStatus(this.dataarray, this.orderType)
      .subscribe((response) => {
        console.log(response)
      }, (error) => {
        console.log(error)
      })
  }
  //updateBackOrderStatus()
  insertNewOrder() {

    let listOfProdIds: any = []
    let methodPaymentFinal: any = {}

    for (const item of this.dataarray) {
      listOfProdIds.push(item.productId)
    }
    var paymenttype: any

    var paymentMethod = ((<HTMLInputElement>document.getElementById("paymentMethod")).value);

    //add code for payment-method
    switch (paymentMethod) {
      case "cod":
        this.orderData.cod = parseFloat(this.orderData.total).toFixed(2);
        methodPaymentFinal = {
          cod: this.orderData.cod
        }

        paymenttype = "cod"
        break;
      case "wallet":
        if (parseFloat(this.walletSummary) >= parseFloat(this.orderData.total)) {
          this.orderData.wallet = parseFloat(this.orderData.total).toFixed(2);
          methodPaymentFinal = {
            wallet: this.orderData.wallet
          }
        } else {
          this.orderData.cod = (parseFloat(this.orderData.total) - parseFloat(this.walletSummary)).toFixed(2);
          this.orderData.wallet = parseFloat(this.walletSummary).toFixed(2);
          methodPaymentFinal = {
            cod: this.orderData.cod,
            wallet: this.orderData.wallet
          }

        }
        paymenttype = "prepaid"
        break;
      case "paylater":
        paymenttype = "paylater"
        this.orderData.paylater = parseFloat(this.orderData.total).toFixed(2);
        methodPaymentFinal = {
          paylater: this.orderData.paylater
        }
        this.dueDate = new Date();
        this.dueDate = this.dueDate.setDate(this.dueDate.getDate() + 90);
        this.dueDate = new Date(this.dueDate);

        break;

      default:
        this.orderData.cod = parseFloat(this.orderData.total).toFixed(2);
        methodPaymentFinal = {
          cod: this.orderData.cod
        }
        paymenttype = "cod"
        break;
    }


    if (!isNaN(this.orderData.wallet)) {
      this.orderData.wallet = parseFloat(this.orderData.wallet).toFixed(2)
    }
    if (!isNaN(this.orderData.cod)) {
      this.orderData.cod = parseFloat(this.orderData.cod).toFixed(2);
    }
    if (!isNaN(this.orderData.paylater)) {
      this.orderData.paylater = parseFloat(this.orderData.paylater).toFixed(2);
    }
    if (!isNaN(this.orderData.card)) {
      this.orderData.card = parseFloat(this.orderData.card).toFixed(2);
    }

    let data: any = {
      orderDetails: {
        Email: this.orderData.Email,
        mobileNumber: this.orderData.mobileNumber,
        billingClinicName: this.paymentService.billingAddress.billingClinicName,
        billingPostcode: this.paymentService.billingAddress.billingPostcode,
        billingBuildingName: this.paymentService.billingAddress.billingBuildingName,
        billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
        billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
        billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
        billingStreetName: this.paymentService.billingAddress.billingStreetName,
        billingState: this.paymentService.billingAddress.billingState,
        customerId: this.orderData.customerId,
        customerName: this.orderData.customerName.firstName + this.orderData.customerName.lastName,
        orderStatus: this.orderStatus || "Pending", // added on 19-5-21
        shippingClinicName: this.paymentService.shippingAddress.shippingClinicName,
        shippingBuildingName: this.paymentService.shippingAddress.shippingBuildingName,
        shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
        shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
        shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
        shippingStreetName: this.paymentService.shippingAddress.shippingStreetName,
        shippingState: this.paymentService.shippingAddress.shippingState,
        shippingCountry: this.countryName,
        shippingCountryId: this.paymentService.shippingAddress.shippingCountryId,
        country: this.countryName,
        paymenttype: paymenttype,
        countryid: this.countryId,
        shippingPostcode: this.paymentService.shippingAddress.shippingPostcode,
        orderDate: this.orderData.orderDate,
        deliveryInstruction: this.orderData.deliveryInstruction,
        couponEntered: this.orderData.couponEntered,
        adminComment: this.orderData.adminComment,
        isDisableReward: this.isDisableReward
      },
      productData: this.dataarray,
      walletPayment: {
        listOfProductIds: JSON.stringify(listOfProdIds),
        productTotal: this.orderData.productTotal,
        totalAmountWithTax: this.orderData.total,
        discount: this.orderData.discount,
        tax: this.orderData.taxpercent,
        taxCode: this.taxCodeByUser || this.orderData.taxCode, // added || this.orderData.taxCode
        delieveryType: this.orderData.delieveryType,
        delieveryCharge: this.orderData.delieveryCharge,
        customPONumber: this.orderData.customPONumber,
        paymentTermDays: this.orderData.paymentTermDays,
        methodOfPayment: methodPaymentFinal,
        // methodOfPayment: {
        //   card: this.orderData.card,
        //   wallet: this.orderData.wallet,
        //   cod: this.orderData.cod,
        //   paylater: this.orderData.paylater
        // },
        taxamount: this.orderData.taxAmount
      }
    }
    if (this.dueDate && this.dueDate != null) {
      data.orderDetails.dueDate = this.dueDate
      // data.walletPayment.paylater = this.orderData.total
      data.orderDetails.paymenttype = "paylater"
    }

    this.insertOrderInDB(data)
    // if (parseFloat(this.orderData.total) == (parseFloat(this.orderData.card + this.orderData.wallet + this.orderData.cod ))){
    //   this.insertOrderInDB(data)
    // } else {
    //   this.toastr.error('Amount should be matched')
    // }  
  }
  insertOrderInDB(data) {
    let siteType = "admin"

    this.paymentService.insertNewOrder(data, siteType, this.promoCodeId)
      .subscribe((response) => {
        let mesg: any = response;
        mesg = mesg.response.result.orderId
        this.toastr.success('New Order with ID ' + ' ' + mesg + ' is created successfully!');
        // if (parseFloat(this.orderData.wallet) > 1) {
        //   this.deductBalance()
        // }
        this.router.navigate(['/sale/orders'])

      }, (error) => {
        console.log(error);
      })
  }

  /* this function will deduct wallet balance */
  deductBalance() {
    let walletData = {
      "customerId": this.orderData.customerId,
      "amountDebit": parseFloat(this.orderData.wallet),
      "amountCredit": 0,
      "message": "deducted for placing the new order",
      "type": "Wallet",
      "txnSource": "Admin",
      "txnSourceId": 0
    }

    this.paymentService.deductWalletAmount(this.orderData.customerId, walletData)
      .subscribe((response) => {
        console.log(response)
        this.toastr.success("Wallet updated")
      }, (error) => {
        console.log(error)
        this.toastr.error("Issues while updating wallet, Kindly reach out to support team")
      })
  }
  // TO UPDATE ORDER EXISTING
  updateExistingOrder() {

    let listOfProdIds: any = []
    let methodPaymentFinal: any = {}
    let walletChangeFinal: any = {}
    for (const item of this.dataarray) {
      listOfProdIds.push(item.productId)
    }

    var paymenttype: any
    var paymentCODval = parseFloat(this.paymentDetailArray.cod) || 0
    var paymentCardval = parseFloat(this.paymentDetailArray.card) || 0
    var paymentWalletval = parseFloat(this.paymentDetailArray.wallet) || 0
    var paymentPaylaterval = parseFloat(this.paymentDetailArray.paylater) || 0
    var paymentPayPalval = parseFloat(this.paymentDetailArray.paypal) || 0
    walletChangeFinal = null;

    var balanceAmount: any
    //ALL MEETHOD OF PAYMENT CALCULATION IS DONE FROM BACKEND SIDE ONLY
    if (parseFloat(this.previousOrderTotal) != parseFloat(this.orderData.total)) {
      //add condition wallet, paylater, cod, cod+wallet

      if ((paymentCardval == 0) && (paymentPayPalval == 0) && (paymentWalletval != 0)) {
        //cod + wallet or wallet only
        //check if new total can be adjusted wallet else adjust
        methodPaymentFinal = this.paymentDetailArray

      }
      if ((paymentCardval == 0) && (paymentCODval != 0) && (paymentPayPalval == 0) && (paymentPaylaterval == 0) && (paymentWalletval == 0)) {
        //COD only
        methodPaymentFinal.cod = parseFloat(this.orderData.total).toFixed(2)

      }
      if ((paymentCardval == 0) && (paymentCODval == 0) && (paymentPayPalval != 0) && (paymentPaylaterval == 0) && (paymentWalletval == 0)) {
        //paypal only
        methodPaymentFinal.paypal = parseFloat(this.orderData.total).toFixed(2)
        //**REFUND ACTION TO BE DONE IF ANY */
      }

      if ((paymentCardval != 0) && (paymentWalletval != 0)) {
        //card+wallet only
        //do later
        //will be managed from Backend

        methodPaymentFinal = this.paymentDetailArray

      }
      if ((paymentPaylaterval != 0)) {
        //paylater only. can never be partial
        //Not adding any code. as we will block modification for BNPL orders
        methodPaymentFinal.paylater = parseFloat(this.orderData.total).toFixed(2)
        // methodPaymentFinal = this.paymentDetailArray
      }


    } else {
      //order total did not change
      //order will not change when created by online customers
      methodPaymentFinal = this.paymentDetailArray

    }


    if (!isNaN(this.orderData.wallet)) {
      this.orderData.wallet = parseFloat(this.orderData.wallet).toFixed(2)
    }
    if (!isNaN(this.orderData.cod)) {
      this.orderData.cod = parseFloat(this.orderData.cod).toFixed(2);
    }
    if (!isNaN(this.orderData.paylater)) {
      this.orderData.paylater = parseFloat(this.orderData.paylater).toFixed(2);
    }
    if (!isNaN(this.orderData.card)) {
      this.orderData.card = parseFloat(this.orderData.card).toFixed(2);
    }
    if (this.isArchivedValue) {
      this.orderData.isArchived = this.isArchivedValue
    }

    let data = {

      orderDetails: {
        Email: this.orderData.Email,
        mobileNumber: this.orderData.mobileNumber,
        billingClinicName: this.paymentService.billingAddress.billingClinicName,
        billingPostcode: this.paymentService.billingAddress.billingPostcode,
        billingBuildingName: this.paymentService.billingAddress.billingBuildingName,
        billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
        billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
        billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
        billingStreetName: this.paymentService.billingAddress.billingStreetName,
        billingState: this.paymentService.billingAddress.billingState,
        customerId: this.orderData.customerId,
        customerName: this.orderData.customerName.firstName + this.orderData.customerName.lastName,
        shippingClinicName: this.paymentService.shippingAddress.shippingClinicName,
        shippingBuildingName: this.paymentService.shippingAddress.shippingBuildingName,
        shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
        shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
        shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
        shippingStreetName: this.paymentService.shippingAddress.shippingStreetName,
        shippingCountry: this.countryName,
        country: this.countryName,
        paymenttype: paymenttype,//:this.orderData.paymenttype
        countryid: this.countryId,
        orderStatus: this.orderData.orderStatus,
        shippingPostcode: this.paymentService.shippingAddress.shippingPostcode,
        orderDate: this.orderData.orderDate,
        deliveryInstruction: this.orderData.deliveryInstruction,
        adminComment: this.orderData.adminComment,
        isArchived: this.orderData.isArchived,
        isDisableReward: this.isDisableReward
      },
      productData: this.dataarray,
      walletPayment: {
        listOfProductIds: JSON.stringify(listOfProdIds),
        productTotal: this.orderData.productTotal,
        totalAmountWithTax: this.orderData.total,
        tax: this.orderData.taxpercent,
        taxCode: this.orderData.taxCode,
        discount: this.orderData.discount, //this.orderData.discount || this.orderData.taxCode,
        delieveryType: this.orderData.delieveryType,
        delieveryCharge: this.orderData.delieveryCharge,
        customPONumber: this.orderData.customPONumber,
        paymentTermDays: this.orderData.paymentTermDays,
        methodOfPayment: methodPaymentFinal,
        taxamount: this.orderData.taxAmount
      },
      walletChange: walletChangeFinal || null

    }
    this.commonService.billingPincode = this.paymentService.billingAddress.billingPostcode;
    this.commonService.shippingPincode = this.paymentService.shippingAddress.shippingPostcode;

    this.paymentService.updateOrderForCouponChange(data, this.orderType, this.promoCodeId)
      .subscribe((response) => {
        let backorder: any = response
        var backorderCode = backorder.response.result.backorderdata.orderNo
        if ((backorderCode)) {
          this.toastr.info(`Order updated successfully with new backorder no. #${backorderCode}`)

        } else {
          this.toastr.info(`Order updated successfully`)
        }
        this.router.navigate(['/sale/orders'])
      }, (error) => {
        console.log(error);
      })
  }

  /* this function will update the address */
  updateAddress() {
    this.commonService.fieldValidations()
    if (this.commonService.emptyFieldsCheck()) {
      if (this.orderType == "new")
        this.toastr.success("Address Updated successfully")
      else {
        let data = {
          shippingBuildingName: this.paymentService.shippingAddress.shippingBuildingName,
          shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
          shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
          shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
          shippingStreetName: this.paymentService.shippingAddress.shippingStreetName,
          shippingPostcode: this.paymentService.shippingAddress.shippingPostcode,
          shippingState: this.paymentService.shippingAddress.shippingState,
          billingClinicName: this.paymentService.billingAddress.billingClinicName,
          billingPostcode: this.paymentService.billingAddress.billingPostcode,
          billingBuildingName: this.paymentService.billingAddress.billingBuildingName,
          billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
          billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
          billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
          billingStreetName: this.paymentService.billingAddress.billingStreetName,
          billingState: this.paymentService.billingAddress.billingState,
        }
        this.paymentService.updateCustomerDelieveryAddress(this.orderType, data)
          .subscribe((response) => {
            this.toastr.success("Address Updated successfully")
            //location.reload()
          }, (error) => {
            console.log(error)
          })
      }
    }
  }

  changeOrderStatus(status) {
    this.paymentService.updateCompleteOrderStatus(this.orderType, status, this.dataarray)
      .subscribe((response) => {
        this.toastr.success("Order status has been changed successfully!!")
        this.router.navigate(['/sale/orders'])
      }, (error) => {
        console.log(error)
      })
  }

  navigateBackorder(idx) {
    var navLink = "/sale/sale-admin-order/" + idx
    window.open(navLink, '_blank');
    // window.location([/sale/sale-admin-order/)
    //  this.router.navigate([/sale/sale-admin-order/, idx]) // BRD to added in the link
  }

  /**
   * On Country Change
   */
  onCountryChange(data) {
    this.fillTaxWithCountry(data['value'])
    this.enableFields = true;
    if (this.orderType == "new") {
      this.getDeleiveryData(data['value']['id']); //passing countryid
    }
    this.getAllCustomers(data['value']['id'])
    this.commonService.valueChanged = true

  }

  onApplyCoupon() {
    var couponButton = document.getElementById('spanName').innerText;
    if (couponButton == "Remove Coupon") {
      this.couponEntered = '';
      this.orderData.discount = 0;
      this.couponAppliedStatus = false;
      this.promoCodeStatus = 'Coupon removed successfully.'
      this.onChangeBilling();
      setTimeout(() => {
        this.promoCodeStatus = '';
      }, 2000);
      return;
    }

    var coupon = ((<HTMLInputElement>document.getElementById("coupon")).value);
    var totalTemp = ((<HTMLInputElement>document.getElementById("Total")).value);

    var customerIdTemp = this.orderData.customerId;
    this.couponEntered = coupon;
    this.couponAppliedStatus = true;
    this.paymentService.applyCoupon(this.couponEntered, totalTemp, customerIdTemp)
      .subscribe((response) => {
        let mesg: any = response;
        this.couponStatus = false;
        this.couponEntered = coupon;
        this.promoCodeStatus = mesg.message.charAt(0).toUpperCase() + mesg.message.slice(1);
        if (mesg.data) {
          this.orderData.discount = parseFloat(mesg.data.discount_applied).toFixed(2)
          this.promoCodeId = mesg.data.id;
          this.onChangeBilling();
        }
      }, (error) => {
        this.promoCodeStatus = error.error.message;
        this.couponStatus = true;
      })
  }

  onChangeRemovePromo() {
    var couponButton = document.getElementById('spanName').innerText;
    if (couponButton == "Remove Coupon") {
      this.couponEntered = '';
      this.orderData.discount = 0;
      this.couponAppliedStatus = false;
      this.toastr.warning(`Coupon removed`);
      this.promoCodeStatus = '';
    }
  }

  productNameSelected() {
    if (this.productSelected == false)
      this.toastr.warning(`Please select a product`);
  }

  removeCoupon() {
    this.readonlyLengthBased = false
    this.couponEntered = '';
    this.orderData.discount = 0;
    this.couponAppliedStatus = false;
    this.promoCodeStatus = 'Coupon removed successfully.'
    this.onChangeBilling();
    setTimeout(() => {
      this.promoCodeStatus = '';
    }, 2000);
    this.promoCodeEntered = false
    return;
  }

  removeProduct() {
    this.lastItem.productName = ''
    this.lastItem.sellerName = ''
    this.lastItem.price = ''
    this.lastItem.quantity = ''
    this.lastItem.total = ''
    this.lastItem.lotNumber = ''
    this.lastItem.expiryDate = ''
    this.productSelected = false;
    this.getAllProductsData();
    this.defaultValuesForStock();
  }

  downloadCreditNote() {
    this.encodedIdForCredit = btoa(this.getOrderId);
    this.creditNoteLink = this.baseService.baseUrl + "credit-note-pdf/" + (this.encodedIdForCredit).toString();
  }

  onChange(event) {
    this.commonService.valueChanged = true;
    this.isDeliveryBtnClicked = false;
  }

  backButtonClicked() {
    if (!this.editMode && this.commonService.valueChanged == true) {
      Swal.fire({
        title: 'Are you sure',
        text: 'Want to discard current changes?',
        type: 'question',
        showCancelButton: true,
        confirmButtonText: 'Proceed',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.value) {
          this.router.navigateByUrl("/sale/orders")
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          return
        }
      })
    }
    else if (this.editMode)
      this.router.navigateByUrl("/sale/orders")
    else
      this.router.navigateByUrl("/sale/orders")
  }

  openPaymentModes(contentForPayment) {
    this.paymentItem.paymentMode = ""
    this.paymentItem.referenceId = ""
    this.paymentItem.amount = ""
    this.modalService
      .open(contentForPayment, { ariaLabelledBy: "modal-basic-title", backdrop: 'static', keyboard: false })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;

        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  async manualPayment() {
    this.paymentItem.customerId = this.customerIdForPayment
    this.paymentItem.orderId = this.orderIdForPayment
    this.paymentItem.amount = this.amountForPayment
    if (this.paymentItem.paymentMode.name == 'STRIPE')
      this.paymentItem.paymentMode.name = 'Stripe'
    this.paymentItem.paymentMode = this.paymentItem.paymentMode.name

    this.productService.manualPayment(this.paymentItem).subscribe(async (response) => {
      this.incompletePaymentId = true
      this.paymentSuccessful = true
      this.toastr.success("Payment updated successfully!")
      await new Promise(resolve => setTimeout(resolve, 500));
      location.reload()
    }, (error) => {
      this.incompletePaymentId = true
      this.paymentSuccessful = false
      this.toastr.error("Incorrect payment details.")
    })
    await new Promise(resolve => setTimeout(resolve, 1200));
    if (!this.incompletePaymentId) {
      this.toastr.error("Stripe invoice status is incomplete.")
    }
  }

  paymentModeCheck(mode) {
    this.manualPaymentMode = true
    if (mode.name == 'STRIPE' || mode.name == 'NET-BANKING') {
      this.isStripeNetBanking = true
      this.isCashPaymentMode = false
    }
    else if (mode.name == 'CASH') {
      this.isStripeNetBanking = false
      this.isCashPaymentMode = true
    }
  }

  archiveOrder() {
    Swal.fire({
      text: "Are you sure that you want to mark this order as ARCHIVED?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {
      if (result.value) {
        if (this.orderStatusValue == "Delivered") {
          this.isArchivedValue = true
          Swal.fire(
            '',
            'Order ARCHIVED successfully!',
            'success'
          )
        }
        else {
          this.toastr.error("This order cannot be ARCHIVED!")
        }
      }
    })
  }

  handleChange(event) {
    this.isDisableReward = event.target.value
    event.target.checked == true ? this.isDisableReward = true : this.isDisableReward = false
  }

  calOutOfStock(content) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree([`catalogues/edit-product/` + this.productId])
    );
    if (Number(content.quantity) > Number(this.selectedProductQuantity) && !this.clickedOnSave) {
      Swal.fire({
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
        title: '',
        text: 'This product has insufficient stock! Do you want to update the stock?',
        type: 'warning'
      }).then((result) => {
        if (result.value) {
          window.open(url, '_blank');
          this.productOutOfStock = true
          this.clickedOnYes = true
          this.clickedOnSave = true
        }
        else {
          this.productOutOfStock = false
          this.clickedOnCancel = true
          this.clickedOnSave = true
        }
      })
    }
  }

  calInStock(content) {
    if (Number(content.quantity) <= Number(this.selectedProductQuantity)) {
      this.productOutOfStock = false
      this.clickedOnSave = true
    }
  }

  clickOnSave() {
    if (this.clickedOnYes || this.clickedOnCancel) {
      this.clickedOnSave = true
      this.productOutOfStock = false
    }
  }

  checkProductStock(content) {
    this.calInStock(content);
    this.calOutOfStock(content);
    this.clickOnSave();
  }

  defaultValuesForStock() {
    this.productOutOfStock = true
    this.clickedOnSave = false
    this.clickedOnYes = false
    this.clickedOnCancel = false
  }

  calculateDeliveryCharge() {
    const product = [];
    let code = null;
    this.billingStateList.forEach(element => {
      if (element.title == this.paymentService['billingAddress']['billingState']) {
        code = element['stateCode']
      }
    });

    this.dataarray.forEach(element => {
      if (element) {
        product.push({
          productId: element['productId'],
          quantity: element['quantity']
        });
      }
    });

    if (product && product.length > 0 && this.paymentService['shippingAddress']['shippingPostcode']
      && this.orderData.country && this.paymentService['billingAddress']['billingState']) {
      this.isDeliveryBtnClicked = true;
      const reqPayload = {
        productsList: product,
        postCode: this.paymentService['shippingAddress']['shippingPostcode'],
        countryId: this.orderData.country['id'],
        stateCode: code,
        state: this.paymentService['billingAddress']['billingState']
      };

      this.paymentService.calculateDeliveryCharge(reqPayload).toPromise().then((response: any) => {
        if (response && response['data'] && response['data']['charge']) {
          this.orderData.delieveryCharge = response['data']['charge']['deliveryCharge'];
        }
      });
    } else {
      return;
    }
  }


}
