import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SaleLayoutComponent } from '../sale/sale-layout/sale-layout.component';
import { QuotationComponent } from './pages/quotation/quotation.component';
import { AddQuotationComponent } from './pages/add-quotation/add-quotation.component';
import { InprogressComponent } from './pages/inprogress/inprogress.component';
import { CompletedComponent } from './pages/completed/completed.component';
import { RejectedComponent } from './pages/rejected/rejected.component';
import { OrderLayoutComponent } from './order-layout/order-layout.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { AddEditOrdersComponent } from './components/add-edit-orders/add-edit-orders.component';
import { ModAddEditOrdersComponent } from './components/mod-add-edit-orders/mod-add-edit-orders.component';
import { Resolver } from '../shared/resolver/resolver';
import { PaysectionComponent } from '../sale/components/paysection/paysection.component';
import { PrintQuotationComponent } from './pages/print-quotation/print-quotation.component'
import { SellerProductInfoComponent } from '../sale/components/seller-product-info/seller-product-info.component';
import { AbandonedCartsComponent } from '../sale/components/abandoned-carts/abandoned-carts.component'
import { ViewAbandonedCartsComponent } from '../sale/pages/view-abandoned-carts/view-abandoned-carts.component'
import { ViewUserRequestComponent } from './pages/view-user-request/view-user-request.component';
const routes: Routes = [

  {
    path: '',
    component: SaleLayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'sale',
        pathMatch: 'full'
      },
      {
        path: 'quotations',
        component: QuotationComponent
      },
      {
        path: 'new-quotation',
        component: AddQuotationComponent
      },
      {
        path: 'edit-quotation/:id',
        component: AddQuotationComponent
      },
      {
        path: 'print-quotation/:id',
        component: PrintQuotationComponent
      },
      {
        path: 'inprogress',
        component: InprogressComponent
      },
      {
        path: 'completed',
        component: CompletedComponent
      },
      {
        path: 'rejected',
        component: RejectedComponent
      },
      {
        path: 'orders',
        component: OrdersComponent,
        data: {
          title: 'Orders'
        }
      },
      {
        path: 'new-order',
        component: AddEditOrdersComponent,

      },
      {
        path: 'new-admin-order/:id',
        component: ModAddEditOrdersComponent,
      },
      {
        path: 'sale-admin-order/:id',
        component: ModAddEditOrdersComponent,
        resolve: { order: Resolver }
      },

      {
        path: 'edit-order/:id',
        component: AddEditOrdersComponent,
        resolve: { order: Resolver }

      },
      {
        path: 'pay-section',
        component: PaysectionComponent,

      },
      {
        path: 'out-of-stock-products',
        component: SellerProductInfoComponent,

      },
      {
        path: 'abandonedcarts',
        component: AbandonedCartsComponent
      },
      {
        path: 'view-abandoned-cart/:id',
        component: ViewAbandonedCartsComponent,
      },
      {
        path: 'userRequest',
        component: ViewUserRequestComponent,
      }
    ]
  }
];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class SaleRoutingModule { }
