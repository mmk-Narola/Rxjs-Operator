import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-layout',
  templateUrl: './order-layout.component.html',
  styleUrls: ['./order-layout.component.scss']
})
export class OrderLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
