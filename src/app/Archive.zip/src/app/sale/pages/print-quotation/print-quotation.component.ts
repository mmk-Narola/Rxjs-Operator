import { Component, OnInit, LOCALE_ID, Inject ,ɵConsole} from '@angular/core';
import { Validators, FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { ToastrService } from 'ngx-toastr';
import { QuotationService } from '../../../shared/services/sale/quotation.service';
import { ThrowStmt } from '@angular/compiler';
declare var require: any
@Component({
  selector: 'app-print-quotation',
  templateUrl: './print-quotation.component.html',
  styleUrls: ['./print-quotation.component.scss']
})
export class PrintQuotationComponent implements OnInit {
  id: any;
  editMode: boolean;
  QuotationDetailsData: any;
  private _unsubscribe = new Subject<boolean>();
  quotationProducts: any;
  quotationCompany:any;
  quotationValidityText: any;
  quotationCurrencySymbol: any;
  quotationdeliveryChargeText: any;
  taxRate: any;
  taxCode: any;
  companyName:any;
  companyAddress: any;
  total: any;
  words: any;

  constructor(
    
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private commonService: CommonServiceService,
    private toastr: ToastrService,
    private QuotationService: QuotationService,
   
) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(
      (id: Params) => {
        this.id = +id['id']
        console.log(this.id);
        this.editMode = id['id'] != null
       
        if(this.id)
        {
        this.getQuotationdetails(this.id);
        }
      }
      )
  }
 

  getQuotationdetails(id) {
    this.QuotationService.getQuotationdetails(id).pipe(takeUntil(this._unsubscribe)).subscribe(
      (success:any) => {
        console.log(success);
        this.QuotationDetailsData = success.data;
        console.log(this.QuotationDetailsData);
        this.quotationProducts=this.QuotationDetailsData.quotationProducts;
        this.quotationValidityText = this.QuotationDetailsData.validity;
        this.quotationCurrencySymbol= this.QuotationDetailsData.emails.country.deliveryCharge[0].currency;
        this.quotationdeliveryChargeText = this.QuotationDetailsData.deliveryChargeText;
        this.taxRate = this.QuotationDetailsData.emails.country.tax[0].taxRate;
        this.taxCode = this.QuotationDetailsData.emails.country.tax[0].taxCode;
        this.companyName = this.QuotationDetailsData.emails.country.company[0].name;
        this.companyAddress = this.QuotationDetailsData.emails.country.company[0].workAddress;
        // console.log(this.QuotationDetailsData.taxInPercent)      
        //  this.total=(this.QuotationDetailsData.subTotal)+(this.QuotationDetailsData.taxInPercent);
        //  console.log(this.total);
        
        this.total =  +this.QuotationDetailsData.subTotal  +  this.QuotationDetailsData.taxInPercent;
        this.total = this.QuotationDetailsData.total;

       console.log(this.total);
       var converter = require('number-to-words');
       this.words= converter.toWords(this.total);
      //  return word[0].toUpperCase() + word.substr(1).toLowerCase();
      this.words = this.words[0].toUpperCase() + this.words.substr(1).toLowerCase();
      this.quotationValidityText  = this.quotationValidityText.replace(/SGD/g,this.quotationCurrencySymbol);
      // this.quotationdeliveryChargeText = this.quotationdeliveryChargeText.replace(/SGD/g,this.QuotationDetailsData.emails.country.countryCurrency.symbol);
     

      // this.quotationdeliveryChargeText = this.quotationdeliveryChargeText.replace(/0.00/g,this.QuotationDetailsData.emails.country.deliveryCharge[0].deliveryCharge);
      // this.quotationdeliveryChargeText = this.quotationdeliveryChargeText.replace(/159.50/g,this.QuotationDetailsData.emails.country.deliveryCharge[0].minimumOrderAmount);
      // console.log(this.words);

       this.quotationdeliveryChargeText = this.quotationdeliveryChargeText ? this.quotationdeliveryChargeText : `Please note that there will be ${this.QuotationDetailsData.emails.country.countryCurrency.symbol}
       ${this.QuotationDetailsData.emails.country.deliveryCharge[0].deliveryCharge} delivery fee for order value below
        ${this.QuotationDetailsData.emails.country.countryCurrency.symbol} 
        ${this.QuotationDetailsData.emails.country.deliveryCharge[0].minimumOrderAmount}`


      // var quotationdeliveryChargeStart = this.quotationdeliveryChargeText.slice(0,(this.quotationdeliveryChargeText.length/2)-7) + " " + this.QuotationDetailsData.emails.country.deliveryCharge[0].deliveryCharge;
      // var quotationdeliveryChargeEnd = this.quotationdeliveryChargeText.slice((this.quotationdeliveryChargeText.length/2)-3,this.quotationdeliveryChargeText.length-7)+" "+this.QuotationDetailsData.emails.country.deliveryCharge[0].minimumOrderAmount;
      // this.quotationdeliveryChargeText = quotationdeliveryChargeStart + quotationdeliveryChargeEnd;
      },
      error => {
      }
    )
  } 
}
