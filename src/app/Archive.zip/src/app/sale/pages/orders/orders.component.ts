import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PaymentDetailService } from '../../../shared/services/sale/payment-detail.service';
import { Table } from 'primeng/table';
import { ToastrService } from 'ngx-toastr';
import * as FileSaver from 'file-saver';
import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";
import { DatePipe } from '@angular/common'
import { LazyLoadEvent, ConfirmationService } from 'primeng/api';
import { takeUntil, startWith, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { BaseService } from '../../../shared/services/base.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
interface Country {
  _id: string,
  country: string
}

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {

  cols: any[];
  filterOptions = ['New', 'Out of Stock', 'Shipped', 'Delivered', 'Cancelled', 'Special']
  filteredCols: any = [];
  myDate = new Date();
  startDate: any = null;
  endDate: any = null;
  openDetailIndex = []
  countryId = 1;
  closeResult = "";
  modalContent: any;
  paymentBalance: any;
  selectPaymentMethod: String = 'wallet';
  paylaterBalance: any;
  disablePaylater = true;
  converted_id: any;
  countries: Country[];
  baseUrlPrintInvoice: any;
  baseUrlPrintDo: any;
  private _unsubscribe = new Subject<boolean>();
  exportOrderURL: any
  selectedTab = 0;
  @ViewChild('dt') table: Table;
  constructor(private router: Router, private activateRoute: ActivatedRoute,
    private toast: ToastrService,
    public payService: PaymentDetailService,
    public datepipe: DatePipe,
    private modalService: NgbModal,
    private toastr: ToastrService,
    public paymentService: PaymentDetailService,
    private confirmationService: ConfirmationService,
    private commonService: CommonServiceService,
    private baseService: BaseService
  ) { }

  searchValue: any;
  ngOnInit() {
    localStorage.removeItem('method-of-pay')
    // localStorage.removeItem('orderdata')
    // localStorage.removeItem('order-table')
    //this.getAllBanks()
    var Date90Days = new Date(new Date().setDate(new Date().getDate() - 90));
    this.startDate = this.datepipe.transform(Date90Days, 'yyyy-MM-dd');
    var DateToday = new Date(new Date().setDate(new Date().getDate()));
    this.endDate = this.datepipe.transform(DateToday, 'yyyy-MM-dd');
    this.getAllOrders()
    this.getCountry();
    // Promise.all([this.getAllOrders()])
    this.checkEvent('New')
    if (!localStorage.getItem('order-status')) {
      this.checkEvent('New')
    } else {
      let findValue = localStorage.getItem('order-status')
      this.checkEvent(findValue)
    }

  }
  ordersData: any
  deliveryHide = true;
  checkEvent(value) {
    console.log(this.startDate, this.endDate, this.selectedTab)
    if (value == 'New' || value == 0) {
      value = 'New'
      localStorage.setItem('order-status', value)
      this.getAllOrders()
    } else if (value == 'Cancelled' || value == 4) {
      value = 'Cancelled'
      localStorage.setItem('order-status', value)
      this.payService.getOrderBasedOnUrl(value, this.startDate, this.endDate, this.countryId)
        .subscribe((response) => {
          console.log("response", response)
          this.ordersData = response
          this.ordersData = this.ordersData.response.result
          this.deliveryHide = false;
          if (this.ordersData.length < 1) {
            this.toast.info('No records found in the database')
          }
          else {
            this.showAmountStatus(this.ordersData)
          }
        }, (error) => {
          console.log(error)
        })
    } else if (value == 'Out of Stock' || value == 1) {
      value = 'Out of Stock'
      localStorage.setItem('order-status', value)
      this.payService.getOrderBasedOnUrl(value, this.startDate, this.endDate, this.countryId)
        .subscribe((response) => {

          this.ordersData = response
          this.ordersData = this.ordersData.response.result
          console.log(this.ordersData)
          let data = this.removeDuplicatesFromArrayByProperty(this.ordersData, 'orderId')
          this.ordersData = data;
          this.deliveryHide = false;
          if (this.ordersData.length < 1) {
            this.toast.info('No records found in the database')
          }
          else {
            this.showAmountStatus(this.ordersData)
          }
        }, (error) => {
          console.log(error)
        })
    } else if (value == "Delivered" || value == 3) {
      value = 'Delivered'
      this.payService.getOrderBasedOnUrl(value, this.startDate, this.endDate, this.countryId)
        .subscribe((response) => {
          console.log("response", response)
          this.ordersData = response
          this.ordersData = this.ordersData.response.result
          this.deliveryHide = false;
          if (this.ordersData.length < 1) {
            this.toast.info('No records found in the database')
          }
          else {
            this.showAmountStatus(this.ordersData)
          }
        }, (error) => {
          console.log(error)
        })
    } else if (value == "Special" || value == 5) {
      value = 'Special'
      this.payService.getOrderBasedOnUrl(value, this.startDate, this.endDate, this.countryId)
        .subscribe((response) => {
          console.log("response", response)
          this.ordersData = response
          this.ordersData = this.ordersData.response.result
          this.deliveryHide = false;
          if (this.ordersData.length < 1) {
            this.toast.info('No records found in the database')
          }
          else {
            this.showAmountStatus(this.ordersData)
          }
        }, (error) => {
          console.log(error)
        })
    } else if (value == "Shipped" || value == 2) {
      value = 'Shipped'
      this.payService.getOrderBasedOnUrl(value, this.startDate, this.endDate, this.countryId)
        .subscribe((response) => {
          console.log("response", response)
          this.ordersData = response
          this.ordersData = this.ordersData.response.result
          this.deliveryHide = false;
          if (this.ordersData.length < 1) {
            this.toast.info('No records found in the database')
          }
          else {
            this.showAmountStatus(this.ordersData)
          }
        }, (error) => {
          console.log(error)
        })
    }
  }

  showAmountStatus(data) {
    for (let x in data) {

      if (data[x].orderTransactions.length > 0) {
        data[x]['totalWithTax'] = parseFloat(data[x].orderTransactions[0].totalAmountWithTax);
        data[x]['deliveryType'] = data[x].orderTransactions[0].deliveryType.title;

        if (Object.keys(data[x].orderTransactions[0].methodOfPayment).length > 0) {
          if ((data[x].orderTransactions[0].methodOfPayment).hasOwnProperty("paylater")) {

            data[x]['paymentStatus'] = 'Paid';
          }
          else if (Object.keys(data[x].orderTransactions[0].methodOfPayment).length == 1) {
            if ((data[x].orderTransactions[0].methodOfPayment).hasOwnProperty("cod")) {
              data[x]['paymentStatus'] = 'Not Paid';
            }
            else if ((data[x].orderTransactions[0].methodOfPayment).hasOwnProperty("wallet")) {
              data[x]['paymentStatus'] = 'Paid';
            }
            else if ((data[x].orderTransactions[0].methodOfPayment).hasOwnProperty("card")) {
              data[x]['paymentStatus'] = 'Paid';
            }
          }

          else if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("cod") && (this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("wallet")) {
            if (parseFloat(this.ordersData[x].orderTransactions[0].methodOfPayment['cod']) > 0 && parseFloat(this.ordersData[x].orderTransactions[0].methodOfPayment['wallet']) > 0) {

              this.ordersData[x]['paymentStatus'] = 'Partially Paid';
            } else if (this.ordersData[x].orderTransactions[0].methodOfPayment['cod'] > 0 && this.ordersData[x].orderTransactions[0].methodOfPayment['wallet'] == 0 && this.ordersData[x].orderTransactions[0].methodOfPayment['card'] == 0) {

              this.ordersData[x]['paymentStatus'] = 'Not Paid';
            } else {

              this.ordersData[x]['paymentStatus'] = 'Paid';
            }
          }
        }
      }
    }
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  onChange(event) {
    this.countryId = event.value ? event.value.id : null
    this.setDate();
  }


  onClickRowCollapse(idx) {
    this.openDetailIndex.includes(idx) ? this.openDetailIndex = this.openDetailIndex.filter(obj => obj !== idx) : this.openDetailIndex.push(idx);
  }

  removeDuplicatesFromArrayByProperty = (arr, prop) => arr.reduce((accumulator, currentValue) => {
    if (!accumulator.find(obj => obj[prop] === currentValue[prop])) {
      accumulator.push(currentValue);
    }
    return accumulator;
  }, [])

  /* this function will get 
  *all the orders 
  */
  page = 0;
  limit = null; // 15

  pagination(event) {
    if (event == "prev") {
      if (this.page == 0) {
        this.toast.show('You are at Home Page  only')
      } else {
        this.page = this.page - 1
        this.getAllOrders()
      }
    } else if (event == "home") {
      this.page = 0
      this.getAllOrders()
    } else if (event == "next") {
      this.page = this.page + 1
      this.getAllOrders()
    }


  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  exportExcel() {
    this.commonService.getExportOrder(this.countryId).pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.exportOrderURL = success.data.url
        window.open(this.exportOrderURL, "_self")
      },
      error => {
      }
    )
  }


  filterOrderId = null;


  filterData(event, data) {
    console.log("event", event)
    console.log("data", this.filterOrderId)

    if (data == "byOrderId" && this.filterOrderId.length >= 1) {
      this.getAllOrders()
    }

    if (data == "byOrderId" && this.filterOrderId.length == 0) {
      this.filterData = null
      this.getAllOrders()
    }

  }

  setDate() {
    console.log(this.startDate)
    console.log(this.endDate)
    console.log(this.selectedTab);
    if (!this.startDate) {
      this.toast.show("Select start data")
    } if (!this.endDate) {
      this.toast.show("Select End data")
    }
    if (this.endDate >= this.startDate) {

      if (this.selectedTab == 1) {
        this.checkEvent('Out of Stock')
      } else if (this.selectedTab == 2) {
        this.checkEvent("Shipped")
      } else if (this.selectedTab == 3) {
        this.checkEvent('Delivered')
      } else if (this.selectedTab == 4) {
        this.checkEvent('Cancelled')
      } else if (this.selectedTab == 5) {
        this.checkEvent('Special');
      } else {
        this.checkEvent('New')
      }

      // this.getAllOrders()
    } else {
      this.toast.show("End date should be greater then start date")

    }
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data == 'Print Invoice') {
      this.converted_id = btoa(id);
      this.baseUrlPrintInvoice = this.baseService.baseUrl + 'admin/orderPdf/' + this.converted_id
      window.open(this.baseUrlPrintInvoice, '_blank').focus();
      return
    }

    if (event.currentTarget.firstChild.data == 'Print DO') {
      this.converted_id = btoa(id);
      this.baseUrlPrintDo = this.baseService.baseUrl + 'admin/delivery-order-pdf/' + this.converted_id
      window.open(this.baseUrlPrintDo, '_blank').focus();
      return
    }
  }

  clearFilters() {
    this.startDate = null;
    this.page = 0;
    this.filterOrderId = null;
    this.endDate = null;
    this.checkEvent(this.selectedTab)
  }

  getAllOrders() {
    this.payService.getAllOrders(this.page, this.limit, this.filterOrderId, this.startDate, this.endDate, this.countryId)
      .subscribe((response) => {
        console.log("order...", response)
        this.ordersData = response
        this.ordersData = this.ordersData.response.result.results
        if (this.ordersData.length < 1) {
          this.toast.info("No record found")
        }

        for (let x in this.ordersData) {

          if (this.ordersData[x].orderTransactions.length > 0) {
            this.ordersData[x]['totalWithTax'] = parseFloat(this.ordersData[x].orderTransactions[0].totalAmountWithTax);
            if (this.ordersData[x].orderTransactions[0].deliveryType != null)
              this.ordersData[x]['deliveryType'] = this.ordersData[x].orderTransactions[0].deliveryType.title;

            if (Object.keys(this.ordersData[x].orderTransactions[0].methodOfPayment).length > 0) {
              if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("paylater")) {

                this.ordersData[x]['paymentStatus'] = 'Paid';
              }
              else if (Object.keys(this.ordersData[x].orderTransactions[0].methodOfPayment).length == 1) {
                if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("cod")) {
                  this.ordersData[x]['paymentStatus'] = 'Not Paid';
                }
                else if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("wallet")) {
                  this.ordersData[x]['paymentStatus'] = 'Paid';
                }
                else if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("card")) {
                  this.ordersData[x]['paymentStatus'] = 'Paid';
                }
              }

              else if ((this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("cod") && (this.ordersData[x].orderTransactions[0].methodOfPayment).hasOwnProperty("wallet")) {
                if (parseFloat(this.ordersData[x].orderTransactions[0].methodOfPayment['cod']) > 0 && parseFloat(this.ordersData[x].orderTransactions[0].methodOfPayment['wallet']) > 0) {

                  this.ordersData[x]['paymentStatus'] = 'Partially Paid';
                } else if (this.ordersData[x].orderTransactions[0].methodOfPayment['cod'] > 0 && this.ordersData[x].orderTransactions[0].methodOfPayment['wallet'] == 0 && this.ordersData[x].orderTransactions[0].methodOfPayment['card'] == 0) {

                  this.ordersData[x]['paymentStatus'] = 'Not Paid';
                } else {

                  this.ordersData[x]['paymentStatus'] = 'Paid';
                }
              }
            }
          }
        }

      }, (error) => {
        console.log(error)
        this.toast.error("Some error occured")
      })
  }
  /* this  function will load 
  *new order component 
  */
  createNewOrder(value) {
    console.log('new order creating')
    if (value === 'new') {
      this.payService.billingAddress = {}
      this.payService.shippingAddress = {}
      this.payService.datas = {}
      this.payService.taxDetailsData = {}
      this.router.navigate(['../new-admin-order', 'new'], { relativeTo: this.activateRoute })
    }
  }

  getOrderDetail(value, typeOfPay, orderNo) {
    this.payService.paymentType = typeOfPay;
    console.log(orderNo)
    console.log('type of payment is ', this.payService.paymentType);
    //localStorage.setItem(value,typeOfPay)
    //this.router.navigate([`../edit-order`, value], { relativeTo: this.activateRoute })
    this.router.navigate([`../sale-admin-order`, value], { relativeTo: this.activateRoute })
  }

  deleteOrder(orderNo) {
    console.log(orderNo);
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        this.payService.deleteOrder(orderNo).pipe(takeUntil(this._unsubscribe)).subscribe(
          (success: any) => {
            this.toastr.success(success.response.message);
            this.getAllOrders();
          },
          error => {
          }
        )
      },
      reject: () => {
        return;
      }
    });
  }

  getAllBanks() {
    this.payService.getAllBankNames()
      .subscribe((response) => {
        this.payService.bankDetailsFromDb = response;
        this.payService.bankDetailsFromDb = this.payService.bankDetailsFromDb.response.result
        console.log(this.payService.bankDetailsFromDb);
      })
  }



  open(content, orderContent) {
    var customerId = orderContent.customerId;


    if (Object.keys(orderContent.orderTransactions[0].methodOfPayment).length == 1) {
      if ((orderContent.orderTransactions[0].methodOfPayment).hasOwnProperty("cod")) {
        this.disablePaylater = false;
      }
    }

    this.getWalletBalance(customerId);
    this.modalContent = orderContent;
    this.modalService
      .open(content, { ariaLabelledBy: "modal-basic-title", backdrop: 'static', keyboard: false })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;

        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );

  }





  /* get customer wallet detail by id */
  walletSummary: any;
  getWalletBalance(customerId) {
    this.paymentService.getWalletDetails(customerId)
      .subscribe((response) => {
        this.walletSummary = response;
        this.walletSummary = this.walletSummary.data;
        this.paymentBalance = parseFloat(this.walletSummary.wallet)
      }, (error) => {
        console.log(error)
      })
  }

  onChangePaymentMethod() {
    this.selectPaymentMethod = ((<HTMLInputElement>document.getElementById("paymentMethod")).value);
    if (this.selectPaymentMethod == 'wallet') {
      this.paymentBalance = parseFloat(this.walletSummary.wallet)
    }
    if (this.selectPaymentMethod == "paylater") {
      this.paymentBalance = parseFloat(this.walletSummary.payLaterL32);
      this.paylaterBalance = parseFloat(this.walletSummary.payLaterL32);
    }
  }

  onUpdatePaymentMethod(orderId) {
    let data: any;
    if (this.selectPaymentMethod == 'wallet') {
      data = { "paymentType": "Wallet" }
    }
    if (this.selectPaymentMethod == "paylater") {
      data = { "paymentType": "PAY32-BNPL" }
    }
    this.paymentService.onUpdatePaymentMethod(data, orderId)
      .subscribe((response) => {
        let mesg: any = response;
        console.log(mesg)
        mesg = mesg.response.message
        this.toastr.success(mesg);
        this.getAllOrders();
        this.router.navigate(['/sale/orders'])

      }, (error) => {
        console.log(error);
      })
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }

  }

  onSetActive(idx) {
    this.selectedTab = idx;
  }

  sendInvoice(event, id) {
    Swal.fire({
      title: 'Are you sure?',
      type: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      text: 'Do you want to send invoice email ?'
    }).then((result) => {
      if (result.value) {
        this.paymentService.invoiceOrder(id).subscribe(
          (success) => {
            this.toastr.info("Invoice is successfully sent!")
          },
          (error) => {
          }
        )
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        return;
      }
    })
    return true;
  }
}
