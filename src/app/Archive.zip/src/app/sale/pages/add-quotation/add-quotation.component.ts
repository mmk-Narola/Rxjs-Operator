import { Component, OnInit, LOCALE_ID, Inject, ɵConsole } from "@angular/core";
import {
  Validators,
  FormControl,
  FormBuilder,
  FormGroup,
} from "@angular/forms";

import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { CommonServiceService } from "../../../shared/services/common-service.service";
import { ToastrService } from "ngx-toastr";
import { ProductService } from "../../../shared/services/catalogue/product-add.service";
import { FileUploader } from "ng2-file-upload";
import { DynamicGrid } from "./model/grid.model";
import { QuantityGrid } from "./model/quantityGrid.model";
import { ConfirmationService } from "primeng/api";
import { CurrencyPipe, DatePipe, DecimalPipe } from "@angular/common";
import { CountryService } from "../../../shared/services/country.service";

import { product } from "../../product.model";
import { PaymentDetailService } from "../../../shared/services/sale/payment-detail.service";
import { CustomerService } from "../../../shared/services/customers/customer.service";
import { QuotationService } from "../../../shared/services/sale/quotation.service";
import { CutomerModel } from "../../customer.model";

import { CountryModel } from "../../country.model";
import { Home } from "../../home.model";

import { DropdownModule } from "primeng/dropdown";

import { NgbModalConfig } from "@ng-bootstrap/ng-bootstrap";
import { NgForm } from "@angular/forms";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { data } from "jquery";
import { ThrowStmt } from "@angular/compiler";
import { parse } from "querystring";
//import { type } from "os";

declare var $: any;

interface Country {
  _id: string;
  country: string;
}

@Component({
  selector: "app-add-quotation",
  templateUrl: "./add-quotation.component.html",
  styleUrls: ["./add-quotation.component.scss"],

  // add NgbModalConfig and NgbModal to the component providers
  providers: [NgbModalConfig, NgbModal],
})
export class AddQuotationComponent implements OnInit {
  closeResult = "";
  ngTaxAmount: any;
  discountedAmount: any;

  dynamicArray: Array<DynamicGrid> = [];
  filterOptions = ["new", "inProgress", "completed", "rejected", "unsaved"];
  newDynamic: any = {};
  customerId: any;
  QuotationNo: any;
  addQuotationForm: FormGroup;
  productTitle: string;
  countries: Country[];
  dynamicSeller: Array<DynamicGrid> = [];
  newSeller: any = {};
  dynamicQuantity: Array<QuantityGrid> = [];
  newQuantity: any = {};
  countryId: any;
  selectedCountryId: any;
  product = new product();
  fetchquotationDetails: any;
  addUserForm: FormGroup;
  dataarray = [];

  lastItem: any;

  lastIndex: any;

  customerModel: CutomerModel[] = [];
  countryModel: CountryModel[];
  href: any;
  productId_productName: any;
  home = new Home();
  private _unsubscribe = new Subject<boolean>();
  quotationsDate: string;
  editMode: boolean;
  id: number;
  selectedUser: any;
  filterdOptions = [];
  isSubmittedaddSellerForm: boolean;
  tax_amount: number;
  sub_total: number;
  total: any;
  QuotationDetailsData: any;
  isSubmittedaddquotationForm: boolean;
  DeliveryChargeText: string;
  element: CutomerModel;
  multiple: boolean = true;
  disabled: boolean = false;
  countryValue: any;
  countryEditableQuotation: boolean = true;
  productSelected: boolean = false;
  customerSelected: boolean = false
  config = {
    displayKey: "productName", //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: "auto", //auto //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
    placeholder: "Select Product", // text to be displayed when no item is selected defaults to Select,
    customComparator: () => { }, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
    limitTo: 10, // number thats limits the no of options displayed in the UI (if zero, options will not be limited)
    moreText: "more", // text to be displayed whenmore than one items are selected like Option 1 + 5 more
    noResultsFound: "No results found!", // text to be displayed when no items are found while searching
    searchOnKey: "productName", // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
  };
  configCustmer = {
    displayKey: "custom", //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: "200px", //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
    placeholder: "Select Customer", // text to be displayed when no item is selected defaults to Select,
    customComparator: () => { }, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
    limitTo: 10, // number thats limits the no of options displayed in the UI (if zero, options will not be limited)
    moreText: "more", // text to be displayed whenmore than one items are selected like Option 1 + 5 more
    noResultsFound: "No results found!", // text to be displayed when no items are found while searching
    searchOnKey: "firstName", // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys

  };

  productDataoptions: any[];
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private commonService: CommonServiceService,
    private toastr: ToastrService,
    private ProductService: ProductService,
    public paymentService: PaymentDetailService,
    private customerService: CustomerService,
    private countryService: CountryService,
    private QuotationService: QuotationService,
    private _date: DatePipe,
    private confirmationService: ConfirmationService,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((id: Params) => {
      this.id = +id["id"];
      console.log(this.id);
      this.editMode = id["id"] != null;
      if (!this.id) {
        this.countryEditableQuotation = true
        this.commonService.onNewOrder();
        this.productTitle = "Add New Quotation";
      }
      if (this.id) {
        this.countryEditableQuotation = false
        this.commonService.onNewOrder();
        this.productTitle = "Edit New Quotation";
        this.getQuotationdetails(this.id);
      }
    });
    this.quotationsDate = new Date().toISOString().split("T")[0];

    this.getCountry();
    // this.dataarray.push(this.home);
    Promise.all([this.getCountry(), this.getAllCustomers(1)]);
    this.DeliveryChargeText =
      "Please note that there will be SGD 10.00 delivery fee for order value below SGD 150.00";
    this.addQuotationForm = new FormGroup({
      quotationsDate: new FormControl("", [Validators.required]),
      countryId: new FormControl("", [Validators.required]),
      // quotationsStatusId: new FormControl(''),
      // quotationsStatus: new FormControl('',[Validators.required]),
      AccountNo: new FormControl("", [Validators.required]),
      customerName: new FormControl("", [Validators.required]),
      Email: new FormControl("", [Validators.required]),
      Mobilenumber: new FormControl("", [Validators.required]),
      PaymentTerm: new FormControl("COD", [Validators.required]),
      Comment: new FormControl(""),
      DeliveryLeadtime: new FormControl(
        "3-5  working days (subject to availability upon order confirmation)"
      ),
      DeliveryChargeText: new FormControl(
        "Please note that there will be SGD 0.00 delivery fee for order value below SGD 150.00"
      ),
      Vailidity: new FormControl(
        "The above order is quoted in SGD and valid for 7 days with immediate effect, thereafter subject to our further confirmation."
      ),
      ProductTotal: new FormControl(null, [Validators.required]),
      Discount: new FormControl(0, [Validators.required]),
      Tax: new FormControl(0, [Validators.required]),
      TaxAmount: new FormControl(0, [Validators.required]),
      Total: new FormControl(null, [Validators.required]),
    });
    this.addQuotationForm.controls.quotationsDate.patchValue(
      new Date().toISOString().split("T")[0]
    );
    if (this.id) {
      this.countryEditableQuotation = false;
      this.getAllProductsData(this.addQuotationForm.controls.countryId.value);
      this.getAllCustomers(this.addQuotationForm.controls.countryId.value)
    }

    this.commonService.getCountryInfo();
  }

  open(content) {
    this.productSelected = false;
    this.modalService
      .open(content, { ariaLabelledBy: "modal-basic-title", backdrop: 'static', keyboard: false })
      .result.then(
        (result) => {
          this.closeResult = `Closed with: ${result}`;

        },
        (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );

  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }

  }

  onChange(deviceValue) {
    console.log("Device value", deviceValue);
    console.log("IDK")
    this.keepValue(deviceValue)
    this.selectedCountryId = deviceValue;
    console.log(this.selectedCountryId)
    this.getAllCustomers(deviceValue)
    this.commonService.getCountryParams(this.selectedCountryId);
    console.log(this.commonService.countryMaxLenMap)
    this.commonService.selectedCountry = deviceValue
    if (deviceValue) {
      this.countryId = deviceValue;
      console.log(this.countryId);
      this.getAllProductsData(this.countryId);
    } else {
      this.countryId = this.addQuotationForm.controls.countryId.value;
    }
  }

  getdropdown2(deviceValue) {
    console.log(deviceValue);
  }
  get signUpControls() {
    return this.addQuotationForm.controls;
  }
  onSubmitAddQuotationForm() {
    event.preventDefault();
    this.isSubmittedaddquotationForm = true;
    if (this.dataarray.length == 0) {
      this.toastr.error(
        "Please select a product before submitting",
        "Warning"
      );
    }
    if (this.addQuotationForm.invalid) {
      return;
    }
    console.log(this.dataarray);

    if (!this.id) {
      this.countryEditableQuotation = true;
      const data = {
        quotationDate: this.addQuotationForm.controls.quotationsDate.value,
        quotationStatus: "inProgress",
        //quotationStatusComment:this.addQuotationForm.controls.quotationsStatus.value,
        countryId: Number(this.addQuotationForm.controls.countryId.value),
        //customerId:Number(this.addQuotationForm.controls.customerId.value),
        customerId: this.paymentService.datas.customerName,
        customerName: this.customerId,

        customerEmail: this.addQuotationForm.controls.Email.value,
        customerMobileNumber: this.addQuotationForm.controls.Mobilenumber.value,
        customerAccountNumber: this.addQuotationForm.controls.AccountNo.value,
        shippingClinicName: this.paymentService.shippingAddress
          .shippingClinicName,
        shippingBuildingName: this.paymentService.shippingAddress
          .shippingBuildingName,
        shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
        shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
        shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
        shippingStreetName: this.paymentService.shippingAddress
          .shippingStreetName,
        shippingState: this.paymentService.shippingAddress.shippingState,
        shippingPincode: Number(
          this.paymentService.shippingAddress.shippingPostcode
        ),
        billingClinicName: this.paymentService.billingAddress.billingClinicName,
        billingBuildingName: this.paymentService.billingAddress
          .billingBuildingName,
        billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
        billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
        billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
        billingStreetName: this.paymentService.billingAddress.billingStreetName,
        billingState: this.paymentService.billingAddress.billingState,
        billingPincode: Number(
          this.paymentService.billingAddress.billingPostcode
        ),

        paymentTerm: this.addQuotationForm.controls.PaymentTerm.value,
        comment: this.addQuotationForm.controls.Comment.value,
        deliveryLeadTime: this.addQuotationForm.controls.DeliveryLeadtime.value,
        deliveryChargeText: this.addQuotationForm.controls.DeliveryChargeText
          .value,
        validity: this.addQuotationForm.controls.Vailidity.value,
        subTotal: Number(this.addQuotationForm.controls.ProductTotal.value),
        discount: Number(this.addQuotationForm.controls.Discount.value),
        taxInPercent: Number(this.addQuotationForm.controls.Tax.value),
        taxAmount: Number(this.addQuotationForm.controls.TaxAmount.value),
        total: Number(this.addQuotationForm.controls.Total.value),
        isSameAddress: this.paymentService.isActive,
        quotationProducts: this.dataarray,
      };
      console.log(data);
      var json = JSON.stringify(data);
      console.log(json);
      this.commonService.fieldValidations()
      if (this.commonService.emptyFieldsCheck()) {
        this.QuotationService.onSubmitAddQuotationForm(data)
          .pipe(takeUntil(this._unsubscribe))
          .subscribe(
            (success: any) => {
              this.paymentService.shippingAddress = [];
              this.paymentService.billingAddress = [];
              this.paymentService.isActive = false;
              this.toastr.success("Quotation Create Successfully!");
              this.router.navigate(["/sale/quotations"]);
              this.commonService.billingPincodeValid = true;
              this.commonService.shippingPincodeValid = true;
            },
            (error) => {
              this.toastr.error("error", error); this.id
            }
          );
      }
    }
    if (this.id) {
      this.commonService.onNewOrder();
      this.commonService.countryEditable = false
      const data = {
        id: this.id,
        quotationDate: this.addQuotationForm.controls.quotationsDate.value,
        quotationStatus: "inProgress",
        //  quotationStatusComment:this.addQuotationForm.controls.quotationsStatus.value,
        countryId: Number(this.addQuotationForm.controls.countryId.value),
        customerId: Number(this.addQuotationForm.controls.customerName.value),
        customerName: this.customerId,

        customerEmail: this.addQuotationForm.controls.Email.value,
        customerMobileNumber: this.addQuotationForm.controls.Mobilenumber.value,
        customerAccountNumber: this.addQuotationForm.controls.AccountNo.value,
        shippingClinicName: this.paymentService.shippingAddress
          .shippingClinicName,
        shippingBuildingName: this.paymentService.shippingAddress
          .shippingBuildingName,
        shippingBlockNo: this.paymentService.shippingAddress.shippingBlockNo,
        shippingFloorNo: this.paymentService.shippingAddress.shippingFloorNo,
        shippingUnitNo: this.paymentService.shippingAddress.shippingUnitNo,
        shippingStreetName: this.paymentService.shippingAddress
          .shippingStreetName,
        shippingState: this.paymentService.shippingAddress.shippingState,
        shippingPincode: Number(
          this.paymentService.shippingAddress.shippingPostcode
        ),
        billingClinicName: this.paymentService.billingAddress.billingClinicName,
        billingBuildingName: this.paymentService.billingAddress
          .billingBuildingName,
        billingBlockNo: this.paymentService.billingAddress.billingBlockNo,
        billingFloorNo: this.paymentService.billingAddress.billingFloorNo,
        billingUnitNo: this.paymentService.billingAddress.billingUnitNo,
        billingStreetName: this.paymentService.billingAddress.billingStreetName,
        billingState: this.paymentService.billingAddress.billingState,
        billingPincode: Number(
          this.paymentService.billingAddress.billingPostcode
        ),

        paymentTerm: this.addQuotationForm.controls.PaymentTerm.value,
        comment: this.addQuotationForm.controls.Comment.value,
        deliveryLeadTime: this.addQuotationForm.controls.DeliveryLeadtime.value,
        deliveryChargeText: this.addQuotationForm.controls.DeliveryChargeText
          .value,
        validity: this.addQuotationForm.controls.Vailidity.value,
        subTotal: Number(this.addQuotationForm.controls.ProductTotal.value),
        discount: Number(this.addQuotationForm.controls.Discount.value),
        taxInPercent: Number(this.addQuotationForm.controls.Tax.value),
        taxAmount: Number(this.addQuotationForm.controls.TaxAmount.value),
        total: Number(this.addQuotationForm.controls.Total.value),
        isSameAddress: this.paymentService.isActive,
        quotationProducts: this.dataarray,
      };
      console.log(data);
      var json = JSON.stringify(data);
      console.log(json);
      this.commonService.fieldValidations();
      if (this.commonService.emptyFieldsCheck())
        this.QuotationService.onSubmitUpdateQuotationForm(data)
          .pipe(takeUntil(this._unsubscribe))
          .subscribe(
            (success: any) => {
              this.paymentService.shippingAddress = [];
              this.paymentService.billingAddress = [];
              this.paymentService.isActive = false;
              this.toastr.success("Quotation Update Successfully!");
              this.router.navigate(["/sale/quotations"]);
            },
            (error) => {
              this.toastr.error("error", error);
            }
          );
    }
  }
  customerDataChangeDetect(event) {
    this.customerSelected = true
    console.log(event);
    console.log(this.customerModel);
    this.customerModel.some((elem) => {
      if (event.value.customerId == elem.customerId) {
        console.log("enter");
        console.log(elem);
        this.element = elem;
        console.log(this.element.customerAddress);
        this.customerId = elem.firstName + " " + " " + elem.lastName;
        this.addQuotationForm.controls.Email.patchValue(elem.Email);
        console.log(elem.Email);
        console.log(this.addQuotationForm.controls.Email.patchValue(elem.Email));
        this.addQuotationForm.controls.Mobilenumber.patchValue(
          elem.mobileNumber
        );
        this.addQuotationForm.controls.AccountNo.patchValue(elem.customerId);
        this.paymentService.datas.customerName = event.value.customerId;
        console.log("customer data", this.paymentService.datas.customerName);
        this.paymentService.billingAddress.billingClinicName = elem.clinicName;
        this.paymentService.shippingAddress.shippingClinicName = elem.clinicName;
        this.paymentService.billingAddress.billingClinicName = event.value.clinicName
        this.paymentService.billingAddress.billingBuildingName = event.value.buildingName
        this.paymentService.billingAddress.billingBlockNo = event.value.houseNo
        this.paymentService.billingAddress.billingFloorNo = event.value.floorNo
        this.paymentService.billingAddress.billingUnitNo = event.value.unitNo
        this.paymentService.billingAddress.billingStreetName = event.value.streetName
        this.paymentService.billingAddress.billingState = event.value.state
        this.paymentService.billingAddress.billingPostcode = event.value.pincode
        // this.addQuotationForm.controls.AccountNo.patchValue(elem.customerId);
      } else {
        return false;
      }
    });
  }

  getdropdown1(event: any) {
    this.selectedCountryId = event.value;
  }

  getCountry() {
    this.commonService
      .getCountry()
      .pipe(takeUntil(this._unsubscribe))
      .subscribe(
        (success: any) => {
          this.countries = success.data;
          console.log(this.countries);
        },
        (error) => { }
      );
  }
  arrayOfStringsToArrayOfObjects(arr: any[]) {
    const newArray = [];
    if (arr != []) {
      arr.forEach((element) => {
        newArray.push({
          id: element.productId,
          name: element.productName,
        });
      });
    }
    return newArray;
  }

  getProductData() {
    this.paymentService
      .getSingleProductDetail(this.paymentService.param)
      .subscribe((response) => {
        let data: any = response;
        data = data.response.result;
        this.dataarray = data;
      });
  }
  totalAmountWithTax;

  countriesData: any;

  countryName: any;
  countryid: any;
  detectCountry(value) {
    this.countryModel.some((elem) => {
      if (elem.id == value) {
        this.paymentService.datas.billingCountryName = elem.itemName;
        this.paymentService.datas.countryid = elem.id;
        this.countryName = elem.itemName;
        this.countryid = elem.id;
      } else {
        return false;
      }
      //return false;
    });
    this.paymentService.getDeliveryDetails(value).subscribe((response) => {
      console.log(response);
      let deliveryType: any = response;
      let data: any = response;
      deliveryType = deliveryType.data.title;
      this.paymentService.taxDetailsData.delieveryType = deliveryType;
      this.paymentService.taxDetailsData.delieveryCharge =
        data.data.deliveryCharge;
    });
  }
  customerData: any;
  getAllCustomers(countryV) {
    this.customerService.getCountryCustomers(null, countryV).subscribe(
      (response) => {
        this.customerData = response;
        this.customerData = this.customerData.data.results;
        this.customerModel = this.customerData;
        console.log(this.customerModel);
        for (let user of this.customerModel) {
          user['custom'] = user.firstName + ' ' + user.lastName + ' ' + '-' + ' ' + user.Email;
        }
      },
      (error) => {
        this.toastr.error(error.message);
      }
    );
  }
  productData: any;
  getAllProductsData(countryId) {
    console.log("DDDDDD")
    this.QuotationService.getAllProductsData(countryId)
      .pipe(takeUntil(this._unsubscribe))
      .subscribe(
        (success: any) => {
          console.log(success);
          this.productData = success;
          this.productDataoptions = this.arrayOfStringsToArrayOfObjects(
            success.data
          );
          console.log(this.productDataoptions);
          this.productData = this.productData.data;
          console.log(this.productData);
          //  for(var i=0; i<this.productData.length; i++)
          // {
          //   console.log( this.productData);
          //   console.log( this.productData[i]);
          //   console.log( this.productData[i].productId);
          //   this.options.push({id: this.productData[i].productId, description:this.productData[i].productName});
          // }
          // console.log( this.options);
        },
        (error) => {
          this.toastr.error(error.message);
        }
      );
  }

  detectChangeProduct(value, v1) {
    console.log(value);
    console.log(value.value.productId);
    console.log(v1);
    let tempTotal = [];
    this.productData.some((elem) => {
      if (elem.productId == value.value.productId) {
        this.dataarray[v1].productName = elem.productName;
        this.dataarray[v1].productId = elem.productId;
        this.dataarray[v1].PNCDE = elem.PNCDE;
        this.dataarray[v1].price = parseFloat(elem.MRP);
        this.dataarray[v1].quantity = 1 // added on 21-5-2021
        this.dataarray[v1].sellerId = elem.sellerProducts[0].sellerId;
        this.dataarray[v1].sellerName = elem.sellerProducts[0].sellerDetail.sellerName;
        // this.dataarray[v1].orderProductStatus = 'In Stock'
        var price = this.dataarray[v1].price * this.dataarray[v1].quantity;
        this.dataarray[v1].totalPrice = price.toFixed(2);
        if (elem.productName.length != 0)
          this.productSelected = true
        this.dataarray.forEach((elem) => {
          tempTotal.push(elem.totalPrice);
        });
        var sum = tempTotal.reduce(function (a, b) {
          return +a + +b;
        }, 0);
        console.log(sum);
        this.addQuotationForm.controls.ProductTotal.patchValue(sum);
        this.addQuotationForm.controls.ProductTotal.value;
        console.log(this.addQuotationForm.controls.ProductTotal.value);
        this.sub_total =
          this.addQuotationForm.controls.ProductTotal.value -
          this.addQuotationForm.controls.Discount.value;
        console.log(this.sub_total);
        this.tax_amount =
          (this.addQuotationForm.controls.Tax.value / 100) * this.sub_total;
        console.log(this.tax_amount.toFixed(2));

        this.addQuotationForm.controls.TaxAmount.patchValue(
          this.tax_amount.toFixed(2)
        );
        this.total = this.tax_amount + this.sub_total;
        console.log("Total: " + this.total);
        this.addQuotationForm.controls.Total.patchValue(this.total.toFixed(2));
      }
    });
    console.log(this.dataarray);
  }

  addFieldHome() {
    this.home = new Home();
    this.dataarray.push(this.home);
    this.lastItem = this.dataarray[this.dataarray.length - 1];
    this.lastIndex = this.dataarray.length - 1;
    console.log(this.lastItem);
  }

  removeHomeField() {
    // this.dataarray.pop()
    let tempTotal = [];

    this.dataarray.splice(this.lastIndex, 1);
    console.log(this.dataarray);
    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.totalPrice);
    });
    console.log(tempTotal);
    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);
    console.log(sum);
    this.addQuotationForm.controls.ProductTotal.patchValue(sum);
    this.addQuotationForm.controls.ProductTotal.value;
    this.sub_total =
      this.addQuotationForm.controls.ProductTotal.value -
      this.addQuotationForm.controls.Discount.value;
    this.tax_amount =
      (this.addQuotationForm.controls.Tax.value / 100) * this.sub_total;
    this.addQuotationForm.controls.TaxAmount.patchValue(
      this.tax_amount.toFixed(2)
    );
    this.total = this.tax_amount + this.sub_total;
    console.log(this.total);
    this.addQuotationForm.controls.Total.patchValue(this.total.toFixed(2)); // original this.total.toFixed(2)
    return true;

  }

  removeHome(index) {
    let tempTotal = [];
    console.log(index);
    if (this.dataarray.length == 1) {
      this.toastr.error(
        "Can't delete the row when there is only one row",
        "Warning"
      );
      return false;
    } else {
      this.dataarray.splice(index, 1);
      console.log(this.dataarray);
      this.dataarray.forEach((elem) => {
        tempTotal.push(elem.totalPrice);
      });
      console.log(tempTotal);
      var sum = tempTotal.reduce(function (a, b) {
        return +a + +b;
      }, 0);
      console.log(sum);
      this.addQuotationForm.controls.ProductTotal.patchValue(sum);
      this.addQuotationForm.controls.ProductTotal.value;
      this.sub_total =
        this.addQuotationForm.controls.ProductTotal.value -
        this.addQuotationForm.controls.Discount.value;
      this.tax_amount =
        (this.addQuotationForm.controls.Tax.value / 100) * this.sub_total;
      this.addQuotationForm.controls.TaxAmount.patchValue(
        this.tax_amount.toFixed(2)
      );
      this.total = this.tax_amount + this.sub_total;
      console.log(this.total);
      this.addQuotationForm.controls.Total.patchValue(this.total.toFixed(2)); // original this.total.toFixed(2)
      return true;
    }
  }

  changeProductStatus(value, v1) {
    let tempTotal = [];
    this.dataarray[v1].orderProductStatus = value;
    this.dataarray.forEach((elem) => {
      if (elem.orderProductStatus == "In Stock") {
        tempTotal.push(elem.total);
      }
    });

    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);
    this.addQuotationForm.controls.ProductTotal.patchValue(sum);
    this.paymentService.taxDetailsData.productTotal = sum;
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    this.paymentService.taxDetailsData.taxAmount =
      (this.paymentService.taxDetailsData.productTotal * 10) / 100;
    this.paymentService.taxDetailsData.total =
      this.paymentService.taxDetailsData.taxAmount +
      this.paymentService.taxDetailsData.productTotal;
  }

  quantityDetectChange(value, vl) {
    let tempTotal = [];
    this.dataarray[vl].totalPrice = (this.dataarray[vl].price * value).toFixed(2);

    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.totalPrice);
    });

    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);

    this.addQuotationForm.controls.ProductTotal.patchValue(sum);

    this.paymentService.taxDetailsData.productTotal = sum;

    if (this.id) {
      this.countryEditableQuotation = false;
      this.addQuotationForm.controls.ProductTotal.patchValue(sum);
      this.addQuotationForm.controls.ProductTotal.value;
      console.log(this.addQuotationForm.controls.ProductTotal.value);
      this.sub_total =
        this.addQuotationForm.controls.ProductTotal.value -
        this.addQuotationForm.controls.Discount.value;
      console.log(this.sub_total);
      this.tax_amount =
        (this.addQuotationForm.controls.Tax.value / 100) * this.sub_total;
      console.log(this.tax_amount.toFixed(2));

      this.addQuotationForm.controls.TaxAmount.patchValue(
        this.tax_amount.toFixed(2)
      );
      this.total = this.tax_amount + this.sub_total;
      console.log(this.total);
      this.addQuotationForm.controls.Total.patchValue(this.total.toFixed(2));
    } this.id
    if (!this.id) {
      this.countryEditableQuotation = true;
      this.addQuotationForm.controls.ProductTotal.patchValue(sum);
      this.addQuotationForm.controls.ProductTotal.value;
      console.log(this.addQuotationForm.controls.ProductTotal.value);
      this.sub_total =
        this.addQuotationForm.controls.ProductTotal.value -
        this.addQuotationForm.controls.Discount.value;
      console.log(this.sub_total);
      this.tax_amount =
        (this.addQuotationForm.controls.Tax.value / 100) * this.sub_total;
      console.log(this.tax_amount.toFixed(2));

      this.addQuotationForm.controls.TaxAmount.patchValue(
        this.tax_amount.toFixed(2)
      );
      this.total = this.tax_amount + this.sub_total;
      console.log(this.total);
      this.addQuotationForm.controls.Total.patchValue(this.total.toFixed(2));
    }
    this.paymentService.productDetailArray = this.dataarray;

    //this.paymentService.taxDetailsData.taxAmount =  this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
    this.paymentService.taxDetailsData.taxAmount =
      (this.paymentService.taxDetailsData.productTotal * 10) / 100;
    this.paymentService.taxDetailsData.total =
      this.paymentService.taxDetailsData.taxAmount +
      this.paymentService.taxDetailsData.productTotal;
  }

  detectChangePrice(value, vl) {
    value = parseFloat(value);
    let tempTotal = [];
    this.dataarray[vl].totalPrice = (this.dataarray[vl].quantity * value).toFixed(2);

    this.addQuotationForm.controls.ProductTotal.patchValue(
      this.dataarray[vl].totalPrice
    );

    this.dataarray.forEach((elem) => {
      tempTotal.push(elem.totalPrice);
    });

    if (this.id) {

    }
    if (!this.id) {

    }
    var sum = tempTotal.reduce(function (a, b) {
      return +a + +b;
    }, 0);

    this.paymentService.taxDetailsData.productTotal = parseFloat(sum);
    console.log("SUMMMM:", sum);
    this.paymentService.productDetailArray = this.dataarray;
    this.addQuotationForm.controls.ProductTotal.patchValue(sum);
    this.onChangeBilling();
  }


  onChangeBilling() {
    console.log("Original Total: ", this.addQuotationForm.controls.ProductTotal.value);
    var discountVal = parseFloat((<HTMLInputElement>document.getElementById("discountValue")).value);
    var taxValue = parseFloat((<HTMLInputElement>document.getElementById("taxValue")).value);
    var taxType = ((<HTMLInputElement>document.getElementById("taxValue")).value)

    console.log("discount value", discountVal);
    console.log("tax value", taxValue);

    this.discountedAmount = parseFloat(this.addQuotationForm.controls.ProductTotal.value) - discountVal;
    console.log("discounted amount", this.discountedAmount);

    this.ngTaxAmount = ((this.discountedAmount) * (taxValue / 100));
    this.ngTaxAmount = parseFloat(this.ngTaxAmount).toFixed(2);
    console.log("tax amount", this.ngTaxAmount);

    this.total = (parseFloat(this.discountedAmount) + parseFloat(this.ngTaxAmount));


    this.addQuotationForm.controls.Total.patchValue(parseFloat(this.total).toFixed(2));

    console.log("final amount", parseFloat(this.addQuotationForm.controls.ProductTotal.value) + parseFloat(this.ngTaxAmount));
    console.log("amount after tax: ", this.total.toFixed(2));

  }
  getQuotationdetails(id) {
    this.QuotationService.getQuotationdetails(id)
      .pipe(takeUntil(this._unsubscribe))
      .subscribe(
        (success: any) => {
          this.QuotationDetailsData = success.data;
          console.log(this.QuotationDetailsData);
          this.patchForm(this.QuotationDetailsData);
        },
        (error) => { }
      );

  }

  patchForm(item) {
    this.customerSelected = true
    console.log(item);
    this.commonService.selectedCountry = item.countryId
    let name = item.customerName.split(" ");

    // console.log(this._date.transform(item.quotationDate, 'dd/MM/yyyy'));
    // this.addQuotationForm.controls.quotationsDate.patchValue(this._date.transform(item.quotationDate, 'dd/MM/yyyy'));

    this.QuotationNo = item.quotationNumber;
    console.log(this.QuotationNo);

    this.addQuotationForm.controls.quotationsDate.patchValue(
      item.quotationDate.split("T")[0]
    );
    this.addQuotationForm.controls.countryId.patchValue(item.countryId);
    // this.addQuotationForm.controls.quotationsStatusId.patchValue(item.quotationStatus);
    // this.addQuotationForm.controls.quotationsStatus.patchValue(item.quotationStatusComment);
    //this.addQuotationForm.controls.AccountNo.patchValue(item.customerAccountNumber);
    this.addQuotationForm.controls.customerName.patchValue(name[0]);
    this.addQuotationForm.controls.Email.patchValue(item.customerEmail);
    this.addQuotationForm.controls.AccountNo.patchValue(
      item.customerAccountNumber
    );
    this.addQuotationForm.controls.Mobilenumber.patchValue(
      item.customerMobileNumber
    );
    this.addQuotationForm.controls.PaymentTerm.patchValue(item.paymentTerm);
    this.addQuotationForm.controls.Comment.patchValue(item.comment);
    this.addQuotationForm.controls.DeliveryLeadtime.patchValue(
      item.deliveryLeadTime
    );
    this.addQuotationForm.controls.DeliveryChargeText.patchValue(
      item.deliveryChargeText
    );
    this.addQuotationForm.controls.Vailidity.patchValue(item.validity);
    this.addQuotationForm.controls.ProductTotal.patchValue(item.subTotal);
    this.addQuotationForm.controls.Discount.patchValue(item.discount);
    this.addQuotationForm.controls.Tax.patchValue(item.taxInPercent);
    this.addQuotationForm.controls.TaxAmount.patchValue(item.taxAmount);
    this.addQuotationForm.controls.Total.patchValue(item.total);
    if (item) {
      this.paymentService.shippingAddress.shippingBlockNo =
        item.shippingBlockNo;
      this.paymentService.shippingAddress.shippingBuildingName =
        item.shippingBuildingName;
      this.paymentService.shippingAddress.shippingClinicName =
        item.shippingClinicName;
      this.paymentService.shippingAddress.shippingFloorNo =
        item.shippingFloorNo;
      this.paymentService.shippingAddress.shippingUnitNo = item.shippingUnitNo;
      this.paymentService.shippingAddress.shippingPostcode =
        item.shippingPincode;
      this.paymentService.shippingAddress.shippingStreetName =
        item.shippingStreetName;
      this.paymentService.shippingAddress.shippingUnitNo = item.shippingUnitNo;
      (this.paymentService.shippingAddress.shippingState =
        item.shippingState),
        (this.paymentService.billingAddress.billingClinicName =
          item.billingClinicName);
      this.paymentService.billingAddress.billingBuildingName =
        item.billingBuildingName;
      this.paymentService.billingAddress.billingBlockNo = item.billingBlockNo;
      this.paymentService.billingAddress.billingFloorNo = item.billingFloorNo;
      this.paymentService.billingAddress.billingUnitNo = item.billingUnitNo;
      this.paymentService.billingAddress.billingStreetName =
        item.billingStreetName;
      this.paymentService.billingAddress.billingState = item.billingState;

      this.paymentService.billingAddress.billingPostcode = item.billingPincode;
      this.paymentService.isActive = item.isSameAddress;
    }
    //  let qp = item.quotationProducts.map(async (p)=>{
    //    await p.pncode = p.PNCDE
    //    await delete p.PNCDE ;

    //  })

    item.quotationProducts.forEach((data) => {
      // data.pncode = data.PNCDE;
      // data.total = data.totalPrice;
      // delete data.PNCDE;
    });

    this.dataarray = item.quotationProducts;
  }
  deleteRow(index) { }
  // filterUsers() {
  //   this.filterdOptions = this.customerModel.filter(
  //     item => item.firstName.toLowerCase().includes(this.selectedUser.toLowerCase())
  //   );
  //   console.log(this.filterdOptions);
  // }

  keepValue(deviceValue) {
    this.countryValue = Number(deviceValue)
  }

  removeProduct() {
    this.lastItem.productName = ''
    this.lastItem.sellerName = ''
    this.lastItem.price = ''
    this.lastItem.quantity = ''
    this.lastItem.totalPrice = ''
    this.lastItem.PNCDE = ''
    this.productSelected = false;
  }

  productNameSelected() {
    if (this.productSelected == false)
      this.toastr.warning(`Please select a product`);
  }

  removeCustomer() {
    this.addQuotationForm.controls.customerName.patchValue('');
    this.addQuotationForm.controls.Email.patchValue('');
    this.addQuotationForm.controls.AccountNo.patchValue('');
    this.addQuotationForm.controls.Mobilenumber.patchValue('');
    this.paymentService.shippingAddress = []
    this.paymentService.billingAddress = []
    this.paymentService.isActive = false;
  }
}

