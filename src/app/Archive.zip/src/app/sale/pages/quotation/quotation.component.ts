import { Component, OnInit ,ViewChild} from '@angular/core';
import { Validators, FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {NgbTabsetConfig} from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { UtilityService } from '../../../shared/utility/utility.service'; 
import { CategoryService } from '../../../shared/services/catalogue/category.service';
import { ProductService } from '../../../shared/services/catalogue/product.service';
import { QuotationService } from '../../../shared/services/sale/quotation.service';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { takeUntil, startWith, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { LazyLoadEvent, ConfirmationService } from 'primeng/api';
import { ExcelServiceService } from '../../../shared/services/excel-service.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { trigger,state,style,transition,animate } from '@angular/animations';
import { NgbModal, ModalDismissReasons, NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import { BaseService } from '../../../shared/services/base.service';
import { SortEvent } from 'primeng/api';
import { DatePipe } from '@angular/common'
interface Country {
  _id:string, 
  country:string
}
interface seller {
  _id:string, 
  seller:string
}
@Component({
  selector: 'app-quotation',
  templateUrl: './quotation.component.html',
  styleUrls: ['./quotation.component.scss'],
  animations: [
    trigger('rowExpansionTrigger', [
        state('void', style({
            transform: 'translateX(-10%)',
            opacity: 0
        })),
        state('active', style({
            transform: 'translateX(0)',
            opacity: 1
        })),
        transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
],
providers: [NgbTabsetConfig,NgbAccordionConfig]
})
export class QuotationComponent implements OnInit {
  filterOptions = ['all', 'inProgress', 'completed', 'rejected','unsaved']
  searchTerms$ = new Subject<string>();
  searchBar: any = "";
  dateFrom: any = "";
  baseUrlPrint: any;
  converted_id: any;
  dateTo: any = "";
  quotationStatus: any = "";
  countries:Country[];
  countryId : number = null;
  private _unsubscribe = new Subject<boolean>();
  page:number = 0;
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;
  QuotationList: any;
  totalCount: any;
  action: any;
  constructor(config: NgbTabsetConfig, private router:Router, 
    private activateRoute : ActivatedRoute,
    private utilityService:UtilityService,
    private categoryService:CategoryService,
    private ProductService:ProductService,
    private modalService: NgbModal,
    private toastr: ToastrService,
    private QuotationService: QuotationService,
    private confirmationService: ConfirmationService,
    private commonService : CommonServiceService,
    private baseService: BaseService,
    private excelService:ExcelServiceService,
    public datepipe: DatePipe) {
    // customize default values of tabsets used by this component tree
    // config.justify = 'center';
    config.type = 'pills';  }
    setStatus(id:Number,quotationStatus:Number){

      let statusData = {id,quotationStatus}
      
   this.QuotationService.updateproductStatus(statusData).subscribe(
     (success:any)=>
     {
    
      this.ngOnInit()
  } )
    }
  ngOnInit() {
    
    this.dateFrom = this.datepipe.transform(new Date(new Date().setDate(new Date().getDate() - 90)) , 'yyyy-MM-dd');

    this.dateTo = this.datepipe.transform(new Date(new Date().setDate(new Date().getDate())), 'yyyy-MM-dd');
    this.getCountry();
    this.initiateSearch();
  }
  loadDataLazy(event: LazyLoadEvent) {
    console.log("load");
    this.page = event.first / 10;
    if (!this.searchBar && !this.countryId && !this.dateFrom && !this.dateTo) {
      console.log("1");
      this.getAllquotation(this.page);
    }
    else if (!this.countryId) {
      console.log("2");
      this.getAllquotation(this.page);
    }
    else if (!this.dateFrom) {
      console.log("3");
      this.getAllquotation(this.page);
    }
    else if (!this.dateTo) {
 
      this.getAllquotation(this.page);
    }
    else if (!this.quotationStatus) {
 
      this.getAllquotation(this.page);
    }    
    else {
      console.log("page124");
      this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
    }
  }
  onChange(deviceValue) {
    console.log(deviceValue);
    if (deviceValue) {
      this.countryId = deviceValue;
      console.log(this.countryId);
    }
    else {
    }
  
    this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
  }
  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      // switch to new search observable each time the term changes
      switchMap((term: string) => this.QuotationService.getAllquotationSearch(this.page, term,  this.quotationStatus,this.countryId, this.dateFrom, this.dateTo
      ))
    ).subscribe((success: any) => {
      console.log(success);
      this.QuotationList = success.data.results;
      console.log(this.QuotationList);
      this.totalCount = success.data.total;
      this.utilityService.resetPage();
    })
  }
  filterGlobal(searchTerm) {
    console.log(searchTerm);
    this.primeNGTable.first = 0;
    this.page = 0; 
    this.searchTerms$.next(searchTerm);
  }
  datefromGlobal(dateFrom) {
    console.log(dateFrom);
    this.dateFrom=dateFrom;
    if (dateFrom) {
      this.dateFrom=dateFrom;
      console.log(this.dateFrom);
    }
    else {
    }
    this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
     }
     datetoGlobal(dateTo) {
      console.log(dateTo);
      this.dateTo=dateTo;
      if (dateTo) {
        this.dateTo=dateTo;
        console.log(this.dateTo);
      }
      else {
      }
      this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
       }
  
     getCountry() {
      this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.countries = success.data;
          console.log("mayuri");
          console.log(this.countries);
        },
        error => {
        }
      )
    }

    clearDates(){
      if(this.dateFrom != null && this.dateTo != null){
        this.dateFrom = null;
        this.dateTo = null;
        this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
      }
    }
 
    getAllquotationSearch(page, searchBar ,countryId, quotationStatus,dateFrom, dateTo) {
    
      console.log(page,searchBar,countryId);
      this.QuotationService.getAllquotationSearch(page, searchBar,quotationStatus,countryId,dateFrom,dateTo)
        .pipe(
          takeUntil(this._unsubscribe)
        )
        .subscribe((success: any) => {  
          console.log(success);
          this.QuotationList = success.data.results;
          console.log(this.QuotationList);
          this.totalCount = success.data.total;
          this.utilityService.resetPage();
     
        },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
    } 
    getAllquotation(page) { 
      var data=[];
      this.QuotationService.getAllquotation(page).subscribe(
        (success: any) => {
      
          console.log(success);
    
          this.QuotationList = success.data.results;
            
          console.log(this.QuotationList);
        },
        error => {
        
          this.utilityService.resetPage();
        }
      );
    }
    getDropDownValue(event, id) {
      if(event.currentTarget.firstChild.data === 'Delete') {
        this.confirmationService.confirm({ 
          message: 'Are you sure that you want to perform this action?',
          accept: () => {
            this.QuotationService.deleteQuotation(id).pipe(takeUntil(this._unsubscribe)).subscribe(
              (success: any) => {
                this.getAllquotation(this.page);
                this.QuotationList = this.QuotationList.filter((item: any) => {
                  return id !== item.countryId
                }) 
              },
              error => {
              }
            )
          },
          reject: () => {
            this.action = null;
          }
      });
    }
    if(event.currentTarget.firstChild.data === 'Edit'){
      console.log(event.currentTarget.firstChild.data)
          this.router.navigate(['../edit-quotation',id], {relativeTo: this.activateRoute})
    }
    if(event.currentTarget.firstChild.data === 'Print'){
      // console.log(event.currentTarget.firstChild.data)
      //     this.router.navigate(['../print-quotation',id], {relativeTo: this.activateRoute})
       this.converted_id = btoa(id);
      this.baseUrlPrint = this.baseService.baseUrl + 'admin/quotationPdf/'
      // "https://www.lumiere32.my/testapi/v1/admin/quotationPdf/"

    

    }
  } 
  
  checkEvent(value) {
    console.log(value)
    
    if(value === "all"){
      this.quotationStatus = null;
    }else{
      this.quotationStatus=value;
    }
    if (this.quotationStatus) {
      this.quotationStatus=value;
      console.log(this.quotationStatus);
    }
    else {
    }
    this.getAllquotationSearch(this.page,this.searchBar, this.countryId,this.quotationStatus,this.dateFrom, this.dateTo);
  }
}