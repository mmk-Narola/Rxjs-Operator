import { Component, OnInit } from '@angular/core';
import { Table } from 'primeng/table';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AbandonedCartsService } from '../../../shared/services/sale/abandoned-carts.service';

@Component({
  selector: 'app-view-abandoned-carts',
  templateUrl: './view-abandoned-carts.component.html',
  styleUrls: ['./view-abandoned-carts.component.scss']
})
export class ViewAbandonedCartsComponent implements OnInit {

  breadCrumbTitle: any;
  customerId: any;
  viewData: any = []
  customerName: any;

  constructor(
    private toastr: ToastrService,
    public abandonedCartService: AbandonedCartsService,
    private router: Router,
    private activateRoute: ActivatedRoute,
  ) {
    this.breadCrumbTitle = "View";
  }

  ngOnInit() {

    this.activateRoute.params.subscribe(
      (id: Params) => {
        this.customerId = +id['id'];
        console.log(id);
      }
    );

    Promise.all([this.OnCustomerCarts()]);
  }

  OnCustomerCarts() {
    this.abandonedCartService.onViewcarts(this.customerId)
      .subscribe((response) => {
        let data: any = response;
        data = data.data
        this.viewData = data
        this.viewData.map(i => {
          i.fullName = i.customerDetail.title + " " +
            i.customerDetail.firstName + " " +
            i.customerDetail.lastName;
        })
        this.customerName = this.viewData[0].fullName
        // console.log(JSON.stringify(this.viewData));
      }, (error) => {
        console.log(error)
        this.toastr.error("Some error occured")
      })
  }

  convertToOrder() {
    let siteType = "admin"
    this.abandonedCartService.onConvertToOrder(this.customerId)
      .subscribe((response) => {
        let msg: any = response;
        msg = msg.response.result.orderNo
        this.toastr.success('New Order ' + msg + ' is created successfully!');
        this.router.navigate(['/sale/orders'])

      }, (error) => {
        console.log(error);
      })
  }

}
