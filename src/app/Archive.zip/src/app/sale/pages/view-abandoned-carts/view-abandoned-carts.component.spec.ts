import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAbandonedCartsComponent } from './view-abandoned-carts.component';

describe('ViewAbandonedCartsComponent', () => {
  let component: ViewAbandonedCartsComponent;
  let fixture: ComponentFixture<ViewAbandonedCartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAbandonedCartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAbandonedCartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
