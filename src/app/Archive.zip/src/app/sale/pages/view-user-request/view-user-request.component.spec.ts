import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUserRequestComponent } from './view-user-request.component';

describe('ViewUserRequestComponent', () => {
  let component: ViewUserRequestComponent;
  let fixture: ComponentFixture<ViewUserRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewUserRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUserRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
