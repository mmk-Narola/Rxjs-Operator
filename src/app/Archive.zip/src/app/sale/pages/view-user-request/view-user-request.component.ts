import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbTabsetConfig } from '@ng-bootstrap/ng-bootstrap';
import { UtilityService } from '../../../shared/utility/utility.service';
import { ViewUserRequestService } from '../../../shared/services/sale/view-user-request.service';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { LazyLoadEvent } from 'primeng/api';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-view-user-request',
  templateUrl: './view-user-request.component.html',
  styleUrls: ['./view-user-request.component.scss'],
  animations: [
    trigger('rowExpansionTrigger', [
      state('void', style({
        transform: 'translateX(-10%)',
        opacity: 0
      })),
      state('active', style({
        transform: 'translateX(0)',
        opacity: 1
      })),
      transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
  ],
  providers: [NgbTabsetConfig, NgbAccordionConfig]
})
export class ViewUserRequestComponent implements OnInit {
  start_date: any = "";
  end_date: any = "";
  private _unsubscribe = new Subject<boolean>();
  page: number = 0;
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;
  UserRequestList: any;
  totalCount: any;
  action: any;
  toast: any;
  constructor(
    config: NgbTabsetConfig,
    private router: Router,
    private utilityService: UtilityService,
    private ViewUserRequestService: ViewUserRequestService,
    public datepipe: DatePipe,

  ) {
    config.type = 'pills';
  }
  ngOnInit() {
    this.getAllUserRequestSearch(this.page, this.start_date, this.end_date);
    var Date90Days = new Date(new Date().setDate(new Date().getDate() - 90));
    this.start_date = this.datepipe.transform(Date90Days, 'yyyy-MM-dd');
    var DateToday = new Date(new Date().setDate(new Date().getDate()));
    this.end_date = this.datepipe.transform(DateToday, 'yyyy-MM-dd');
  }

  loadDataLazy(event: LazyLoadEvent) {
    console.log("load");
    this.page = event.first / 10;
    if (!this.start_date && !this.end_date) {
      console.log("1");
      this.getAllUserRequest(this.page);
    }
    else if (!this.start_date) {
      console.log("3");
      this.getAllUserRequest(this.page);
    }
    else if (!this.end_date) {

      this.getAllUserRequest(this.page);
    }
    else {
      console.log("page123");
      this.getAllUserRequestSearch(this.page, this.start_date, this.end_date);
    }
  }

  datefromGlobal(start_date) {
    console.log(start_date);
    this.start_date = start_date;
    if (start_date) {
      this.start_date = start_date;
    }
    else {
    }
    this.getAllUserRequestSearch(this.page, this.start_date, this.end_date);
  }

  datetoGlobal(end_date) {
    console.log(end_date);
    this.end_date = end_date;
    if (end_date) {
      this.end_date = end_date;
    }
    else {
    }
    this.getAllUserRequestSearch(this.page, this.start_date, this.end_date);
  }

  getAllUserRequestSearch(page, start_date, end_date) {
    this.ViewUserRequestService.getAllUserRequestSearch(page, start_date, end_date)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        console.log(success);
        this.UserRequestList = success.data.result;
        console.log("User Request list")
        console.log(this.UserRequestList);
        this.totalCount = success.data.total;
        this.utilityService.resetPage();

      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }

  getAllUserRequest(page) {
    var data = [];
    this.ViewUserRequestService.getAllUserRequest(page).subscribe(
      (success: any) => {

        console.log(success);

        this.UserRequestList = success.data.result;

      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }

  setDate() {
    console.log(this.start_date)
    console.log(this.end_date)
    if (!this.start_date) {
      this.toast.show("Select start data")
    } if (!this.end_date) {
      this.toast.show("Select End data")
    }
    if (this.end_date >= this.start_date) {
      this.getAllUserRequestSearch(this.page, this.start_date, this.end_date)
    } else {
      this.toast.show("End date should be greater then start date")

    }
  }

  clearFilters() {
    this.start_date = null
    this.page = 0
    this.end_date = null
    this.getAllUserRequest(this.page)
  }
}