import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {SellerOrdersComponent} from './components/seller-orders/seller-orders.component';
const routes: Routes = [

  {
    path: '',
    component: SellerOrdersComponent,
    children: [
      {
        path: '',
        redirectTo: 'sellersale',
        pathMatch: 'full'
      },
      // {
      //   path: 'quotations',
      //   component: QuotationComponent
      // },
     
   
       ]
  } 
]; 


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SellersaleRoutingModule { }
