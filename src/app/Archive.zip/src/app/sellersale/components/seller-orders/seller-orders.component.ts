import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-orders',
  templateUrl: './seller-orders.component.html',
  styleUrls: ['./seller-orders.component.scss']
})
export class SellerOrdersComponent implements OnInit {
  products = [
  
    {purchaseOrder:"PO/20092744",date:"29-09-2020",orderTotal:518.40 ,country:"Singapore"},
    {purchaseOrder:"PO/20092742",date:"29-09-2020",orderTotal:846,country:"Malaysia"},
    {purchaseOrder:"PO/20092741",date:"28-09-2020",orderTotal:1846,country:"Singapore"},
    {purchaseOrder:"PO/20092740",date:"28-09-2020",orderTotal:2046,country:"Malaysia"},
    {purchaseOrder:"PO/20092739",date:"28-08-2020",orderTotal:1046,country:"Malaysia"},
    {purchaseOrder:"PO/20092738",date:"27-08-2020",orderTotal:1869,country:"Singapore"},
    {purchaseOrder:"PO/20092737",date:"26-08-2020",orderTotal:2826,country:"Singapore"},

    
    
    ];
  constructor() { }

  ngOnInit() {
  }

}
