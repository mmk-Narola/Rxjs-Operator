import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SellersaleRoutingModule } from './sellersale-routing.module';
import { SellerOrdersComponent } from './components/seller-orders/seller-orders.component';
import {SharedModule} from '../shared/shared.module';
@NgModule({
  imports: [
    CommonModule,
    SellersaleRoutingModule,
    SharedModule
  ],
  declarations: [SellerOrdersComponent]
})
export class SellersaleModule { }
