import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules , CanActivate} from '@angular/router';
import { FullLayoutComponent } from './layouts/full/full-layout.component';
import { ContentLayoutComponent } from './layouts/content/content-layout.component';
import { Full_ROUTES } from './shared/routes/full-layout.routes';
import { CONTENT_ROUTES } from './shared/routes/content-layout.routes';
import {SellerUpdateProductInvComponent} from './seller-update-product-inv/seller-update-product-inv.component';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'auth/login',    
    pathMatch: 'full',

  },
  {
    path:'seller-update-inv',
    component:SellerUpdateProductInvComponent
  },
  {
    path: '',
    component: ContentLayoutComponent,
    data: { title: 'content Views' },
    children: CONTENT_ROUTES
  },
  {
    path: '',
    component: FullLayoutComponent,
    data: { title: 'full Views' },
    children: Full_ROUTES
  },
  // {
  //   path: '**',
  //   redirectTo: 'auth/login',
  //   pathMatch: 'full'
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, { scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
