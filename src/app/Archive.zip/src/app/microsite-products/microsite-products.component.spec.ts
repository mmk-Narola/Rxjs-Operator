import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MicrositeProductsComponent } from './microsite-products.component';

describe('MicrositeProductsComponent', () => {
  let component: MicrositeProductsComponent;
  let fixture: ComponentFixture<MicrositeProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MicrositeProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MicrositeProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
