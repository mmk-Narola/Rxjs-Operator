import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddNewMicrositeProductComponent } from './add-new-microsite-product/add-new-microsite-product.component';
import { MicrositeProductsComponent } from './microsite-products.component';

const routes: Routes = [
  {
    path: '',
    component: MicrositeProductsComponent,
    children: [
      {
        path: '',
        redirectTo: 'microsite-product',
        pathMatch: 'full'
      }
    ]
  },

  {
    path: 'new',
    component: AddNewMicrositeProductComponent,

  },
  {
    path: 'edit/:id',
    component: AddNewMicrositeProductComponent,
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MicrositeProductsRoutingModule { }
