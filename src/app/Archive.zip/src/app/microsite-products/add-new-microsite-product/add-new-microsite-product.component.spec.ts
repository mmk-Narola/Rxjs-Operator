import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewMicrositeProductComponent } from './add-new-microsite-product.component';

describe('AddNewMicrositeProductComponent', () => {
  let component: AddNewMicrositeProductComponent;
  let fixture: ComponentFixture<AddNewMicrositeProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNewMicrositeProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNewMicrositeProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
