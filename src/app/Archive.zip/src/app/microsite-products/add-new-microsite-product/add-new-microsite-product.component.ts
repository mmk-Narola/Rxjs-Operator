import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonServiceService } from '../../shared/services/common-service.service';

@Component({
  selector: 'app-add-new-microsite-product',
  templateUrl: './add-new-microsite-product.component.html',
  styleUrls: ['./add-new-microsite-product.component.scss']
})


export class AddNewMicrositeProductComponent implements OnInit {

  addMicrositeForm: FormGroup;
  isSubmittedaddMicrositeForm: boolean = false;
  editMode = false;
  id: number;
  private _unsubscribe = new Subject<boolean>();
  micrositeTitle: string;
  productDetailsData: any;
  categories: string[];
  file: any;
  files: Array<any> = [];
  selectFile: any
  selected_category: any
  selected_quote: boolean
  selected_brochure: any
  action: any
  selected_image: string = ''
  addMicroProductFormDetails: any
  selected_quote_value: boolean = false
  quoteChanged: boolean = false
  microProductSize: boolean = true;
  url: any;
  product: any;
  dImg: any
  brochureLink: boolean = false
  selectedBrochureLink: string
  imageName: string
  brochureName: string

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private commonService: CommonServiceService,
    private confirmationService: ConfirmationService
  ) { }


  ngOnInit() {
    this.brochureLink = false
    this.dImg = "assets/img/defaultImg.png";
    this.categories = ["Oxygen Concentrator", "Combo Offers", "Rapid Testing Kits"]
    this.quoteChanged = false
    this.commonService.newImage = false
    this.selected_brochure = ""
    this.activatedRoute.params.subscribe(
      (id: Params) => {
        this.id = +id['id']
        this.editMode = id['id'] != null
        if (!this.id) {
          this.micrositeTitle = "Add New Product";
        }
        if (this.id) {
          this.micrositeTitle = "Edit Product";
          this.getMicroProductdetail(this.id);
        }
        this.initForm();
      }
    )
  }

  initForm() {
    let brochure = ""
    let image = ""
    this.addMicrositeForm = new FormGroup({
      name: new FormControl('', Validators.required),
      price: new FormControl('', Validators.required),
      mrp: new FormControl(''),
      image: new FormControl(image),
      brochure: new FormControl(brochure),
      category: new FormControl('', Validators.required),
      min_qty: new FormControl('', Validators.required),
      max_qty: new FormControl('', Validators.required),
      request_quote: new FormControl(false, Validators.required),
      sort_order: new FormControl(''),
      warranty: new FormControl('')
    });
  }

  onSubmitEmailForm() {
    event.preventDefault();

    if (this.id == NaN || this.quoteChanged) {
      this.addMicrositeForm.controls['request_quote'].setValue(this.selected_quote_value);
    }
    this.isSubmittedaddMicrositeForm = true
    if (this.selected_quote != undefined) {
      if (this.selected_quote.toString() == 'true') {
        this.addMicrositeForm.controls['price'].setValue(0.00)
      }
    }

    if (this.addMicrositeForm.invalid) {
      return
    }
    let data = this.addMicrositeForm.value;
    if (this.id) {
      data.id = this.id;
    }

    if (data.mrp == null)
      data.mrp = '0'

    if (data.warranty == null) {
      data.warranty = 0
    }

    if (data.sort_order == null) {
      data.sort_order = 0
    }

    if (data.image == '') {
      this.toastr.error("Please choose an image!");
      return;
    }

    if (data.price == '0' && !data.request_quote) {
      this.toastr.error("Price cannot be 0.");
      return;
    }

    if (data.min_qty >= data.max_qty) {
      this.toastr.error("Maximum Order Quantity should not be less than or equal to Minimum Order Quantity!")
      return;
    }

    let newPrice = data.price
    newPrice = parseFloat(newPrice).toFixed(2);
    data.price = newPrice

    if (!this.id) {
      this.commonService.addMicroProduct(data).pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.toastr.success('Microsite product created successfully!');
          this.router.navigate(['/microsite-products']);
        },
        error => {
          this.toastr.error(error.error.message);
        }
      )
    }

    if (this.id) {
      this.commonService.updateMicroProduct(this.id, data).pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.toastr.success('Microsite product updated successfully!');
          this.router.navigate(['/microsite-products']);

        },
        error => {
          this.toastr.error(error.error.message);
        }
      )
    }
  }


  getMicroProductdetail(id) {
    this.commonService.getMicroProductdetail(id).pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.productDetailsData = success.data;
        this.patchForm(this.productDetailsData);
      },
      error => {
      }
    )
  }
  patchForm(item) {
    this.addMicrositeForm.controls.name.patchValue(item.name);
    this.addMicrositeForm.controls.price.patchValue(item.price);
    this.addMicrositeForm.controls.mrp.patchValue(item.mrp);
    this.addMicrositeForm.controls.image.patchValue(item.image);
    this.addMicrositeForm.controls.brochure.patchValue(item.brochure);
    this.addMicrositeForm.controls.category.patchValue(item.category);
    this.addMicrositeForm.controls.min_qty.patchValue(item.min_qty);
    this.addMicrositeForm.controls.max_qty.patchValue(item.max_qty);
    this.addMicrositeForm.controls.request_quote.patchValue(item.request_quote);
    this.addMicrositeForm.controls.sort_order.patchValue(item.sort_order);
    this.addMicrositeForm.controls.warranty.patchValue(item.warranty);

    this.selected_brochure = item.brochure
    if (this.selected_brochure == "null")
      this.selected_brochure = ""

    if (this.selected_brochure.includes('lumier32.s3')) {
      item.brochure = ""
    }

    if (item.image != null)
      this.selected_image = item.image

    if (item.request_quote == true) {
      this.selected_quote_value = true
    }
    else
      this.selected_quote_value = false

    this.product = item.image
  }

  get signUpControls() {
    return this.addMicrositeForm.controls
  }

  fileChangeEvent(event: any) {
    if (event.target.files.length > 0) {
      const images_upload_url = event.target.files[0];
      this.imageName = images_upload_url.name
      this.addMicrositeForm.patchValue({
        file: images_upload_url
      });
      if (event.target.files[0].size < 200000) {
        {
          this.microProductSize = true;
          this.commonService.newImage = true
          let reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]);
          reader.onload = (event) => {
            this.url = reader.result;
            this.product = this.url;
          }
          this.addMicrositeForm.controls['image'].setValue(images_upload_url ? images_upload_url : '');
        }
      }
      else {
        this.microProductSize = false;
        this.commonService.newImage = false
        this.addMicrositeForm.controls['image'].setValue(images_upload_url ? '' : '');
        this.toastr.error("File size should not exceed 200kb");
      }
    }
  }

  uploadBrochure(event) {
    if (event.target.files.length > 0) {
      const brochure_file = event.target.files[0];
      this.brochureName = brochure_file.name
      this.addMicrositeForm.patchValue({
        brochure: brochure_file
      });
      this.addMicrositeForm.controls['brochure'].setValue(brochure_file ? brochure_file : '');
    }
  }

  selectQuote(value) {
    this.selected_quote = value
    if (value == 'true')
      this.selected_quote_value = true
    else
      this.selected_quote_value = false
    this.quoteChanged = true
  }

  removeCatalogue() {
    this.selected_brochure = ''
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        this.addMicrositeForm.controls['brochure'].setValue('');
        return true;
      },
      reject: () => {
        this.action = null;
      }
    });
  }


  removeImage() {
    this.selected_image = ''
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        this.addMicrositeForm.controls['image'].setValue('');
        this.product = '';
        this.selected_image = '';
        return true;
      },
      reject: () => {
        this.action = null;
      }
    });
  }

  addBrochureLink() {
    this.brochureLink = true
  }

}
