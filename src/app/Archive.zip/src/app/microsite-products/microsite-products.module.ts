import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MicrositeProductsRoutingModule } from './microsite-products-routing.module';
import { MicrositeProductsComponent } from './microsite-products.component';
import { SharedModule } from '../shared/shared.module';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { TagInputModule } from 'ngx-chips';
import { ButtonModule } from 'primeng/button';
import { AddNewMicrositeProductComponent } from './add-new-microsite-product/add-new-microsite-product.component';
import { FileUploadModule } from 'ng2-file-upload';
import { RequiredIfDirective } from './required-if.directive';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { FormsModule } from '@angular/forms';



@NgModule({
  imports: [
    CommonModule,
    MicrositeProductsRoutingModule,
    SharedModule,
    AngularMultiSelectModule,
    SelectDropDownModule,
    NgxDatatableModule,
    TableModule,
    DropdownModule,
    TagInputModule,
    ButtonModule,
    FileUploadModule,
    NgxDatatableModule,
    TableModule,
    FormsModule
  ],
  declarations: [MicrositeProductsComponent, AddNewMicrositeProductComponent, RequiredIfDirective]
})
export class MicrositeProductsModule { }
