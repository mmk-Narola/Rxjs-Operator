import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonServiceService } from '../shared/services/common-service.service';
import { UtilityService } from '../shared/utility/utility.service';

@Component({
  selector: 'app-microsite-products',
  templateUrl: './microsite-products.component.html',
  styleUrls: ['./microsite-products.component.scss']
})
export class MicrositeProductsComponent implements OnInit {
  micrositeProductsList: any
  action: any;
  private _unsubscribe = new Subject<boolean>();
  constructor(
    private service: CommonServiceService,
    private utilityService: UtilityService,
    private confirmationService: ConfirmationService,
    private router: Router,
    private activateRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.getAllMicrositeProducts()
  }
  getAllMicrositeProducts() {
    this.service.getAllMicrositeProducts().subscribe(
      (success: any) => {
        this.micrositeProductsList = success.data;
      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {
      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.service.deleteMicrositeProduct(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.getAllMicrositeProducts();
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });
    }
    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['edit', id], { relativeTo: this.activateRoute })
    }
  }

  setStatus(id: Number, status: Number) {
    let statusData = { id, status }
    this.service.updateMicroProductStatus(statusData).subscribe(
      (success: any) => {
        this.ngOnInit();
      })
  }
}
