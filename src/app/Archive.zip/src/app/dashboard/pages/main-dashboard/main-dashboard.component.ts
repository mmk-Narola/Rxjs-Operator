import { Component, OnInit, ViewChild } from '@angular/core';
import { UtilityService } from '../../../../app/shared/utility/utility.service';
import { DashboardService } from '../../../../app/shared/utility/dashboard.service';
import { NgbProgressbarConfig } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr'
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import * as dayjs from 'dayjs';
import { DaterangepickerDirective } from 'ngx-daterangepicker-material';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { pairwise, takeUntil, filter } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-main-dashboard',
  templateUrl: './main-dashboard.component.html',
  styleUrls: ['./main-dashboard.component.scss'],
  providers: [NgbProgressbarConfig]
})
export class MainDashboardComponent implements OnInit {
  private _unsubscribe = new Subject<boolean>();
  lineChartData: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  countries: any;
  selectedCountry = 1;
  lineChartLabels: Label[] = ['January'];
  topProducts = [];
  currency: any
  currencySymbol: String

  lineChartOptions = {
    responsive: true,
    title: {
      text: 'Avg Vs. Total Orders',
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#FFAF90',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

  // Bar graph
  lineChartDataBar: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsBar: Label[] = ['Loading..'];
  lineChartOptionsBar = {
    responsive: true,
    title: {
      text: 'Products Onboarded Monthly',
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          min: 0,
          max: 5
        }
      }]
    }
  };
  lineChartTypeBar = 'horizontalBar';

  lineChartColorsBar: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#0277BD',
    },
  ];
  // 

  // Onboard Seller Graph
  lineChartDataSeller: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsSeller: Label[] = ['Loading..'];
  lineChartOptionsSeller = {
    responsive: true,
    title: {
      text: 'Sellers Onboarded Monthly',
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };
  lineChartTypeSeller = 'horizontalBar';

  lineChartColorsSeller: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#FFAB91',
    },
  ];
  // Manufacturers

  lineChartDataManu: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsManu: Label[] = ['Loading..'];
  lineChartOptionsManu = {
    responsive: true,
    title: {
      text: 'Manufacturers Onboarded Monthly',
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };
  lineChartTypeManu = 'horizontalBar';

  lineChartColorsManu: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#26C6DA',
    },
  ];
  //
  // Customer Graph
  lineChartDataCustomer: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsCustomer: Label[] = ['Loading..'];
  lineChartOptionsCustomer = {
    responsive: true,
    title: {
      text: 'Customer Overview',
      display: true
    },

    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };
  lineChartTypeCustomer = 'bar';


  lineChartColorsCustomer: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#FF8558',
    },
  ];
  // order Graph
  lineChartDataOrders: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsOrders: Label[] = ['Loading..'];
  lineChartOptionsOrders = {
    responsive: true,
    title: {
      text: 'Orders Overview',
      display: true
    },

    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };
  lineChartTypeOrders = 'bar';

  lineChartColorsOrders: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#0ABC76',
    },
  ];

  // monthly growth chart
  lineChartDataGrowth: ChartDataSets[] = [{ data: [1], label: 'Loading..' }];
  lineChartLabelsGrowth: Label[] = ['Loading..'];
  lineChartOptionsGrowth = {
    responsive: true,
    title: {
      text: 'Monthly Growth Chart',
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    }
  };
  lineChartTypeGrowth = 'line';

  lineChartColorsGrowth: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#FF7181',
    },
  ];

  dashboard: any;
  Chart: any
  matrices: any = [];
  charts: any = [];
  startDate: any = null;
  endDate: any = null;
  currentYear: number = new Date().getFullYear();
  selected: any;
  topFiveSellers = [];
  topFiveCustomers = [];

  @ViewChild(DaterangepickerDirective) picker: DaterangepickerDirective;
  constructor(
    private utilityService: UtilityService,
    private DashboardService: DashboardService,
    config: NgbProgressbarConfig,
    private toast: ToastrService,
    public datepipe: DatePipe,
    private commonService: CommonServiceService,
  ) {
    config.max = 1000;
    config.animated = true;
    config.type = 'success';
    config.height = '5px';
  }

  ngOnInit() {

    this.endDate = this.datepipe.transform(new Date(new Date().setDate(new Date().getDate())), 'yyyy-MM-dd');
    this.startDate = this.datepipe.transform(new Date().getFullYear() + "01-01", 'yyyy-MM-dd');
    this.selected = { start: dayjs(this.startDate).format('YYYY-MM-DD'), end: dayjs(this.endDate).format('YYYY-MM-DD') }
    //Promise.all([this.onGetMetrices()]);
    Promise.all([this.onGetCharts()]);
    Promise.all([this.getCountry()]);
  }

  onGetMetrices() {
    this.DashboardService.getDashboardMetrices(this.startDate, this.endDate, this.selectedCountry)
      .subscribe((response) => {
        let data: any = response;
        data = data.data
        this.matrices = data;
        //  console.log(JSON.stringify(data));
      }, (error) => {
        console.log(error)
        //this.toast.error("Some error occured")
      })
  }

  onGetCharts() {
    this.DashboardService.getDashboardCharts(this.startDate, this.endDate, this.currentYear, this.selectedCountry)
      .subscribe((response) => {
        let data: any = response;
        data = data.data
        this.charts = data;
        //  console.log(JSON.stringify(this.charts))
        this.topFiveSellers = this.charts.top_sellers;
        this.topFiveCustomers = this.charts.top_customers;
        this.lineChartLabels = this.charts.avg_vs_total_orders.label
        this.topProducts = this.charts.top_products

        var data1 = [];
        var data2 = [];
        for (let obj of this.charts.avg_vs_total_orders.data1) {
          data1.push(parseFloat(obj));
        }
        for (let obj of this.charts.avg_vs_total_orders.data2) {
          data2.push(parseFloat(obj));
        }
        this.lineChartData = [{ data: data1, label: 'Data 1' },
        { data: data2, label: 'Data 2' }];

        var dataProduct = [];

        for (let obj of this.charts.total_products.data) {
          dataProduct.push(parseFloat(obj));
        }

        this.lineChartDataBar = [{ data: dataProduct, label: 'Products' }];
        this.lineChartLabelsBar = this.charts.total_products.label;
        // sellers
        var dataSeller = [];
        for (let obj of this.charts.total_sellers.data) {
          dataSeller.push(parseFloat(obj));
        }
        this.lineChartDataSeller = [{ data: dataSeller, label: 'Seller' }];
        this.lineChartLabelsSeller = this.charts.total_sellers.label;
        // manufacturers
        var dataManufactures = [];
        for (let obj of this.charts.total_brands.data) {
          dataManufactures.push(parseFloat(obj));
        }
        this.lineChartDataManu = [{ data: dataManufactures, label: 'Manufacturers' }]
        this.lineChartLabelsManu = this.charts.total_brands.label;

        // total customers;
        var customers = [];
        for (let obj of this.charts.total_customers.data) {
          customers.push(parseFloat(obj));
        }

        this.lineChartDataCustomer = [{ data: customers, label: 'Customers' }]
        this.lineChartLabelsCustomer = this.charts.total_customers.label;

        // order overviews
        var orders = [];
        for (let obj of this.charts.total_orders.data) {
          orders.push(parseFloat(obj));
        }
        this.lineChartDataOrders = [{ data: orders, label: 'Orders' }];
        this.lineChartLabelsOrders = this.charts.total_orders.label;
        // monthly growth chart
        var growthChart = [];
        for (let obj of this.charts.total_sales.data) {
          growthChart.push(parseFloat(obj));
        }
        this.lineChartLabelsGrowth = this.charts.total_sales.label;
        this.lineChartDataGrowth = [{ data: growthChart, label: 'Orders' }]
      }, (error) => {
        console.log(error)
        //this.toast.error("Some error occured")
      })
  }


  onSelectedDateRange(evt: Event) {
    this.startDate = moment(evt['start']).format('YYYY-MM-DD');
    this.endDate = moment(evt['end']).format('YYYY-MM-DD');
    if (this.startDate == 'Invalid date' && this.endDate == 'Invalid date') {
      this.toast.error("No date range selected")
      return;
    } else {
      this.onGetMetrices();
    }
  }

  open() {
    this.picker.open();
  }

  arrayOfStringsToArrayOfObjects(arr: any[]) {
    const newArray = [];
    if (arr != []) {
      arr.forEach(element => {
        newArray.push({
          label: element.itemName,
          value: element.id
        });
      });
    }
    return newArray;
  }

  arrayOfStringsToObjects(arr: any[]) {
    const newArray = [];
    if (arr != []) {
      arr.forEach(element => {
        newArray.push({
          label: element.countryCurrency.id,
          value: element.countryCurrency.symbol
        });
      });
    }
    return newArray;
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = this.arrayOfStringsToArrayOfObjects(success.data);
        this.currency = this.arrayOfStringsToObjects(success.data);
        for (var i = 0; i < this.currency.length; i++) {
          if (this.currency[i].label == this.selectedCountry) {
            this.currencySymbol = this.currency[i].value;
          }
        }
      },
      error => {
      }
    )
  }

  OnSelectCountry(evt: any) {
    this.selectedCountry = evt.value;
    for (var i = 0; i < this.currency.length; i++) {
      if (this.currency[i].label == this.selectedCountry) {
        this.currencySymbol = this.currency[i].value;
      }
    }
    this.onGetCharts()
    this.onGetMetrices();
  }

}
