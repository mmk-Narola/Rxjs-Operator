import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { ChartistModule } from 'ng-chartist';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatchHeightModule } from '../shared/directives/match-height.directive';
import { DashboardLayoutComponent } from './dashboard-layout/dashboard-layout.component';
import { MainDashboardComponent } from './pages/main-dashboard/main-dashboard.component';
//import { SharedModule } from 'app/shared/shared.module';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ChartsModule } from 'ng2-charts';
import {DropdownModule} from 'primeng/primeng';
import {ButtonModule} from 'primeng/button';
@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    ChartistModule,
    NgbModule,
    MatchHeightModule,
    FormsModule,
    NgxDaterangepickerMd.forRoot(),
    ChartsModule,
    DropdownModule,
    ButtonModule
    //SharedModule
  ],
  exports: [],
  declarations: [DashboardLayoutComponent, MainDashboardComponent],
  providers: []
})
export class DashboardModule { }
