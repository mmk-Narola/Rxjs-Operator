import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experience-layout',
  templateUrl: './experience-layout.component.html',
  styleUrls: ['./experience-layout.component.scss']
})
export class ExperienceLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
