import { Component, OnInit } from '@angular/core';
import {WalletService} from '../../shared/services/wallet/wallet.service';
import {Router,ActivatedRoute} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-get-top-details',
  templateUrl: './get-top-details.component.html',
  styleUrls: ['./get-top-details.component.scss']
})
export class GetTopDetailsComponent implements OnInit {
  products:any;
  userSelect = "topup"
  constructor(private service : WalletService,private router:Router,
    private activateRoute: ActivatedRoute,
    private toastr: ToastrService
    ) { }
  
    userSearched(value){
      this.userSelect = value
    }
  ngOnInit() {
    Promise.all([this.getAllPromos()])
  }

  promoData:any;
  getAllPromos(){
    this.service.getAllTopUpDetails()
    .subscribe((response)=>{
      this.promoData = response;
      this.promoData = this.promoData.data.results
      console.log(this.promoData)
    },(error)=>{
      console.log(error)
    })
  }
  addNew(){
    this.router.navigate(['/pay/add-topup'],{ relativeTo: this.activateRoute })
  }
/* this function
will edit the top up data
*/
edit(id){
  console.log("edit..")
  this.router.navigate(['/pay/edit-topup'+`/${id}`],{ relativeTo: this.activateRoute })
}
delete(id){
  this.service.deleteExisitngTopuP(id)
  .subscribe((response)=>{
    console.log(response)
    let message : any = response;
    message = message.data
    this.toastr.success(message)
    this.getAllPromos()
  },(error)=>{
    console.log(error)
  })
}
}
