import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTopDetailsComponent } from './get-top-details.component';

describe('GetTopDetailsComponent', () => {
  let component: GetTopDetailsComponent;
  let fixture: ComponentFixture<GetTopDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTopDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTopDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
