import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../../shared/services/common-service.service';
import { ToastrService } from 'ngx-toastr';
import { WalletService } from '../../shared/services/wallet/wallet.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

interface Country {
  _id: string,
  country: string
}
@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.scss']
})
export class WalletComponent implements OnInit {
  wallet: any = {}
  heading: any;
  dataBasedOnID: any;
  addWalletForm: FormGroup;
  id: number;
  editMode: boolean;
  countries: Country[];
  walletDetails: any;
  isSubmittedAddWalletForm: boolean = false
  private _unsubscribe = new Subject<boolean>();
  constructor(private toastr: ToastrService,
    private walletService: WalletService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    public commonService: CommonServiceService
  ) { }

  fetchTopUpDetailsPerID() {
    this.walletService.getSingleTopUpDetails(this.id)
      .subscribe((success: any) => {
        this.walletDetails = success.data
        this.patchForm(this.walletDetails);
      }, (error) => {
        console.log(error)
      })
  }

  ngOnInit() {
    this.getCountry();
    this.activateRoute.params.subscribe(
      (id: Params) => {
        this.id = +id['id']
        this.editMode = id['id'] != null
        if (!this.id) {
          this.heading = "Add New Top-up"
        }
        if (this.id) {
          this.heading = "Update Existing Top-up"
          this.fetchTopUpDetailsPerID();
        }
        this.initForm()
        this.getCountry();
      }
    )
  }

  initForm() {
    this.addWalletForm = new FormGroup({
      title: new FormControl(null, Validators.required),
      amount: new FormControl(null, Validators.required),
      cashbackAmount: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
      countryId: new FormControl(null, Validators.required)
    });
  }

  countryData: any;
  countryDisplay: boolean = true;
  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = this.arrayOfStringsToArrayOfObjects(success.data);
      },
      error => {
      }
    )
  }

  arrayOfStringsToArrayOfObjects(arr: any[]) {
    const newArray = [];
    arr.forEach(element => {
      newArray.push({
        label: element.itemName,
        value: element.id
      });
    });
    return newArray;
  }

  submitTopUpDetails() {
    event.preventDefault();
    this.isSubmittedAddWalletForm = true
    if (this.addWalletForm.invalid) {
      return
    }
    let data = this.addWalletForm.value;
    data.type = "topup"
    if (this.id) {
      data.id = this.id;
    }
    if (!this.id) {
      this.walletService.addNewTopUp(data).pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.toastr.success('Top-up Plan Created Successfully!');
          this.router.navigate(['/pay/topups']);
        },
        error => {
          this.toastr.error(error.error.message);
        }
      )
    }
    if (this.id) {
      this.walletService.updateTopUpDetails(this.id, data).pipe(takeUntil(this._unsubscribe)).subscribe(
        (success: any) => {
          this.toastr.success('Top-up Plan Updated Successfully!');
          this.router.navigate(['/pay/topups']);

        },
        error => {
          this.toastr.error(error.error.message);
        }
      )
    }
  }

  patchForm(item) {
    this.addWalletForm.controls.title.patchValue(item.title);
    this.addWalletForm.controls.amount.patchValue(item.amount);
    this.addWalletForm.controls.countryId.patchValue(item.countryId);
    this.addWalletForm.controls.cashbackAmount.patchValue(item.cashbackAmount);
    this.addWalletForm.controls.description.patchValue(item.description);
  }

  get signUpControls() {
    return this.addWalletForm.controls;
  }
}
