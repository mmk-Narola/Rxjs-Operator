import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {WalletComponent} from './wallet/wallet.component';
import {Pay32Component} from './pay32/pay32.component';
import {GetTopDetailsComponent} from './get-top-details/get-top-details.component';
import {AdjustCustomerWalletComponent} from './adjust-customer-wallet/adjust-customer-wallet.component';
import {CustomerWalletTableComponent} from './components/customer-wallet-table/customer-wallet-table.component'
const routes: Routes = [
  {
    path: '',
    component: Pay32Component,
    
    children: [
      {
        path: '',
        redirectTo: 'pay',
        pathMatch: 'full'
      },
   
      {
        // path: 'wallet',
        path: 'topups',
        component: GetTopDetailsComponent
      },
      {
        path:'wallet',
        component: CustomerWalletTableComponent
      },
      {
        path: 'add-topup',
        component: WalletComponent
      },
      {
        path: 'edit-topup/:id',
        component: WalletComponent
      },
      {
        path:'edit-customer-wallet/:id',
        component:AdjustCustomerWalletComponent
      }
    ]
    
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Pay32RoutingModule { }
