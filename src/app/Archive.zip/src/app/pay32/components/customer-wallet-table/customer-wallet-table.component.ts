import { Component, OnInit } from '@angular/core';
import { WalletService } from '../../../shared/services/wallet/wallet.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../../shared/services/customers/customer.service';
@Component({
  selector: 'app-customer-wallet-table',
  templateUrl: './customer-wallet-table.component.html',
  styleUrls: ['./customer-wallet-table.component.scss']
})
export class CustomerWalletTableComponent implements OnInit {
  promoData: any;
  custID: any;
  activeTab = 0;
  pageTitle = "Top Up Wallet";
  payType = "Wallet";
  constructor(private service: WalletService, private router: Router,
    private activateRoute: ActivatedRoute,
    private customerService: CustomerService
  ) {

    this.custID = this.activateRoute.snapshot.paramMap.get("id")
    console.log("customer id", this.custID)
  }

  ngOnInit() {
    this.getAllCustomersWhoUseWallet();
    this.getAllCustomersWhoUsePayLater();
  }
  customerData: any;
  paylaterData: any;
  getAllCustomersWhoUseWallet() {
    this.service.customerWhoUseWallet('Wallet')
      .subscribe((response) => {
        this.customerData = response;
        this.customerData = this.customerData.data;
        this.customerData.map(i => {
          i.fullName = i.customer.title + " " + i.customer.firstName + " " + i.customer.lastName;
          i.country = i.customer.country.country
          i.email = i.customer.Email;
          i.wallet = parseFloat(i.wallet)
          i.spent = parseFloat(i.spent)
        });

      }, (error) => {
        console.log(error)
      })
  }

  getAllCustomersWhoUsePayLater() {
    this.service.customerWhoUseWallet('PAY32-BNPL')
      .subscribe((response) => {
        this.paylaterData = response;
        this.paylaterData = this.paylaterData.data

        this.paylaterData.map(i => {
          i.fullName = i.customer.title + " " + i.customer.firstName + " " + i.customer.lastName;
          i.country = i.customer.country.country;
          i.email = i.customer.Email;
          i.wallet = parseFloat(i.wallet)
          i.spent = parseFloat(i.spent)
        });

      }, (error) => {
        console.log(error)
      })
  }

  edit(id) {
    this.router.navigate(['/pay/edit-customer-wallet/' + id])
  }

  walletDetails(id) {
    this.customerService.payType = this.payType;
    this.router.navigate(['/customer/walletHistory/' + id])
    this.customerService.customerId = id
  }

  onSetActive(idx) {
    this.activeTab = idx;
    if (idx == 0)
      this.payType = "Wallet"
    else
      this.payType = "PAY32-BNPL"
    this.pageTitle = idx == 0 ? "Top Up Wallet" : "Pay Later";
  }
}
