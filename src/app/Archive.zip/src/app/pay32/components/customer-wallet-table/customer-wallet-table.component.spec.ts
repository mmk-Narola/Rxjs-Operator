import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerWalletTableComponent } from './customer-wallet-table.component';

describe('CustomerWalletTableComponent', () => {
  let component: CustomerWalletTableComponent;
  let fixture: ComponentFixture<CustomerWalletTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerWalletTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerWalletTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
