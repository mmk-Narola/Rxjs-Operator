import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay32',
  templateUrl: './pay32.component.html',
  styleUrls: ['./pay32.component.scss']
})
export class Pay32Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
