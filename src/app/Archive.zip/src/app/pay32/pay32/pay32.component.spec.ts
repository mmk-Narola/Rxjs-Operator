import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Pay32Component } from './pay32.component';

describe('Pay32Component', () => {
  let component: Pay32Component;
  let fixture: ComponentFixture<Pay32Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Pay32Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Pay32Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
