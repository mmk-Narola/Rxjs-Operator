import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Pay32RoutingModule } from './pay32-routing.module';
import { WalletComponent } from './wallet/wallet.component';
import { Pay32Component } from './pay32/pay32.component';
import {SharedModule} from '../shared/shared.module';
import { GetTopDetailsComponent } from './get-top-details/get-top-details.component';
import { CustomerWalletTableComponent } from './components/customer-wallet-table/customer-wallet-table.component';
import { AdjustCustomerWalletComponent } from './adjust-customer-wallet/adjust-customer-wallet.component';

@NgModule({
  imports: [
    CommonModule,
    Pay32RoutingModule,
    SharedModule
  ],
  declarations: [WalletComponent, Pay32Component, GetTopDetailsComponent, CustomerWalletTableComponent, AdjustCustomerWalletComponent]
})
export class Pay32Module { }
