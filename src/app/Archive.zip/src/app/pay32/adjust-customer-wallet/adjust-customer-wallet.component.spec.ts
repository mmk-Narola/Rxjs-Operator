import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustCustomerWalletComponent } from './adjust-customer-wallet.component';

describe('AdjustCustomerWalletComponent', () => {
  let component: AdjustCustomerWalletComponent;
  let fixture: ComponentFixture<AdjustCustomerWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdjustCustomerWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustCustomerWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
