import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { WalletService } from '../../shared/services/wallet/wallet.service';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-adjust-customer-wallet',
  templateUrl: './adjust-customer-wallet.component.html',
  styleUrls: ['./adjust-customer-wallet.component.scss']
})
export class AdjustCustomerWalletComponent implements OnInit {
  custID: any;
  customerData: any;
  adjustType = ["Credit", "Debit"]
  addAdjustCustomerWalletForm: FormGroup;
  isSubmittedAdjustWalletForm: boolean = false
  userAdjustType: string = "Credit"
  selectedType: any;

  constructor(
    private router: Router,
    private service: WalletService,
    private toast: ToastrService,
    private activateRoute: ActivatedRoute) {

  }

  userSelectAdjustType(value) {
    this.userAdjustType = value
  }

  fetchCustomerWalletDetails() {
    this.service.singleCustomerWhoUseWallet(this.custID)
      .subscribe((response) => {
        this.customerData = response
        this.customerData = this.customerData.data
        this.patchForm(this.customerData)
      }, (error) => {
        console.log(error)
      })
  }

  initForm() {
    this.addAdjustCustomerWalletForm = new FormGroup({
      firstName: new FormControl(null),
      email: new FormControl(null),
      mobileNumber: new FormControl(null),
      wallet: new FormControl(null),
      pay32bnpl: new FormControl(null),
      comments: new FormControl(null),
      amount: new FormControl(null),
      type: new FormControl(false, Validators.required),
    });
  }

  ngOnInit() {
    this.initForm();
    this.custID = this.activateRoute.snapshot.paramMap.get("id")
    this.fetchCustomerWalletDetails()
  }

  submit() {
    event.preventDefault();
    if (this.selectedType == undefined) {
      this.toast.error("Type is required")
      return;
    }

    let adjustTypeDetails = this.addAdjustCustomerWalletForm.value

    if (adjustTypeDetails.amount == null) {
      this.toast.error("Adjust amount is required")
      return;
    }
    let data: any = {
      "adminComments": this.addAdjustCustomerWalletForm.value.comments,
      "message": this.userAdjustType == "Credit" ? 'Credited by Admin' : 'Debited by Admin',
      "type": this.selectedType,
      "txnSource": "Admin",
      "txnSourceId": "0"
    }
    if (this.userAdjustType == "Credit") {
      data.amountCredit = adjustTypeDetails.amount
      data.amountDebit = 0
    } else if (this.userAdjustType == "Debit") {
      data.amountDebit = adjustTypeDetails.amount
      data.amountCredit = 0
      if (Number(data.amountDebit) > Number(this.customerData.wallet.wallet)) {
        this.toast.warning("Debit amount cannot be more than current balance");
        return;
      }
    }

    this.service.walletAdjustment(this.custID, data)
      .subscribe((response) => {
        let message: any = response
        message = message.message
        this.toast.success(message)
        this.router.navigate(['/customer/customers'])
      }, (error) => {
        console.log(error)
      })
  }

  back() {
    this.router.navigate(['/customer/customers'])
  }

  patchForm(item) {
    this.addAdjustCustomerWalletForm.controls.firstName.patchValue(item.customer.firstName);
    this.addAdjustCustomerWalletForm.controls.email.patchValue(item.customer.Email);
    this.addAdjustCustomerWalletForm.controls.mobileNumber.patchValue(item.customer.mobileNumber);
    this.addAdjustCustomerWalletForm.controls.wallet.patchValue(item.wallet.wallet);
    this.addAdjustCustomerWalletForm.controls.pay32bnpl.patchValue(item.PAY32BNPL.pay32bnpl);
  }

  selectType(value) {
    this.selectedType = value
  }

  get signUpControls() {
    return this.addAdjustCustomerWalletForm.controls
  }
}
