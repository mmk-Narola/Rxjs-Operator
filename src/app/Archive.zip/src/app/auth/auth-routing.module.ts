import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RecoverPasswordComponent } from './recover-password/recover-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SellerLoginComponent } from './seller-login/seller-login.component';
import { AuthGuardService as AuthGuard } from '../shared/services/auth/auth-guard.service';
import { ChangePasswordComponent } from './change-password/change-password.component';
const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: 'login',
  //   pathMatch: 'full'
  // },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'sellerlogin',
    component: SellerLoginComponent
  },
  {
    path: 'recover-password',
    component: RecoverPasswordComponent,

  },
  {
    path: 'reset-password',
    component: ResetPasswordComponent,

  },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
