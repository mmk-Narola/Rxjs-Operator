import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidators } from 'ng5-validation';
import { validateAllFormFields } from '../../shared/utility/custom-validators';
import { AuthService } from '../../shared/services/auth.service';
import { SharedDataService } from '../../shared/services/shared-data.service';
import { Router } from '@angular/router';
import { UtilityService } from '../../shared/utility/utility.service';
import { HttpResponse } from '@angular/common/http';
@Component({
  selector: 'app-seller-login',
  templateUrl: './seller-login.component.html',
  styleUrls: ['./seller-login.component.scss']
})
export class SellerLoginComponent implements OnInit {
  isLoginSubmitted: boolean = false;
  loginForm = new FormGroup({
    // username: new FormControl('', [
    //   Validators.required,
    //   CustomValidators.username
    // ]),
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  });
  constructor(
    private authService: AuthService,
    private sharedDataService: SharedDataService,
    private router: Router,
    private utility: UtilityService
  ) { }

  ngOnInit() {
    if (localStorage.getItem('admintoken')) {
      this.router.navigateByUrl('/dashboard/main');
    } else {
      this.router.navigate(['/auth/sellerlogin']);
    }
  }

  onSubmit() {
    this.isLoginSubmitted = true;
    if (this.loginForm.valid) {
      console.log("value",this.loginForm.value)
      this.utility.loaderStart();
      this.authService
        .sellerLogin(this.loginForm.value)
        .subscribe(
          (response: HttpResponse<any>) => {

            localStorage.setItem('admintoken', response.headers.get('authtoken'));
            this.sharedDataService.updateUserDataStore(response.body.data);
            this.router.navigateByUrl('/sellerdashboard');
          },
          error => {
            console.log(error)
            this.utility.routingAccordingToError(error);
          }
        )
        .add(() => {
          this.utility.resetPage();
        });
    } else {
      validateAllFormFields(this.loginForm);
    }
  }

}
