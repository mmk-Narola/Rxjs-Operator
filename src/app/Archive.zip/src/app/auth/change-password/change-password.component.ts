import { Component, OnInit } from "@angular/core";
import { NgxUiLoaderService } from "ngx-ui-loader";
import { ErrorHandlerService } from "../../shared/services/error-handler.service";
import { AuthService } from "../../shared/services/auth.service";
import { UtilityService } from "../../shared/utility/utility.service";
import {
  FormGroup,
  FormControl,
  Validators,
  ValidatorFn,
  ValidationErrors,
} from "@angular/forms";
import {
  passwordMatchValidator,
  validateAllFormFields,
} from "../../shared/utility/custom-validators";
import { MessageService } from "primeng/api";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.scss"],
})
export class ChangePasswordComponent implements OnInit {
  changeStatus: boolean;
  changePasswordForm: FormGroup;
  passwordChanged: boolean = false;

  isChangePasswordSubmitted: boolean = false;
  constructor(
    private loader: NgxUiLoaderService,
    private errorHandler: ErrorHandlerService,
    private authService: AuthService,
    private utility: UtilityService,
    private messageService: MessageService
  ) { }

  ngOnInit() {
    this.changeStatus = false;

    this.changePasswordForm = new FormGroup(
      {
        oldPassword: new FormControl("", [
          Validators.required,
        ]),
        newPassword: new FormControl("", [
          Validators.required,
          Validators.minLength(8),
        ]),
        confirmPassword: new FormControl("", [
          Validators.required,
          Validators.minLength(8),
        ]),
      },
      { validators: this.passwordErrorValidator }
    );
  }

  changePassword() {
    this.isChangePasswordSubmitted = true;
    if (this.changePasswordForm.valid) {
      this.loader.start();
      const changePasswordBody = {
        oldPassword: this.changePasswordForm.controls.oldPassword.value,
      };
      console.log(this.changePasswordForm.value);
      console.log(changePasswordBody);
      this.authService.changePassword(this.changePasswordForm.value).subscribe(
        (response) => {
          this.messageService.add({
            severity: "success",
            summary: `Password Updated`,
          });
          this.utility.scrollToTop();
          this.changeStatus = true;
          this.loader.stop();
        },
        (error) => {
          this.errorHandler.routeAccordingToError(error);
          this.loader.stop();
        }
      );
      this.utility.scrollToTop();
    } else {
      validateAllFormFields(this.changePasswordForm);
    }
  }

  passwordErrorValidator: ValidatorFn = (
    control: FormGroup
  ): ValidationErrors | null => {
    const password = control.get("newPassword");
    const repeatPassword = control.get("confirmPassword");
    if (password.value != "" && repeatPassword.value != "")
      return password.value != repeatPassword.value
        ? { passwordError: true }
        : null;
  };
}
