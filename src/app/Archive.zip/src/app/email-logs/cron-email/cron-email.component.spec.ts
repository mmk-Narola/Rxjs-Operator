import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CronEmailComponent } from './cron-email.component';

describe('CronEmailComponent', () => {
  let component: CronEmailComponent;
  let fixture: ComponentFixture<CronEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CronEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CronEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
