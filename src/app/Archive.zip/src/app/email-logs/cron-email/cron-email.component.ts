import { Component, OnInit } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonServiceService } from '../../shared/services/common-service.service';
import { UtilityService } from '../../shared/utility/utility.service';

@Component({
  selector: 'app-cron-email',
  templateUrl: './cron-email.component.html',
  styleUrls: ['./cron-email.component.scss']
})
export class CronEmailComponent implements OnInit {
  page: number = null;
  cronEmailList: any
  action: any;
  private _unsubscribe = new Subject<boolean>();
  constructor(
    private service: CommonServiceService,
    private utilityService: UtilityService,
    private confirmationService: ConfirmationService
  ) { }

  ngOnInit() {
    this.getAllCronEmails(this.page)
  }
  getAllCronEmails(page) {
    this.service.getAllCronEmails(this.page).subscribe(
      (success: any) => {
        this.cronEmailList = success.data.results;
      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }

  getDropDownValue(id) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        this.service.deleteCronEmail(id).pipe(takeUntil(this._unsubscribe)).subscribe(
          (success: any) => {
            this.getAllCronEmails(this.page);
          },
          error => {
          }
        )
      },
      reject: () => {
        this.action = null;
      }
    });
  }
}

