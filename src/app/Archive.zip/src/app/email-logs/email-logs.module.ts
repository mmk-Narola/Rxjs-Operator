import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailLogsRoutingModule } from './email-logs-routing.module';
import { CronEmailComponent } from './cron-email/cron-email.component';
import { ButtonModule, DropdownModule, SharedModule } from 'primeng/primeng';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { TableModule } from 'primeng/table';
import { TagInputModule } from 'ngx-chips';

@NgModule({
  imports: [
    CommonModule,
    EmailLogsRoutingModule,
    SharedModule,
    AngularMultiSelectModule,
    NgxDatatableModule,
    TableModule,
    DropdownModule,
    TagInputModule,
    ButtonModule,
  ],
  declarations: [CronEmailComponent]
})
export class EmailLogsModule { }
