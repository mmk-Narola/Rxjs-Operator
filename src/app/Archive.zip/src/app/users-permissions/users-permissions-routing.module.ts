import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersLayoutComponent } from './users-layout/users-layout.component';
import { UsersComponent } from './pages/users/users.component';
import { PermissionsComponent } from './pages/permissions/permissions.component';
import { AddUserComponent } from './pages/users/add-user/add-user.component';
import { AddPermissionComponent } from './pages/permissions/add-permission/add-permission.component';
import { AdminUsersComponent } from './pages/admin-users/admin-users.component';
import { AddAdminUserComponent } from './pages/admin-users/add-admin-user/add-admin-user.component';

const routes: Routes = [{

  path: '',
  children: [
    {
      path: '',
      component: UsersLayoutComponent,
      children: [

        {
          path: 'user-permissions',
          component: PermissionsComponent,
          data: {
            title: 'Permissions'
          }
        },
        {
          path: 'new',
          component: AddUserComponent,

        },
        {
          path: 'users',
          component: UsersComponent,
        },
        {
          path: 'newPermission',
          component: AddPermissionComponent,
        },
        // {
        //   path: ':id',
        //   component: UsersComponent,

        // },
        {
          path: 'edit/:id',
          component: AddUserComponent,

        },
        // {
        //   path: ':id',
        //   component: PermissionsComponent,

        // },
        {
          path: 'editPermission/:id',
          component: AddPermissionComponent,

        },
        {
          path: 'admin-users',
          component: AdminUsersComponent,
          data: {
            title: 'Admin'
          }
        },
        {
          path: 'add-admin-user',
          component: AddAdminUserComponent,
        },
        {
          path: 'edit-admin-user/:id',
          component: AddAdminUserComponent,
        },
      ]
    }
  ]

}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersPermissionsRoutingModule { }
