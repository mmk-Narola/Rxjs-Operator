import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { takeUntil, startWith, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { UtilityService } from '../../../shared/utility/utility.service';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { ConfirmationService, LazyLoadEvent } from 'primeng/api';
import { UsersPermissionsService } from '../../../shared/services/users-permissions.service';


@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.scss']
})
export class AdminUsersComponent implements OnInit {

  @ViewChild(Table) primeNGTable: Table;
  adminUsersList: any[];
  private _unsubscribe = new Subject<boolean>();
  page: number = 0;
  totalCount: any;
  action: any;
  searchTerms$ = new Subject<string>();
  countries: any[];
  countryId: number = null;
  roles: any[];

  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private UsersPermissionsService: UsersPermissionsService,
    private commonService: CommonServiceService,
    private confirmationService: ConfirmationService,
  ) { }

  ngOnInit() {
    this.initiateSearch();
    this.getCountry();
    this.getRole();
  }

  onAddAdminUser() {
    this.router.navigate(['../add-admin-user'], { relativeTo: this.activateRoute })
  }

  loadDataLazy(event: LazyLoadEvent) {
    console.log("load");
    this.page = event.first / 10;
    if (!this.countryId)
      this.getAllAdminUsers(this.page);
    else
      this.getAllAdminUserSearch(this.page, this.countryId);

  }

  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      switchMap((term: string) => this.UsersPermissionsService.getAllAdminUserSearch(this.page, this.countryId
      ))
    ).subscribe((success: any) => {
      this.adminUsersList = success.data.results;
      this.totalCount = success.data.total;
      this.utilityService.resetPage();
    })
  }

  getAllAdminUserSearch(page, countryId) {
    this.UsersPermissionsService.getAllAdminUserSearch(page, countryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        console.log(success);
        this.adminUsersList = success.data.results;
        this.totalCount = success.data.total;
        this.utilityService.resetPage();
      })
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Edit') {
      console.log(id)
      this.router.navigate(['../edit-admin-user', id], { relativeTo: this.activateRoute })
    }
  }

  getAllAdminUsers(page) {
    this.UsersPermissionsService.getAllAdminUsers(page).subscribe(
      (success: any) => {
        this.adminUsersList = success.data.results;
        console.log("Users List")
        console.log(success)
        this.totalCount = success.data.total;
      },
      error => {
        this.utilityService.resetPage();
      }
    );
  }


  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  getRole() {
    this.commonService.getRole().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.roles = success.data;
      },
      error => {
      }
    )
  }

  onChange(deviceValue) {
    if (deviceValue) {
      this.countryId = deviceValue;
    }
    else {
    }
    this.getAllAdminUserSearch(this.page, this.countryId);
  }


}
