import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SellerproductsRoutingModule } from './sellerproducts-routing.module';
import { SellerproductsComponent } from './components/sellerproducts/sellerproducts.component';
import {SharedModule} from '../shared/shared.module';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    SellerproductsRoutingModule
  ],
  declarations: [SellerproductsComponent]
})
export class SellerproductsModule { }
