import { Component, OnInit } from '@angular/core';
import {PaymentDetailService} from '../shared/services/sale/payment-detail.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-seller-update-product-inv',
  templateUrl: './seller-update-product-inv.component.html',
  styleUrls: ['./seller-update-product-inv.component.scss']
})
export class SellerUpdateProductInvComponent implements OnInit {
seller:any ={}
respData:any;
showDisplay = false;
  constructor(public service:PaymentDetailService ,private toast:ToastrService) { }
  validateSeller(){
    this.service.validateSeller(this.seller.accountId)
    .subscribe((response)=>{
      console.log(response)
      this.respData = response
      
      if(Object.keys(this.respData.data).length > 0){
        console.log('user validated')
        this.getAllOutStockData()
        this.toast.success("User validated")
        localStorage.setItem('sellerAccount',this.seller.accountId)
      } else {
        this.toast.error("user is not authorized")
      }
    },(error)=>{
      this.toast.error("User is not authorized")
      console.log(error)
    })
  }
 
  ngOnInit() {
    if(!localStorage.getItem('sellerAccount')){
      console.log("create session")
    } else {
      this.getAllOutStockData()
    }
  
  }
  products:any;
  getAllOutStockData(){
    this.service.getAllOutStockOrderProducts()
    .subscribe((response)=>{
      this.products = response;
      this.products = this.products.response.result
      this.showDisplay = true;
    },(error)=>{
      console.log(error)
    })
  }
  getOrderDetail(outId){
    this.products.some((elem)=>{
      if (elem.outOfStockId == outId ){
        if (elem.orderProductStatus == 'Out of Stock'){
          elem.orderProductStatus = 'In Stock'
        } else if (elem.orderProductStatus = 'In Stock') {
          elem.orderProductStatus = 'Out of Stock'
        }
      }
    })
  }

  updateStatus(){
    let data = this.products.filter(o => o.orderProductStatus === 'In Stock')
    this.service.updateOutOrderBySeller(data)
    .subscribe((response)=>{
      console.log("data updated successfully",response)
      this.toast.success('Data Updated Successfully')
      this.getAllOutStockData()
    },(error)=>{
      console.log("issues while updating the status , try again later",error)
      this.toast.success('Error while updating the table')
    })
  }

}
