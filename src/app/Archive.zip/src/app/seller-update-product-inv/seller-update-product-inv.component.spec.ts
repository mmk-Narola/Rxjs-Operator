import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerUpdateProductInvComponent } from './seller-update-product-inv.component';

describe('SellerUpdateProductInvComponent', () => {
  let component: SellerUpdateProductInvComponent;
  let fixture: ComponentFixture<SellerUpdateProductInvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerUpdateProductInvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerUpdateProductInvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
