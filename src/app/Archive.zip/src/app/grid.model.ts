export class DynamicGrid{   
    id:string;
    Varient:string;
    PNCDE:string;
    quantity:string;
    is_sale:string;
    sale_price:string;
    price:string;
    wallet:string;
    seller_Id : number;
}
