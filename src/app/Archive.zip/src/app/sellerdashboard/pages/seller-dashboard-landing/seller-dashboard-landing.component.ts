import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-dashboard-landing',
  templateUrl: './seller-dashboard-landing.component.html',
  styleUrls: ['./seller-dashboard-landing.component.scss']
})
export class SellerDashboardLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
