import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerDashboardLandingComponent } from './seller-dashboard-landing.component';

describe('SellerDashboardLandingComponent', () => {
  let component: SellerDashboardLandingComponent;
  let fixture: ComponentFixture<SellerDashboardLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerDashboardLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerDashboardLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
