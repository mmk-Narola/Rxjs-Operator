import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerDashboardLayoutComponent } from './seller-dashboard-layout.component';

describe('SellerDashboardLayoutComponent', () => {
  let component: SellerDashboardLayoutComponent;
  let fixture: ComponentFixture<SellerDashboardLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellerDashboardLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerDashboardLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
