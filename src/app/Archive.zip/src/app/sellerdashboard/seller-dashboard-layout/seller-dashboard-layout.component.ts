import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-dashboard-layout',
  templateUrl: './seller-dashboard-layout.component.html',
  styleUrls: ['./seller-dashboard-layout.component.scss']
})
export class SellerDashboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  dummyData =[
    
    {"name":"Views","value":7947},
    {"name":"Click","value":5950},
    {"name":"Add To Carts","value":2817},
    {"name":"Purchase","value":2399},
  ]

  products = [
  
	{title:"Harmonize™",click:300,view:412,addToCart:120,purchase:101,quantity:200,purchased:197,country:'Singapore '},
	{title:"Herculite™ Ultra",click:499,view:512,addToCart:222,purchase:200,quantity:342,purchased:300,country:'Singapore '},
	{title:"SonicFill™ 2",click:555,view:489,addToCart:119,purchase:102,quantity:343,purchased:312,country:'Singapore '},
	{title:"Vertise™ Flow",click:278,view:789,addToCart:234,purchase:213,quantity:123,purchased:100,country:'Singapore '},
	{title:"Premise™",click:349,view:456,addToCart:121,purchase:110,quantity:882,purchased:800,country:'Singapore '},
	{title:"Premise™ Flowable",click:777,view:843,addToCart:221,purchase:199,quantity:738,purchased:712,country:'Singapore '},
	{title:"Revolution™ Formula 2",click:345,view:643,addToCart:121,purchase:101,quantity:278,purchased:201,country:'Singapore '},
	{title:"CompoRoller™",click:324,view:345,addToCart:222,purchase:200,quantity:383,purchased:380,country:'Singapore '},
	{title:"Kolor + Plus™",click:345,view:394,addToCart:111,purchase:109,quantity:378,purchased:371,country:'Singapore '},
	{title:"Herculite™ Ultra Flow",click:567,view:612,addToCart:221,purchase:121,quantity:443,purchased:400,country:'Singapore '},
	{title:"Dyad Flow",click:312,view:744,addToCart:101,purchase:100,quantity:643,purchased:602,country:'Singapore '},
	{title:"Herculite Précis",click:389,view:521,addToCart:211,purchase:200,quantity:748,purchased:702,country:'Singapore '},
	{title:"Herculite Précis Flow",click:573,view:644,addToCart:122,purchase:100,quantity:793,purchased:723,country:'Singapore '},
	{title:"Premisa™",click:337,view:543,addToCart:671,purchase:543,quantity:748,purchased:700,country:'Singapore '}
  ];
}
