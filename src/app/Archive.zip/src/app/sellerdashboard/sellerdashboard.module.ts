import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SellerdashboardRoutingModule } from './sellerdashboard-routing.module';
import { SellerDashboardLayoutComponent } from './seller-dashboard-layout/seller-dashboard-layout.component';
import { SellerDashboardLandingComponent } from './pages/seller-dashboard-landing/seller-dashboard-landing.component';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    SellerdashboardRoutingModule
  ],
  declarations: [SellerDashboardLayoutComponent, SellerDashboardLandingComponent]
})
export class SellerdashboardModule { }
