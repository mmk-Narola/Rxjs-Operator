import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SellerDashboardLayoutComponent} from './seller-dashboard-layout/seller-dashboard-layout.component';
import {SellerDashboardLandingComponent} from './pages/seller-dashboard-landing/seller-dashboard-landing.component';

const routes: Routes = [
  {
    path: '',
    component: SellerDashboardLayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'seller-main',
        pathMatch: 'full'
      },
      {
        path: 'seller-main',
        component: SellerDashboardLayoutComponent
      }
    ],  
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SellerdashboardRoutingModule { }
