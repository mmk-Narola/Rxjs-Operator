import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PromtionSectionComponent } from './components/promtion-section/promtion-section.component';
import { AddNewPromotionComponent } from './components/add-new-promotion/add-new-promotion.component';
import { PageOffersComponent } from './components/page-offers/page-offers.component';
import { AddNewOfferComponent } from './components/page-offers/add-new-offer/add-new-offer.component';
import { PromotionCategoriesComponent } from './components/promotion-categories/promotion-categories.component';
import { AddNewPromotionCategoryComponent } from './components/promotion-categories/add-new-promotion-category/add-new-promotion-category.component';
import { SchemeComponent } from './components/rewards/scheme/scheme.component';
import { AddNewSchemeComponent } from './components/rewards/scheme/add-new-scheme/add-new-scheme.component';
import { UserRedemptionComponent } from './components/rewards/user-redemption/user-redemption.component';
const routes: Routes = [

  {
    path: '',
    component: PromtionSectionComponent,
    children: [
      {
        path: '',
        redirectTo: 'promotion',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: 'promo-codes',
    component: PromtionSectionComponent
  },
  {
    path: 'add',
    component: AddNewPromotionComponent
  },
  {
    path: 'edit/:id',
    component: AddNewPromotionComponent
  },
  {
    path: 'page-offers',
    component: PageOffersComponent
  },
  {
    path: 'page-offers/add-page-offer',
    component: AddNewOfferComponent
  },
  {
    path: 'page-offers/edit-page-offer/:id',
    component: AddNewOfferComponent
  },
  {
    path: 'promotion-categories',
    component: PromotionCategoriesComponent
  },
  {
    path: 'promotion-categories/add-category',
    component: AddNewPromotionCategoryComponent
  },
  {
    path: 'promotion-categories/edit-category/:id',
    component: AddNewPromotionCategoryComponent
  },
  {
    path: 'rewards/schemes',
    component: SchemeComponent
  },
  {
    path: 'rewards/schemes/add-scheme',
    component: AddNewSchemeComponent
  },
  {
    path: 'rewards/schemes/edit-scheme/:id',
    component: AddNewSchemeComponent
  },
  {
    path: 'rewards/userRedemption',
    component: UserRedemptionComponent
  },
  {
    path: 'rewards/userRedemption/add-scheme',
    component: AddNewSchemeComponent
  },
  {
    path: 'rewards/schemes/edit-scheme/:id',
    component: AddNewSchemeComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PromotionsRoutingModule { }
