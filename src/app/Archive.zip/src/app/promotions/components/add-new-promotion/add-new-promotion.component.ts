import { Component, Input, OnInit } from '@angular/core';
import { PromotionService, } from '../../../shared/services/sale/promotion.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr'
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { NgStyle } from '@angular/common';
import { SelectItem } from 'primeng/primeng';

import { CutomerModel } from "../../../sale/customer.model";
import { CustomerService } from "../../../shared/services/customers/customer.service";
import { ColorPickerService } from 'ngx-color-picker';
import { containsElement } from '@angular/animations/browser/src/render/shared';
import { parse } from 'querystring';



@Component({
  selector: 'app-add-new-promotion',
  templateUrl: './add-new-promotion.component.html',
  styleUrls: ['./add-new-promotion.component.scss']

})


export class AddNewPromotionComponent implements OnInit {


  paramValue: any
  editPromData: any;
  productTitle: string;
  selectedDate = new Date();
  editMode: boolean;
  id: number;
  customerModel: CutomerModel[] = [];
  element: CutomerModel;
  customers: any = [];
  selectedPromoType: number;
  selectedPromoTypeName: string;
  promoDescription: string;
  customerIds = [];
  promoCodeTypeDict: any = [];
  countryId: any
  isPromoFixed: boolean = false;
  config = {
    displayKey: "fullName", //if objects array passed which key to be displayed defaults to description
    search: true, //true/false for the search functionlity defaults to false,
    height: "200px", //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
    placeholder: "Select Customer", // text to be displayed when no item is selected defaults to Select,
    customComparator: () => { }, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
    limitTo: 10, // number thats limits the no of options displayed in the UI (if zero, options will not be limited)
    moreText: "more", // text to be displayed whenmore than one items are selected like Option 1 + 5 more
    noResultsFound: "No results found!", // text to be displayed when no items are found while searching
    searchOnKey: "fullName", // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
  };

  configPromo = {
    displayKey: "promotypename", //if objects array passed which key to be displayed defaults to description
    search: false, //true/false for the search functionlity defaults to false,
    height: "auto", //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
    placeholder: "Select Promocode Type", // text to be displayed when no item is selected defaults to Select,
    customComparator: () => { }, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
    limitTo: 2, // number thats limits the no of options displayed in the UI (if zero, options will not be limited)
    moreText: "more", // text to be displayed whenmore than one items are selected like Option 1 + 5 more
    noResultsFound: "No results found!", // text to be displayed when no items are found while searching
    searchOnKey: "promotypename", // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
  };

  SelectPromoType(event) {
    this.selectedPromoType = event.value.id;
    this.selectedPromoTypeName = event.value.promotypename;
    if (this.selectedPromoTypeName == "Fixed Amount")
      this.isPromoFixed = true
    else
      this.isPromoFixed = false
  }

  constructor(public service: PromotionService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private common: CommonServiceService,
    private activatedRoute: ActivatedRoute,

    private customerService: CustomerService,

  ) {

    this.paramValue = this.route.snapshot.params.id
    if (this.paramValue) {
      this.getAllCountries()
      this.service.getAllPromotionsPerId(this.paramValue).subscribe((response) => {
        this.editPromData = response;
        this.editPromData = this.editPromData.data
        this.updateModule(this.editPromData)
        this.getAllCustomers(this.editPromData.countryId)
        console.log(response)
      })
    }
    else {
      this.service.promotionData = {}
      this.getAllCountries()
    }
    console.log(this.paramValue)
    this.href = this.router.url;
    console.log(this.href)
  }

  href: any;
  ngOnInit() {
    // this.getAllCountries()

    this.activatedRoute.params.subscribe(
      (id: Params) => {
        this.id = +id['id']
        console.log(this.id);
        this.editMode = id['id'] != null
        if (!this.id) {
          this.productTitle = "Add New Promotion";
        }
        if (this.id) {
          this.productTitle = "Edit New Promotion";
        }
      }
    )

    this.promoCodeTypeDict = [
      { id: 1, promotypename: "Percentage" },
      { id: 2, promotypename: "Fixed Amount" }
    ]
  }
  countryModel: any;
  getAllCountries() {
    this.common.getCountry().subscribe((response) => {
      this.countryModel = response;
      this.countryModel = this.countryModel.data
    }, (error) => {
      this.toastr.error(error.message)
    })
  }


  customerData: any;
  getAllCustomers(countryId) {
    this.customerService.getCountryCustomers(null, countryId).subscribe(
      (response) => {
        this.customerData = response;
        this.customerData = this.customerData.data.results;
        this.customerData.map(i => {
          i.fullName = i.title + " " + i.firstName + " " + i.lastName + ' ' + '-' + ' ' + i.Email
        })
        this.customerModel = this.customerData;
        console.log(this.customerModel);
      },
      (error) => {
        this.toastr.error(error.message);
      }
    );
  }

  customerDataChangeDetect(event) {
    var customer: any = [];
    var customerDetails: any = [];
    console.log(event.value);
    customerDetails.push(event.value);
    console.log(customerDetails);

    for (let record of customerDetails) {
      for (let key of record) {
        customer.push({
          "customerId": key.customerId,
          "fullName": key.fullName
        });
      }
    }
    this.customers = customer;
  }

  checkValidations() {
    if (this.selectedPromoTypeName == "Fixed Amount") {
      this.service.promotionData.maximumBill = 0;
    }
    if (this.service.promotionData.startDate > this.service.promotionData.endDate) {
      this.toastr.show("Start date should be less than the end date")
      return;
    }

    if (!this.service.promotionData.title) {
      this.toastr.show("Enter valid title")
      return
    }
    if (!this.service.promotionData.code) {
      this.toastr.show("Enter valid code")
      return
    }
    if (!this.service.promotionData.status) {
      this.toastr.show("Please choose status to be active or inactive")
      return
    }
    if (!this.service.promotionData.quotaPerUser) {
      this.toastr.show("Please choose quota Per User to be active or inactive")
      return
    }
    if (!this.service.promotionData.startDate) {
      this.toastr.show("Please choose valid start date")
      return
    }
    if (!this.service.promotionData.endDate) {
      this.toastr.show("Please choose valid end date")
      return
    }
    if (this.service.promotionData.maximumBill == undefined) {
      this.toastr.show("Please choose valid maximum discount amount")
      return
    }
    if (this.service.promotionData.minimumBill == undefined) {
      this.toastr.show("Please choose valid minimum discount amount")
      return
    }
    if (!this.service.promotionData.discount) {
      this.toastr.show("Please choose valid discount")
      return
    }
    if (this.service.promotionData.promotionDate == undefined) {
      this.toastr.show("Please choose valid date")
      return
    }
    if (this.service.promotionData.country == undefined) {
      this.toastr.show("Please select a country")
      return
    }
    if (this.selectedPromoType == undefined) {
      this.toastr.show("Please choose Discount Type")
      return
    }

    else {
      this.submitOrder()
    }
    console.log(this.service.promotionData)

  }
  countryCHose(e) {
    this.getAllCustomers(e.id)
    this.countryId = e.id;
    console.log(e)
    console.log(this.service.promotionData.country)
  }
  submitOrder() {
    if (this.paramValue) {
      if (this.service.promotionData.firstTimeUser == "1") {
        this.service.promotionData.firstTimeUser = 1
      } else {
        this.service.promotionData.firstTimeUser = 0
      }
      if (this.service.promotionData.status == "INACTIVE" || this.service.promotionData.status == "0") {
        this.service.promotionData.status = "0"
      } else {
        this.service.promotionData.status = "1"
      }

      if (this.customers.length == 0) {
        this.customers = null;
      }
      if (this.selectedPromoTypeName == "Fixed Amount") {
        this.service.promotionData.maximumBill = 0;
      }

      console.log(this.service.promotionData, "update")

      let data = {
        "name": this.service.promotionData.title,
        "code": this.service.promotionData.code,
        "customersdetail": this.customers,
        "promoCodeType": this.selectedPromoType,
        "discount": this.service.promotionData.discount,
        "countryId": this.service.promotionData.country.id,
        "minimumBillAmount": this.service.promotionData.minimumBill,
        "maximumDiscountAmount": this.service.promotionData.maximumBill,
        "startDate": this.service.promotionData.startDate,
        "endDate": this.service.promotionData.endDate,
        "userQuota": this.service.promotionData.quotaPerUser,
        "firstTimeUser": this.service.promotionData.firstTimeUser,
        "promoDate": this.service.promotionData.promotionDate,
        "description": this.promoDescription,
        "status": this.service.promotionData.status,
      }
      console.log("data update", data)

      this.service.updatePromotion(this.paramValue, data)
        .subscribe((response) => {
          console.log(response)
          let data: any = response;
          data = data.message
          this.toastr.success(data)
          this.router.navigate(['/promotion'])
        }, (error) => {
          console.log(error)
          this.toastr.error("Error While updating the offer")
        })
    } else {
      if (this.service.promotionData.firstTimeUser == 1) {
        this.service.promotionData.firstTimeUser = 1
      } else {
        this.service.promotionData.firstTimeUser = 0
      }

      if (this.customers.length == 0) {
        this.customers = null;
      }




      let data = {
        "name": this.service.promotionData.title,
        "code": this.service.promotionData.code,
        "promoCodeType": this.selectedPromoType,
        "customersdetail": this.customers,
        "description": this.promoDescription,
        "discount": this.service.promotionData.discount,
        "countryId": this.service.promotionData.country.id,
        "minimumBillAmount": this.service.promotionData.minimumBill,
        "maximumDiscountAmount": this.service.promotionData.maximumBill,
        "startDate": this.service.promotionData.startDate,
        "endDate": this.service.promotionData.endDate,
        "userQuota": this.service.promotionData.quotaPerUser,
        "firstTimeUser": this.service.promotionData.firstTimeUser,
        "promoDate": this.service.promotionData.promotionDate,
        "status": this.service.promotionData.status
      }
      console.log("submit is", data)
      this.service.addNewPromotion(data).subscribe((response) => {
        console.log(response)
        this.toastr.success("Promotion Offer created successfully")
        this.router.navigate(['/promotion'])
      }, (error) => {
        this.toastr.success("Issue while creating the promotion offer")
        console.log(error)
      })
    }
  }

  submit() {
    if (this.service.promotionData.status == "INACTIVE") {
      this.service.promotionData.status = "0"
    } else {
      this.service.promotionData.status = "1"
    }

    this.checkValidations()
  }

  updateModule(data) {

    data.endDate = new Date(data.endDate).toISOString().split('T')[0];
    data.startDate = new Date(data.startDate).toISOString().split('T')[0];
    data.promoDate = new Date(data.promoDate).toISOString().split('T')[0];

    if (data.status == 1) {
      this.service.promotionData.status = "ACTIVE"
    } else {
      this.service.promotionData.status = "INACTIVE"
    }

    if (data.firstTimeUser === 0) {
      console.log("yeah")
      this.service.promotionData.firstTimeUser = "0"
    } else {
      this.service.promotionData.firstTimeUser = "1"
    }

    if (data.promoCodeType == 1) {
      this.selectedPromoTypeName = "Percentage";
    } else {
      this.selectedPromoTypeName = "Fixed Amount";
      this.isPromoFixed = true;
    }


    if (this.countryModel) {
      this.countryModel.some((elem) => {

        if (elem.id == data.countryId) {
          this.service.promotionData.country = elem
        }

      })
    }

    this.service.promotionData.title = data.name
    this.service.promotionData.code = data.code
    this.service.promotionData.discount = data.discount
    this.selectedPromoType = data.promoCodeType
    this.service.promotionData.minimumBill = data.minimumBillAmount
    this.service.promotionData.maximumBill = data.maximumDiscountAmount
    this.service.promotionData.startDate = data.startDate
    this.service.promotionData.endDate = data.endDate
    this.service.promotionData.quotaPerUser = data.userQuota
    this.service.promotionData.promotionDate = data.promoDate
    this.promoDescription = data.description
    this.service.promotionData.customerId = data.customersdetail
  }
}

