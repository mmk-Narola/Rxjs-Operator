import { Component, OnInit } from '@angular/core';
import { PromotionService } from '../../../shared/services/sale/promotion.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr'
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { DatePipe } from '@angular/common'
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UtilityService } from '../../../shared/utility/utility.service';
@Component({
  selector: 'app-promtion-section',
  templateUrl: './promtion-section.component.html',
  styleUrls: ['./promtion-section.component.scss']
})
export class PromtionSectionComponent implements OnInit {
  page: number = null;
  startDate: any = null;
  endDate: any = null;
  private _unsubscribe = new Subject<boolean>();

  constructor(public service: PromotionService,
    private router: Router,
    private toast: ToastrService,
    private common: CommonServiceService,
    public datepipe: DatePipe,
    private utilityService: UtilityService,
  ) { }

  ngOnInit() {
    Promise.all([this.getAllCountries()])
    var Date90Days = new Date(new Date().setDate(new Date().getDate() - 90));
    this.startDate = this.datepipe.transform(Date90Days, 'yyyy-MM-dd');
    var DateToday = new Date(new Date().setDate(new Date().getDate()));
    this.endDate = this.datepipe.transform(DateToday, 'yyyy-MM-dd');
    this.getAllPromotionsDateSearch(this.page, this.startDate, this.endDate);
  }

  countryModel: any;
  getAllCountries() {
    this.common.getCountry().subscribe((response) => {
      this.countryModel = response;
      this.countryModel = this.countryModel.data
      console.log("country model is,", this.countryModel)
    }, (error) => {
      console.log(error)
    })
  }
  promData: any
  getAllPromotions(page) {
    this.service.getAllPromotions(this.page).subscribe((response) => {
      this.promData = response;
      this.promData = this.promData.data.results
      console.log(this.promData)
      const length = Object.keys(this.promData).length;
      for (var i = 0; i < length; i++) {
        this.promData[i].status == 1 ? this.promData[i].status = 'ACTIVE' : this.promData[i].status = 'INACTIVE'
        this.promData[i].promoCodeType == 1 ? this.promData[i].promoCodeType = 'Percentage' : this.promData[i].promoCodeType = 'Fixed Amount'
      }
    })
  }

  onChange(data) {
    console.log(data)
  }
  edit(data, value) {
    console.log(data)
    this.service.promotionDataPerIdForEdit = data
    this.router.navigate([`/promotion/edit/${data.id}`])
  }

  delete(data, value) {
    console.log(data.id)
    this.service.deletePromotionData(data.id)
      .subscribe((response) => {
        let message: any = response
        message = message.data
        console.log(response)
        this.toast.success(message)
        this.getAllPromotions(this.page)
      }, (error) => {
        console.log(error.error)
        this.toast.error(error.error.message)
      })
  }
  add() {
    console.log("route..")
    this.router.navigate(['/promotion/add'])
  }

  clearFilters() {
    this.startDate = null
    this.page = null
    this.endDate = null
    this.getAllPromotions(this.page)
  }

  setDate() {
    if (!this.startDate) {
      this.toast.show("Select start data")
    } if (!this.endDate) {
      this.toast.show("Select End data")
    }
    if (this.endDate >= this.startDate) {
      this.getAllPromotionsDateSearch(this.page, this.startDate, this.endDate)
    } else {
      this.toast.show("End date should be greater then start date")

    }
  }

  getAllPromotionsDateSearch(page, start_date, end_date) {
    this.service.getAllPromotionsDateSearch(page, start_date, end_date)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        console.log(success);
        this.promData = success.data.results;
        const length = Object.keys(this.promData).length;
        for (var i = 0; i < length; i++) {
          this.promData[i].status == 1 ? this.promData[i].status = 'ACTIVE' : this.promData[i].status = 'INACTIVE'
          this.promData[i].promoCodeType == 1 ? this.promData[i].promoCodeType = 'Percentage' : this.promData[i].promoCodeType = 'Fixed Amount'
        }
        this.utilityService.resetPage();

      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }
}
