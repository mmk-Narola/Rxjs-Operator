import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromtionSectionComponent } from './promtion-section.component';

describe('PromtionSectionComponent', () => {
  let component: PromtionSectionComponent;
  let fixture: ComponentFixture<PromtionSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromtionSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromtionSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
