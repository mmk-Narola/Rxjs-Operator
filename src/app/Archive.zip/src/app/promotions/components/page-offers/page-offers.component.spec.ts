import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageOffersComponent } from './page-offers.component';

describe('PageOffersComponent', () => {
  let component: PageOffersComponent;
  let fixture: ComponentFixture<PageOffersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageOffersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageOffersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
