import { Component, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { distinctUntilChanged, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { PromotionService } from '../../../shared/services/sale/promotion.service';
import { UtilityService } from '../../../shared/utility/utility.service';

interface Country {
  _id: string,
  country: string
}

@Component({
  selector: 'app-page-offers',
  templateUrl: './page-offers.component.html',
  styleUrls: ['./page-offers.component.scss']
})
export class PageOffersComponent implements OnInit {
  pageOffersList: any
  private _unsubscribe = new Subject<boolean>();
  countries: Country[];
  countryId: any = "";
  searchKey: any = "";
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;
  searchTerms$ = new Subject<string>();
  action: any;
  convertHTML;

  constructor(
    private promotionService: PromotionService,
    private utilityService: UtilityService,
    private toastr: ToastrService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private commonService: CommonServiceService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    this.convertHTML = this.sanitizer;
    this.getCountry();
    this.initiateSearch();
  }

  setStatus(id: Number, adminStatus: Number) {
    let statusData = { id, adminStatus }
    this.promotionService.updatePageOffersStatus(statusData).subscribe(
      (success: any) => {
        this.ngOnInit()
      },
      error => {
      })
  }

  onAddPageOffers() {
    this.router.navigate(['../page-offers/add-page-offer'], { relativeTo: this.activateRoute })
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {
      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.promotionService.deletePageOfferData(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.toastr.info("Page Offer deleted successfully!");
              this.getAllPageOffers(this.searchKey, this.countryId);
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });
    }

    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../page-offers/edit-page-offer/', id], { relativeTo: this.activateRoute })
    }
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  onChange(deviceValue) {
    this.countryId = deviceValue;
    this.getAllPageOffers(this.searchKey, this.countryId);
  }

  getAllPageOffers(searchKey, countryId) {
    this.promotionService.getAllPageOffers(searchKey, countryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        this.pageOffersList = success.data;
        this.utilityService.resetPage();
      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }

  filterGlobal(searchTerm) {
    this.primeNGTable.first = 0;
    this.searchTerms$.next(searchTerm);
  }

  initiateSearch() {
    this.searchTerms$.pipe(
      takeUntil(this._unsubscribe),
      startWith(''),
      distinctUntilChanged(),
      switchMap((term: string) => this.promotionService.getAllPageOffers(term, this.countryId
      ))
    ).subscribe((success: any) => {
      console.log(success);
      this.pageOffersList = success.data;
      this.utilityService.resetPage();
    })
  }

}
