import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromotionCategoriesComponent } from './promotion-categories.component';

describe('PromotionCategoriesComponent', () => {
  let component: PromotionCategoriesComponent;
  let fixture: ComponentFixture<PromotionCategoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromotionCategoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromotionCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
