import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Subject } from 'rxjs';
import { distinctUntilChanged, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { CommonServiceService } from '../../../shared/services/common-service.service';
import { PromotionService } from '../../../shared/services/sale/promotion.service';
import { UtilityService } from '../../../shared/utility/utility.service';

interface Country {
  _id: string,
  country: string
}

@Component({
  selector: 'app-promotion-categories',
  templateUrl: './promotion-categories.component.html',
  styleUrls: ['./promotion-categories.component.scss']
})
export class PromotionCategoriesComponent implements OnInit {
  promotionalCategoriesList: any
  private _unsubscribe = new Subject<boolean>();
  countries: Country[];
  countryId: any = "";
  @ViewChild(Table) tableComponent: Table;
  @ViewChild(Table) primeNGTable: Table;
  action: any
  constructor(
    private promotionService: PromotionService,
    private utilityService: UtilityService,
    private toastr: ToastrService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private commonService: CommonServiceService

  ) { }

  ngOnInit() {
    this.getCountry();
    this.getAllPromotionalCategories(this.countryId);
  }
  setStatus(id: Number, adminStatus: Number) {
    let statusData = { id, adminStatus }
    this.promotionService.updatePromotionalCategoryStatus(statusData).subscribe(
      (success: any) => {
        this.ngOnInit()
      },
      error => {
      })
  }

  onAddPromotionalCategory() {
    this.router.navigate(['../promotion-categories/add-category'], { relativeTo: this.activateRoute })
  }

  getDropDownValue(event, id) {
    if (event.currentTarget.firstChild.data === 'Delete') {
      this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',
        accept: () => {
          this.promotionService.deletePromotionalCategory(id).pipe(takeUntil(this._unsubscribe)).subscribe(
            (success: any) => {
              this.toastr.info("Promotional Category deleted successfully!");
              this.getAllPromotionalCategories(this.countryId);
            },
            error => {
            }
          )
        },
        reject: () => {
          this.action = null;
        }
      });
    }

    if (event.currentTarget.firstChild.data === 'Edit') {
      this.router.navigate(['../promotion-categories/edit-category/', id], { relativeTo: this.activateRoute })
    }
  }

  getCountry() {
    this.commonService.getCountry().pipe(takeUntil(this._unsubscribe)).subscribe(
      (success: any) => {
        this.countries = success.data;
      },
      error => {
      }
    )
  }

  onChange(deviceValue) {
    this.countryId = deviceValue;
    this.getAllPromotionalCategories(this.countryId);
  }

  getAllPromotionalCategories(countryId) {
    this.promotionService.getAllPromotionalCategories(countryId)
      .pipe(
        takeUntil(this._unsubscribe)
      )
      .subscribe((success: any) => {
        this.promotionalCategoriesList = success.data;
        this.utilityService.resetPage();
      },
        error => {
          this.utilityService.routingAccordingToError(error);
        })
  }

}
