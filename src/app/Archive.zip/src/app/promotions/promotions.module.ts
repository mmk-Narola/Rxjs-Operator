import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';

import { PromotionsRoutingModule } from './promotions-routing.module';
import { PromtionSectionComponent } from './components/promtion-section/promtion-section.component';
import { TableModule } from 'primeng/table';
import { SharedModule } from '../../app/shared/shared.module';
import { AddNewPromotionComponent } from './components/add-new-promotion/add-new-promotion.component';

import { DropdownModule } from 'primeng/primeng';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { PageOffersComponent } from './components/page-offers/page-offers.component';
import { AddNewOfferComponent } from './components/page-offers/add-new-offer/add-new-offer.component';
import { PromotionCategoriesComponent } from './components/promotion-categories/promotion-categories.component';
import { AddNewPromotionCategoryComponent } from './components/promotion-categories/add-new-promotion-category/add-new-promotion-category.component';
import { SchemeComponent } from './components/rewards/scheme/scheme.component';
import { AddNewSchemeComponent } from './components/rewards/scheme/add-new-scheme/add-new-scheme.component';
import { UserRedemptionComponent } from './components/rewards/user-redemption/user-redemption.component';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PromotionsRoutingModule,
    TableModule,

    DropdownModule,
    SelectDropDownModule
  ],
  providers: [CurrencyPipe], // added for currency symbol
  declarations: [PromtionSectionComponent, AddNewPromotionComponent, PageOffersComponent, AddNewOfferComponent, PromotionCategoriesComponent, AddNewPromotionCategoryComponent, SchemeComponent, AddNewSchemeComponent, UserRedemptionComponent]
})
export class PromotionsModule { }
