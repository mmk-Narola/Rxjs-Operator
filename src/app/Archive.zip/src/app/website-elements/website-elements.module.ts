import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 0
import { SharedModule } from '../../app/shared/shared.module';

import { WebsiteElementsRoutingModule } from './website-elements-routing.module';
import { WebsiteElementsLayoutComponent } from './website-elements-layout/website-elements-layout/website-elements-layout.component';
import { BannersComponent } from './pages/banners/banners.component';
import { AddBannerComponent } from './pages/banners/add-banner/add-banner.component';
import { UploadFileComponent } from './pages/upload-file/upload-file.component';
import { UploadNewFileComponent } from './pages/upload-file/upload-new-file/upload-new-file.component';

@NgModule({
  imports: [
    CommonModule,
    WebsiteElementsRoutingModule,
    SharedModule
  ],
  declarations: [WebsiteElementsLayoutComponent, BannersComponent, AddBannerComponent, UploadFileComponent, UploadNewFileComponent]
})
export class WebsiteElementsModule { }
