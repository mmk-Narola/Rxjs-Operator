import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WebsiteElementsLayoutComponent } from '../website-elements/website-elements-layout/website-elements-layout/website-elements-layout.component';
import { BannersComponent } from './pages/banners/banners.component';
import { AddBannerComponent } from './pages/banners/add-banner/add-banner.component';
import { UploadFileComponent } from './pages/upload-file/upload-file.component';
import { UploadNewFileComponent } from './pages/upload-file/upload-new-file/upload-new-file.component';

const routes: Routes = [
  {
    path: '',
    component: WebsiteElementsLayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'website-elements',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: 'upload-files',
    component: UploadFileComponent
  },
  {
    path: 'upload-new-file',
    component: UploadNewFileComponent
  },
  {
    path: 'banners',
    component: BannersComponent,
    data: {
      title: 'Banners'
    }
  },
  {
    path: 'new-banner',
    component: AddBannerComponent,
  },
  {
    path: ':id',
    component: BannersComponent,
  },
  {
    path: 'edit-banner/:id',
    component: AddBannerComponent,

  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WebsiteElementsRoutingModule { }
