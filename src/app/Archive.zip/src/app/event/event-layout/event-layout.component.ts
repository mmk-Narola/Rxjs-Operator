import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-layout',
  templateUrl: './event-layout.component.html',
  styleUrls: ['./event-layout.component.scss']
})
export class EventLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
