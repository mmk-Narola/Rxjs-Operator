import { RouteInfo } from './sidebar.metadata';

// Sidebar menu Routes and data
export const ROUTES: RouteInfo[] = [
  {
    path: '/dashboard',
    title: 'Dashboard',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },
  {
    path: '/customers',
    title: 'Customers',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/customer/customers', title: 'Customers', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/customer/customer-groups', title: 'Customer Groups', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
    ]
  },

  {
    path: '/sellers',
    title: 'Sellers',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/seller/sellers', title: 'Sellers', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/seller/seller-activities', title: 'Seller Activities', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/seller/seller-payout', title: 'Seller Payout', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/seller/product-list', title: 'Product Approvals', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] }
    ]
  },
  //  {
  //   path: '/sellers',
  //   title: 'Sale',
  //   icon: 'ft-users',
  //   class: 'has-sub',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: [
  //     { path: '/orders/orders', title: 'Orders', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
  //    ]},
  {
    path: '/catalogues',
    title: 'Catalogue',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/catalogues/products', title: 'Products', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/catalogues/manufacturing-brand', title: 'Manufacturer / Brands', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/catalogues/categories', title: 'Categories', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/catalogues/parent-categories', title: 'Parent Categories', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/catalogues/country-origin', title: 'Country Origin', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },

    ]
  },
  {
    path: '/systemsetting',
    title: 'System Settings',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/systemsetting/supplytype', title: 'Supply Type', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/country', title: 'Country', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/return-reason', title: 'Return Reason', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/delivery-charge', title: 'Delivery Charge', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/cancel', title: 'Cancel Reason', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/tax', title: 'Tax', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/systemsetting/sentemail', title: 'Sent Emails', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] }

    ]
  },
  {
    path: '/users',
    title: 'User & Permission',
    icon: 'ft-user-check',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/user-permissions/users', title: 'Users', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/user-permissions/user-permissions', title: 'Permissions', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/user-permissions/admin-users', title: 'Admin Users', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
    ]
  },
  {
    path: '/website-elements',
    title: 'Website Elements',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/website-elements/banners', title: 'Banners', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/website-elements/upload-files', title: 'Upload File', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
    ]
  },
  {
    path: '/sale',
    title: 'Sale',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/sale/orders', title: 'Order', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/sale/quotations', title: 'Quotation', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/sale/abandonedcarts', title: 'Abandoned Carts', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/sale/userRequest', title: 'User Request', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
    ]
  },

  {
    path: '/pay',
    title: 'Pay32',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/pay/topups', title: 'Top Up Plans', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/pay/wallet', title: 'Customer Wallet', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },

    ]
  },

  {
    path: '/promotion',
    title: 'Promotion',
    icon: 'ft-users',
    class: 'has-sub',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: [
      { path: '/promotion/promo-codes', title: 'Promo Codes', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/promotion/page-offers', title: 'Page Offers', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      { path: '/promotion/promotion-categories', title: 'Promotional Categories', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
      {
        path: '/promotion/rewards',
        title: 'Rewards',
        icon: '',
        class: 'has-sub',
        badge: '',
        badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
        isExternalLink: false,
        submenu: [
          { path: '/promotion/rewards/schemes', title: 'Schemes', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
          { path: '/promotion/rewards/userRedemption', title: 'User Redemption', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] }
        ]
      }
    ]
  },
  {
    path: '/email-logs',
    title: 'Email Logs',
    icon: 'ft-users',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },
  {
    path: '/microsite-products',
    title: 'Corporate Products',
    icon: 'ft-users',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },


  // {
  //   path: '/users',
  //   title: 'Users',
  //   icon: 'ft-users',
  //   class: 'has-sub',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: [
  //     {
  //       path: '/users/expert-listing',
  //       title: 'Expert Listing',
  //       icon: '',
  //       class: '',
  //       badge: '',
  //       badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //       isExternalLink: false,
  //       submenu: []
  //     },
  //     {
  //       path: '/users/professional-listing',
  //       title: 'Professional Listing',
  //       icon: '',
  //       class: '',
  //       badge: '',
  //       badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //       isExternalLink: false,
  //       submenu: []
  //     },

  //   ]
  // },
  // {
  //   path: '/companies',
  //   title: 'Companies',
  //   icon: 'fa fa-building-o',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // },
  // {
  //   path: '/experience',
  //   title: 'Experience',
  //   icon: 'fa fa-tasks',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // },
  // {
  //   path: '/categories',
  //   title: 'Categories',
  //   icon: 'fa fa-tasks',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // },
  // {
  //   path: '/skill',
  //   title: 'Skills',
  //   icon: 'fa fa-tasks',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // },
  // {
  //   path: '/event',
  //   title: 'Events',
  //   icon: 'fa fa-tasks',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // },
  // {
  //   path: '/questions',
  //   title: 'Questions',
  //   icon: 'fa fa-tasks',
  //   class: '',
  //   badge: '',
  //   badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
  //   isExternalLink: false,
  //   submenu: []
  // }
];
