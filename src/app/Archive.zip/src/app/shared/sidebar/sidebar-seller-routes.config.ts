import { RouteInfo } from './sidebar.metadata';

// Sidebar menu Routes and data
export const SELLERROUTES: RouteInfo[] = [
  {
    path: '/sellerdashboard',
    title: 'Seller Dashboard',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },

 

  {
    path: '/seller/sellersale',
    title: 'Orders',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  
  },


  {
    path: '/seller/sellerproducts',
    title: 'Products',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },
  {
    path: '/sellerdashboard',
    title: 'PO Statements',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },

  {
    path: '/sellerdashboard',
    title: 'Logs',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },

  {
    path: '/sellerdashboard',
    title: 'Notifications',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },
  {
    path: '/sellerdashboard',
    title: 'Profile',
    icon: 'ft-home',
    class: '',
    badge: '',
    badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
    isExternalLink: false,
    submenu: []
  },
//   {
//     path: '/customers',
//     title: 'Customers',
//     icon: 'ft-users',
//     class: 'has-sub',
//     badge: '',
//     badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1',
//     isExternalLink: false,
//     submenu: [
//       { path: '/customer/customers', title: 'Customers', icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] }
//      ]}
     
    
            
];
