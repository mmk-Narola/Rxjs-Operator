import { Injectable } from '@angular/core';
import {BaseService} from './base.service';
import {ErrorHandlerService} from './error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CountryService {
countriesName:any
  constructor(private baseService:BaseService,
        private errorHandler: ErrorHandlerService,
        private http: HttpClient
    ) { }
/* this method will fetch all the countries */
    getAllCountries(){
      return this.http.get(this.baseService.baseUrl + 'admin/countries').pipe(
        catchError(this.errorHandler.handleError)
      )
    }
}
