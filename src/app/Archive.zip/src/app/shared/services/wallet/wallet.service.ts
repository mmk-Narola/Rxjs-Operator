import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { Subscription } from 'rxjs/internal/Subscription';
import { Observable, Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class WalletService {

  constructor(private baseService: BaseService,
    private http: HttpClient,
    private errorHandler: ErrorHandlerService) { }

  addNewTopUp(body) {
    return this.http.post(this.baseService.baseUrl + 'admin/topupScheme/', body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  customerWhoUseWallet(payType) {
    let url = "http://localhost:3000/api/v1/admin/customerWallet?type=Wallet"
    return this.http.get(this.baseService.baseUrl + `admin/customerWallet?type=${payType}`).pipe(
      //return this.http.get(url).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  walletAdjustment(id, body) {
    let url = "http://localhost:3000/api/v1/customer/" + id + '/wallet'
    return this.http.post(this.baseService.baseUrl + 'customer/' + id + '/wallet', body).pipe(
      // return this.http.post(url,body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  singleCustomerWhoUseWallet(id) {
    //let url = "http://localhost:3000/api/v1/admin/customerAllWallet/"+id
    return this.http.get(this.baseService.baseUrl + 'admin/customerAllWallet/' + id).pipe(
      //return this.http.get(url).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  getAllTopUpDetails() {
    return this.http.get(this.baseService.baseUrl + 'admin/topupScheme').pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  getSingleTopUpDetails(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/topupScheme/detail/' + id).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  updateTopUpDetails(id, body) {
    return this.http.patch(this.baseService.baseUrl + 'admin/topupScheme/' + id, body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  deleteExisitngTopuP(id) {
    return this.http.delete(this.baseService.baseUrl + '/admin/topupScheme/' + id).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  adjustCustomerReward(id, data) {
    return this.http.post(this.baseService.baseUrl + 'customer/' + id + '/reward', data).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
}
