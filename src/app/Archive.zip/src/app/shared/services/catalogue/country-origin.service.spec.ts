import { TestBed } from '@angular/core/testing';

import { CountryOriginService } from './country-origin.service';

describe('CountryOriginService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CountryOriginService = TestBed.get(CountryOriginService);
    expect(service).toBeTruthy();
  });
});
