import { Injectable } from '@angular/core';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
import { retry, catchError, takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class CountryOriginService {
  page: number = null;
  baseUrl: string;
  private _unsubscribe = new Subject<boolean>();
  countryIdMap = new Map();

  constructor(
    private baseService: BaseService,
    private errorHandler: ErrorHandlerService,
    private http: HttpClient,

  ) {
    this.baseUrl = this.baseService.baseUrl;

  }

  getAllCountryOrigins(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/countryOrigin', { params: params }
    ).pipe(catchError(this.errorHandler.handleError));
  }

  deleteCountryOrigin(id) {
    return this.http.delete(this.baseUrl + 'admin/countryOrigin/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllCountryOriginsDetails(id) {
    return this.http.get(this.baseUrl + 'admin/countryOrigin/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  addCountryOrigin(data) {
    return this.http.post(this.baseUrl + 'admin/countryOrigin', data).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  updateCountryOrigin(data) {
    return this.http.post(this.baseUrl + 'admin/countryOrigin', data).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  updateCountryStatus(statusData: { id: Number; adminStatus: Number }) {

    return this.http.post(this.baseUrl + 'admin/countryOrigin', statusData)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getCountryInfo() {
    const newArray = [];
    this.getAllCountryOrigins(this.page)
      .pipe(takeUntil(this._unsubscribe))
      .subscribe(
        (success: any) => {
          if (success.data != []) {
            success.data.results.forEach((element) => {
              newArray.push({
                countryName: element.countryName,
                id: element.id
              });
            }),
              newArray.forEach((element, index, array) => {
                this.countryIdMap.set(element.id, element.countryName);
              });
          }
        },
        (error) => { }
      );
  }
}
