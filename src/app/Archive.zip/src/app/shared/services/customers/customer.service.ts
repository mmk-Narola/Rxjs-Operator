import { Injectable } from '@angular/core';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  baseUrl: string;
  customerId: string;
  payType: string;

  constructor(
    private baseService: BaseService,
    private errorHandler: ErrorHandlerService,
    private http: HttpClient
  ) {
    this.baseUrl = this.baseService.baseUrl;

  }

  addCustomer(data) {
    let url = "http://localhost:3000/api/v1/"
    return this.http.post(this.baseUrl + 'admin/customer', data).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  addCustomerGroup(data) {

    return this.http.post(this.baseUrl + 'admin/customerGroup', data).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  updateCustomer(data) {

    return this.http.put(this.baseUrl + 'admin/customer', data).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  getAllCustomers(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/customer',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllCustomersSearch(page?, searchKey?, exportAll?, countryId?) {

    const params = { page: page, searchKey: searchKey, exportAll: exportAll, countryRegionId: countryId }
    return this.http.get(this.baseUrl + 'admin/customer',
      { params: params }).pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  getCustomerId(id) {

    return this.http.get(this.baseUrl + 'admin/getCustomerDetail/' + id).pipe(

      catchError(this.errorHandler.handleError)
    );
  }
  getCustomerGroupId(id) {

    return this.http.get(this.baseUrl + 'admin/getCustomerGroupDetail/' + id).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  getCustomerGroup(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/customerGroup',
      { params: params }).pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  getCustomerGroupParams(page?, searchKey?, exportAll?) {
    const params = { page: page, searchKey: searchKey, exportAll: exportAll }
    return this.http.get(this.baseUrl + 'admin/customerGroup',
      { params: params }).pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  deleteCustomer(id) {

    return this.http.delete(this.baseUrl + 'admin/customer/' + id)
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  deleteCustomerGroup(id) {
    return this.http.delete(this.baseUrl + 'admin/deleteGroup/' + id)
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  getAssignGroup() {

    return this.http.get(this.baseUrl + 'admin/getCustomerGroup')
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  updateCustomerStatus(statusData: { customerId: Number; adminStatus: Number }) {

    return this.http.put(this.baseUrl + 'admin/customerStatus', statusData)
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  getCountry() {
    // return this.http.get(`${this.baseService}web/countries`, { observe: 'response' })
    return this.http.get(this.baseUrl + 'web/countries', { observe: 'response' })
      .pipe(
        retry(3)
      );
  }

  getCountryInfo() {

    return this.http.get(this.baseUrl + 'admin/country')
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  getCountryCustomers(page?, countryId?) {

    const params = { page: page, countryRegionId: countryId }
    return this.http.get(this.baseUrl + 'admin/customer',
      { params: params }).pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  getCustomerDetail(id, type?, start_date?, end_date?) {
    const params = { type: type, start_date: start_date, end_date: end_date }
    return this.http.get(this.baseUrl + 'customer/' + id, { params: params }).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllCustomerDateSearch(page?, start_date?, end_date?, countryRegionId?) {
    const params = {
      page: page, start_date: start_date, end_date: end_date, countryRegionId: countryRegionId
    }
    return this.http.get(this.baseUrl + 'admin/customer',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getWalletHistory(id, walletType) {
    return this.http.get(this.baseUrl + 'exportCustomerWalletHistory/' + id + `?type=` + walletType).pipe(
      catchError(this.errorHandler.handleError)
    );
  }
}


