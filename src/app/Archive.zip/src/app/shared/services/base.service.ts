import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
const APIEndpoint = environment.APIEndpoint;

@Injectable({
  providedIn: 'root'
})
export class BaseService {

  // on production
  //public baseUrl = APIEndpoint;

  // on local

  // public baseUrl = 'http://175.41.182.101:5000/api/v1/';
  //public baseUrl = 'https://lumiere32.my/api/v1/';
  public baseUrl = 'http://192.168.100.11:5000/testapi/v1/';
  // public baseUrl = 'https://lumiere32.my/testapi/v1/';
  public exportBaseUrl = 'https://www.lumiere32.my/testapi'



  constructor(private httpClient: HttpClient,) { }

}

// 1. active 1
// inactive 0
