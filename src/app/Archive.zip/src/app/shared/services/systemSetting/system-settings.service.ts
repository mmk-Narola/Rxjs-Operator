import { Injectable } from '@angular/core';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SystemSettingsService { 
  baseUrl: string;

  constructor(    
    private baseService: BaseService,
    private errorHandler: ErrorHandlerService,
    private http: HttpClient
  ) {
    this.baseUrl = this.baseService.baseUrl;

  }

  addCountry(data) {
    
    return this.http.post(this.baseUrl + 'admin/countrySetting', data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }
  addCancel(data) {
    
    return this.http.post(this.baseUrl + 'admin/cancelReason', data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }
  updateCountry(data)
  {
    return this.http.post(this.baseUrl + 'admin/countrySetting', data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }

  getCountrydetails(id) {
    
    return this.http.get(this.baseUrl + 'admin/countrySetting/' + id)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }

  getSupplyTypedetails(id) {
    return this.http.get(this.baseUrl + 'admin/supplyType/' + id)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
  getAllSupplyType(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/supplyType',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }

  getAllCountries(page) {
    
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/countrySetting',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
  getAllCancel(page) {
    
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/cancelReason',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
  getCountry() 
  {
    
    return this.http.get(this.baseUrl + 'admin/countrySetting')
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }

  getAllCountriesSearch(page?, searchKey?) {
    
    const params = { page: page, searchKey: searchKey  }
    return this.http.get(this.baseUrl + 'admin/countrySetting', { params: params })
    .pipe(
      
      catchError(this.errorHandler.handleError)
    );
}  
getAllCancelSearch(page?, searchKey?) {
    
  const params = { page: page, searchKey: searchKey  }
  return this.http.get(this.baseUrl + 'admin/cancelReason', { params: params })
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
} 
addSupply(data) {
    return this.http.post(this.baseUrl + 'admin/supplyType', data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }
  getAllSupplysSearch(page?, searchKey?, countryId?) {
    
    const params = { page: page, searchKey: searchKey  ,countryId: countryId}
    return this.http.get(this.baseUrl + 'admin/supplyType',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
deleteCountry(id) {
  return this.http.delete(this.baseUrl + 'admin/countrySetting/' + id)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}

deleteCancel(id)
{ return this.http.delete(this.baseUrl + 'admin/cancelReason/' + id)
.pipe(
  
  catchError(this.errorHandler.handleError)
);

}
  deleteSupply(id) {
    return this.http.delete(this.baseUrl + 'admin/supplyType/' + id)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }

  
  updateCountryStatus(statusData: {id: Number; adminStatus: Number }){
    return this.http.put(this.baseUrl + 'admin/countrySetting', statusData)
    .pipe(
      
      catchError(this.errorHandler.handleError)
    );
}
updateCancelStatus(statusData: {id: Number; adminStatus: Number }){
  return this.http.put(this.baseUrl + 'admin/cancelReason', statusData)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}
getCancelDetails(id)
{
  return this.http.get(this.baseUrl + 'admin/cancelReason/' + id)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      ); 
}
  updateSellerStatus(statusData: {id: Number; adminStatus: Number }){
    
    return this.http.put(this.baseUrl + 'admin/supplyType', statusData)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
  updateSupply(data)
  {
    return this.http.post(this.baseUrl + 'admin/supplyType', data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }

  addEmails(data) {
    console.log(data)
    return this.http.post(this.baseUrl + 'admin/sentEmails', data).pipe(
     
      catchError(this.errorHandler.handleError)
    );
  }

  getEmails()
  {
    return this.http.get(this.baseUrl + 'admin/sentEmails')
      .pipe(
        
        catchError(this.errorHandler.handleError)
      );
    
  }
  getAllEmailSearch(page?, countryId?) {
    
    const params = { page: page, countryId: countryId}
    return this.http.get(this.baseUrl + 'admin/sentEmails',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }
  deleteEmail(id){ 
    console.log("in service");
    return this.http.delete(this.baseUrl + 'admin/sentEmails/' + id)
    .pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }
  getAllEmail(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/sentEmails',
      { params: params }).pipe(
        
        catchError(this.errorHandler.handleError)
      );
  }

  getAllEmaildetails(id) {
    console.log("reached")
    return this.http.get(this.baseUrl + 'admin/sentEmails/detail/' + id)
      .pipe(
        
        catchError(this.errorHandler.handleError)
      ); 
  }

  updateEmail(id, data)
  {
    return this.http.patch(this.baseUrl + 'admin/sentEmails/' + id, data).pipe(
      
      catchError(this.errorHandler.handleError)
    );
  }

}
