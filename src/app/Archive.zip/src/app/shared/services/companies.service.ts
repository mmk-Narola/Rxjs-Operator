import { Injectable } from '@angular/core';
import { ErrorHandlerService } from './error-handler.service';
import { map } from 'rxjs/operators';
import { BaseService } from './base.service';
import { HttpClient } from '@angular/common/http';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class CompaniesService {
    baseUrl: string;
    constructor(
        private errorHandler: ErrorHandlerService,
        private http: HttpClient,
        private baseSevice: BaseService
    ) {
        this.baseUrl = this.baseSevice.baseUrl;
    }

    // get all companies with paging
    getCompanies(page) {
        const params = { page: page }
        return this.http.get(this.baseUrl + 'companyList',
            { params: params }).pipe(
                
                catchError(this.errorHandler.handleError)
            );
    }

    // get all companies by search value with paging
    getAllCompaniesSearch(page, searchKey) {
        const params = { page: page, searchKey: searchKey }
        return this.http.get(this.baseUrl + 'companyList',
            { params: params }).pipe(
                
                catchError(this.errorHandler.handleError)
            );
    }
    // update category
    update(data, companyId) {
        return this.http.put(this.baseUrl + 'company/' + companyId, data).pipe(
            
            catchError(this.errorHandler.handleError)
        );
    }

    add(data) {
        return this.http.post(this.baseUrl + 'company', data).pipe(
            
            catchError(this.errorHandler.handleError)
        );
    }

    updateStatus(data) {
        return this.http.put(this.baseUrl + 'companyStatus/', data).pipe(
            
            catchError(this.errorHandler.handleError)
        );
    }
    
    importCsv(file) {
        const d = new FormData();
        d.append('company_file', file);
        return this.http.post(this.baseUrl + 'import-company/', d).pipe(
            
            catchError(this.errorHandler.handleError)
        );
    }
}
