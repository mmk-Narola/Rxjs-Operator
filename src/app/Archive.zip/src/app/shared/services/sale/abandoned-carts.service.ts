import { Injectable } from '@angular/core';
import { ErrorHandlerService } from '../error-handler.service';
import { HttpClient } from '@angular/common/http';
import { BaseService } from '../base.service';
import { retry, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AbandonedCartsService {
  baseUrl: string;
  constructor(
        private errorHandler: ErrorHandlerService,
        private http: HttpClient,
        private baseSevice: BaseService,
        private router: Router
  ) {  this.baseUrl = this.baseSevice.baseUrl; }

  abandonedCarts(){
    let url = 'https://lumiere32.my/testapi/v1/admin/abandoncart';
    return this.http.get(this.baseUrl + `admin/` + `abandoncart`).pipe(
            
      catchError(this.errorHandler.handleError)
  );
  }

  onViewcarts(id){
    let url = 'https://lumiere32.my/testapi/v1/admin/abandoncart/:customerId';
    return this.http.get(this.baseUrl + `admin/` + `abandoncart/` + id ).pipe(
            
      catchError(this.errorHandler.handleError)
  );
  }

  onConvertToOrder(id){
    let url = 'https://lumiere32.my/testapiv1/order/abandon-cart-order/:customerId';

    return this.http.post(this.baseUrl + `order/` + `abandon-cart-order/` + id, null).pipe(
            
      catchError(this.errorHandler.handleError)
  );
  }
}
