import { Injectable } from '@angular/core';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ViewUserRequestService {
  baseUrl: string;
  constructor(
    private baseService: BaseService,
    private errorHandler: ErrorHandlerService,
    private http: HttpClient
  ) {
    this.baseUrl = this.baseService.baseUrl;
  }
  getAllUserRequestSearch(page?, start_date?, end_date?) {
    const params = {
      page: page, start_date: start_date, end_date: end_date
    }
    return this.http.get(this.baseUrl + 'customer/userRequest',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllUserRequest(page) {

    const params = { page: page }
    return this.http.get(this.baseUrl + 'customer/userRequest',
      { params: params }).pipe(

        catchError(this.errorHandler.handleError)
      );
  }


}
