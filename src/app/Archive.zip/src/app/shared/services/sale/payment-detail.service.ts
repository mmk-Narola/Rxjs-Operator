import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { Subscription } from 'rxjs/internal/Subscription';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PaymentDetailService {
  invokeGetOrderDetails = new EventEmitter();
  subsVar: Subscription;

  private selectCustomerName = new BehaviorSubject({});
  selectedCustomer = this.selectCustomerName.asObservable();

  constructor(private baseService: BaseService,
    private http: HttpClient,
    private errorHandler: ErrorHandlerService) { }
  private subject = new Subject<any>();
  delieveryData: any;


  onOrderClick() {

    this.invokeGetOrderDetails.emit();
  }


  codAmount = 0;
  cod: any = {
    "chequeno": 0
  }

  finalDelType: any;
  payType: any;
  usrePaymentType: any
  bankDetailsFromDb: any
  modeOfPay: any;
  paySelectByUser: any;
  orderRecordTable: any;
  showDisplay: boolean = true;
  paymentType: any;
  editActive: boolean
  isActive: boolean;
  param: any
  paymentDetails = {};  // for payment details section 
  PaymentSettlement: any  // for payment settlement section will be use for modal for adding line
  paySettlementFieldArray: Array<any> = []; // payment settlement table array for storing rows added  or remove etc.
  /* billing address variables for both shipping and  billing */

  shippingAddress: any = {}
  billingAddress: any = {}
  orderDataService: any;
  /*this method will fetch all the tax related code and percentage from backend */
  taxDetailsData: any = {}
  productDataForTotal: any
  datas: any = {}
  fieldArray: Array<any> = [];
  productStatusArr: any
  productDetailArray: any
  walletData: any;
  paymentSettleArray: any = []
  OutRecord: any = []
  // this.paymentService.orderData.orderDetails.customerId
  orderData: any = {
    "orderDetails": {
      customerId: null
    }
  }

  ChangeCustomerName(message) {
    this.selectCustomerName.next(message);
  }

  getAllTaxDetail() {
    return this.http.get(this.baseService.baseUrl + 'admin/tax').pipe(
      catchError(this.errorHandler.handleError)
    );

  }
  /* calculate product total */
  calculateProductTotal() {
    let arr = []
    this.productDataForTotal.forEach((elem) => {
      arr.push(elem.total);
    })
    this.taxDetailsData.productTotal = arr.reduce((a, b) => {
      return a + b
    })
  }
  //https://www.lumiere32.my/testapi/v1/order/checkout?orderBy=admin&paymentType=admin
  /* create new order */
  insertNewOrder(body, siteType, promoId) {
    // let url = "http://localhost:3000/api/v1/admin/orders/insert-order/" // old 

    let url = "https://lumiere32.my/testapi/v1/order/checkout?orderBy=admin&paymentType=admin&promotionOffersId=166"


    return this.http.post(this.baseService.baseUrl + 'order/checkout' + `?orderBy=${siteType}&paymentType=admin&promotionOffersId=${promoId}`, body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  // Update payment method

  onUpdatePaymentMethod(body, id) {
    let url = "https://lumiere32.my/testapi/v1/order/pay-with-wallet/:orderId"
    return this.http.post(this.baseService.baseUrl + 'order/pay-with-wallet/' + id, body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  /* update back status order*/
  updateBackOrderStatus(body, id) {
    let url = "http://localhost:3000/api/v1/admin/order/update-backorder/"
    return this.http.post(this.baseService.baseUrl + 'admin/order/update-backorder/' + `?id=${id}`, body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  cancelOrderById(body, id) {
    let url = "http://localhost:3000/api/v1/admin/order/cancel-all-orders/"
    return this.http.post(this.baseService.baseUrl + 'admin/order/cancel-all-orders/' + `?id=${id}`, body).pipe(
      catchError(this.errorHandler.handleError)
    )

  }

  /* update existing order based on id */
  updateOrder(body, id) {
    let url = "http://localhost:3000/api/v1/admin/orders/update-order-products-status/"
    // return this.http.post(this.baseService.baseUrl + 'admin/orders/update-order-products-status/' + id, body).pipe(
    //   //  return this.http.post(url + id ,body).pipe(
    //   catchError(this.errorHandler.handleError)
    // )
    return this.http.put(this.baseService.baseUrl + 'order/checkout/' + id, body).pipe(
      //  return this.http.post(url + id ,body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  updateOrderForCouponChange(body, id, promotionOffersId) {
    const params = { promotionOffersId: promotionOffersId }
    let url = "http://localhost:3000/api/v1/admin/orders/update-order-products-status/"
    return this.http.put(this.baseService.baseUrl + 'order/checkout/' + id, body, { params: params }).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  updateCustomerDelieveryAddress(id, body) {
    let url = "http://localhost:3000/api/v1/order/"
    //return this.http.post(this.baseService.baseUrl + 'admin/orders/update-order-products-status/' + id ,body).pipe(
    return this.http.patch(this.baseService.baseUrl + 'order/' + id + '/address', body).pipe(
      catchError(this.errorHandler.handleError)
    )

  }
  /* update complete order status */
  updateCompleteOrderStatus(id, status, body) {
    let url = "http://localhost:3000/api/v1/admin/update-order/"
    //return this.http.post(this.baseService.baseUrl + 'admin/orders/update-order-products-status/' + id ,body).pipe(
    return this.http.post(url + `?id=${id}&status=${status}`, body).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  getAllOrders(page, limit, orderId, start_date, end_date, countryId) {
    let url = `http://localhost:3000/api/v1/admin/orders?page=${page}&limit=${limit}&orderId=${orderId}&start_date=${start_date}&end_date=${end_date}&countryId=${countryId}`
    // return this.http.get(url).pipe(
    return this.http.get(this.baseService.baseUrl + `admin/orders?page=${page}&limit=${limit}&orderId=${orderId}&start_date=${start_date}&end_date=${end_date}&countryId=${countryId}`).pipe(
      catchError(this.errorHandler.handleError)
    )

  }

  getOrderBasedOnUrl(id, start_date, end_date, countryId) {
    let url = "hhttp://localhost:3000/api/v1/admin/get-all?type=Delivered&start_date=2021-05-01&end_date=2021-07-21&countryId=2"
    // return this.http.get(url +'?type=' + id)
    return this.http.get(this.baseService.baseUrl + `admin/get-all?type=${id}&start_date=${start_date}&end_date=${end_date}&countryId=${countryId}`)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  cancelOrder(id, body) {
    let url = "http://localhost:3000/api/v1/admin/cancelorder/"
    //return this.http.post(url + id, body)
    return this.http.post(this.baseService.baseUrl + 'admin/cancelorder/' + id, body)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  outStockOrder(body) {
    let url = "http://localhost:3000/api/v1/admin/insert/out-of-stock"
    // return this.http.post(url , body)
    return this.http.post(this.baseService.baseUrl + 'admin/insert/out-of-stock', body)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  cancelDetails(id) {
    let url = "http://localhost:3000/api/v1/admin/cancel/"
    //return this.http.get(url + id)
    return this.http.get(this.baseService.baseUrl + 'admin/cancel/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  getSingleOrder(id) {
    let url = "http://localhost:3000/api/v1/admin/order/"
    //return this.http.get(url  + id).pipe(
    // return this.http.get(this.baseService.baseUrl + 'admin/order/' + id).pipe(
    //   catchError(this.errorHandler.handleError)
    // )
    return this.http.get(this.baseService.baseUrl + 'admin/orders/detail/' + id).pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  getSingleProductDetail(id) {
    let url = "http://localhost:3000/api/v1/admin/order/product-details/"
    // return this.http.get(url  + id).pipe(
    return this.http.get(this.baseService.baseUrl + 'admin/order/product-details/' + id).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  getSingleProductStatus() {
    let url = "http://localhost:3000/api/v1/admin/order-product/status"
    //return this.http.get(url).pipe(
    return this.http.get(this.baseService.baseUrl + 'admin/order-product/status').pipe(
      catchError(this.errorHandler.handleError)
    )
  }
  getDeliveryDetails(id) {
    // return this.http.get(this.baseService.baseUrl + 'admin/deliveryChargeDetail/' + id)
    return this.http.get(this.baseService.baseUrl + 'admin/deliveryChargeDetail/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }
  getModeOfPayment() {
    let url = "http://localhost:3000/api/v1/admin/payment"
    //return this.http.get(url)
    return this.http.get(this.baseService.baseUrl + 'admin/payment')
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }
  /* get all bank names */
  getAllBankNames() {
    let url = "http://localhost:3000/api/v1/admin/bank-details"
    // return this.http.get(url)
    return this.http.get(this.baseService.baseUrl + 'admin/bank-details')
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }
  /* check customer wallet */
  getWalletDetails(id) {
    let url = "http://localhost:3000/api/v1/customer/detail/"
    // return this.http.get(url + id)
    return this.http.get(this.baseService.baseUrl + 'customer/detail/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  getAllModeOfPayment() {
    let url = "http://localhost:3000/api/v1/admin/mode-of-payment"
    //return this.http.get(url)
    return this.http.get(this.baseService.baseUrl + 'admin/mode-of-payment')
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  getAllOutStockOrderProducts() {
    let url = "http://localhost:3000/api/v1/admin/get-out-stock-data"
    return this.http.get(this.baseService.baseUrl + 'admin/get-out-stock-data').pipe(
      // return this.http.get(url)
      //.pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  updateOutOrderBySeller(body) {
    let url = "http://localhost:3000/api/v1/admin/update-out-stock-data"
    return this.http.post(this.baseService.baseUrl + 'admin/update-out-stock-data', body).pipe(
      //return this.http.post(url,body)
      //.pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  deductWalletAmount(id, body) {
    let url = "http://localhost:3000/api/v1/customer/" + id + '/wallet'
    return this.http.post(this.baseService.baseUrl + 'customer/' + id + '/wallet', body).pipe(
      //return this.http.post(url,body)
      //.pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  validateSeller(id) {
    let url = "http://localhost:3000/api/v1/admin/seller/detail/"
    return this.http.get(this.baseService.baseUrl + 'admin/seller/detail/' + id).pipe(
      // return this.http.get(url + id)
      //.pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  applyCoupon(couponCode, total, customerId) {

    let url = "https://lumiere32.my/testapi/v1/applyPromotionOffers?code=Promo5&customerId=91&total=500";

    return this.http.get(this.baseService.baseUrl + `applyPromotionOffers?code=${couponCode}&customerId=${customerId}&total=${total}`).pipe(
      catchError(this.errorHandler.handleError)
    )
  }

  deleteOrder(id) {
    let url = "https://lumiere32.my/testapi/v1/order/delete/781";
    return this.http.delete(this.baseService.baseUrl + 'order/delete/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  invoiceOrder(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/invoice/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      )
  }

  getStateByPincode(countryId, pincode) {
    return this.http.get(this.baseService.baseUrl + 'web/getStateByPincode?countryId=' + countryId + '&postCode=' + pincode)
      .pipe(catchError(this.errorHandler.handleError))
  }

  calculateDeliveryCharge(reqPayload) {
    // http://localhost:5000/testapi/v1/admin/getDeliveryCharge
    return this.http.post(this.baseService.baseUrl + 'admin/getDeliveryCharge', reqPayload)
      .pipe(catchError(this.errorHandler.handleError))
  }

}
