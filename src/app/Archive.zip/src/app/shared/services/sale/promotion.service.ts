import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PromotionService {

  constructor(
    private baseService: BaseService,
    private http: HttpClient,
    private errorHandler: ErrorHandlerService
  ) { }
  promotionData: any = {}
  promotionDataPerIdForEdit: any;
  getAllPromotions(page) {
    const params = { page: page }
    return this.http.get(this.baseService.baseUrl + 'admin/promotionOffers', { params: params }).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllPromotionsPerId(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/promotionOffers/detail/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  addNewPromotion(body) {
    return this.http.post(this.baseService.baseUrl + 'admin/promotionOffers', body).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  updatePromotion(id, body) {
    return this.http.patch(this.baseService.baseUrl + 'admin/promotionOffers/' + id, body).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  deletePromotionData(id) {
    return this.http.delete(this.baseService.baseUrl + 'admin/promotionOffers/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllPromotionsDateSearch(page?, start_date?, end_date?) {
    const params = {
      page: page, start_date: start_date, end_date: end_date
    }
    return this.http.get(this.baseService.baseUrl + 'admin/promotionOffers',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  updatePageOffersStatus(statusData: { id: Number; adminStatus: Number }) {
    return this.http.put(this.baseService.baseUrl + 'admin/subscriptionPromotion', statusData)
      .pipe(catchError(this.errorHandler.handleError));
  }

  createDataForm(dataForm, data) {
    if (data.id != null) {
      dataForm.append('id', data['id']);
    }
    dataForm.append('image', data['image']);
    dataForm.append('countryId', data['countryId']);
    dataForm.append('name', data['name']);
    dataForm.append('description', data['description']);
    dataForm.append('subCategoryId', data['subCategoryId']);
    dataForm.append('sort_order', data['sort_order']);
    if (data['supplyTypeId'] != "" && data['supplyTypeId'] != null)
      dataForm.append('supplyTypeId', data['supplyTypeId']);
    dataForm.append('urlLink', data['urlLink']);
    dataForm.append('adminStatus', data['adminStatus']);
  }

  addpageOffers(data) {
    const dataForm = new FormData();
    this.createDataForm(dataForm, data)
    return this.http.post(this.baseService.baseUrl + 'admin/subscriptionPromotion', dataForm).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllPageOffersPerId(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/getSubscriptionPromotion?id=' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  updatePromotionalCategoryStatus(statusData: { id: Number; adminStatus: Number }) {
    return this.http.put(this.baseService.baseUrl + 'admin/subscriptionPromotionCategory', statusData)
      .pipe(catchError(this.errorHandler.handleError));
  }

  addpromotionalCategory(data) {
    return this.http.post(this.baseService.baseUrl + 'admin/subscriptionPromotionCategory', data).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getCategories() {
    return this.http.get(this.baseService.baseUrl + 'admin/getSubscriptionPromotionCategory').pipe(
      catchError(this.errorHandler.handleError));
  }

  getPromotionalCategoryPerId(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/getSubscriptionPromotionCategory?id=' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllPageOffers(searchKey?, countryId?) {
    const params = {
      searchKey: searchKey, countryId: countryId
    }
    return this.http.get(this.baseService.baseUrl + 'admin/getSubscriptionPromotion',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllPromotionalCategories(countryId?) {
    const params = {
      countryId: countryId
    }
    return this.http.get(this.baseService.baseUrl + 'admin/getSubscriptionPromotionCategory',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  deletePageOfferData(id) {
    return this.http.delete(this.baseService.baseUrl + 'admin/subscriptionPromotion/' + id).pipe(
      catchError(this.errorHandler.handleError));
  }

  deletePromotionalCategory(id) {
    return this.http.delete(this.baseService.baseUrl + 'admin/subscriptionPromotionCategory/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  createDataFormForSchemes(dataFormForScheme, data) {
    if (data.id != null) {
      dataFormForScheme.append('id', data['id']);
    }
    dataFormForScheme.append('image', data['image']);
    dataFormForScheme.append('countryId', data['countryId']);
    dataFormForScheme.append('schemeName', data['schemeName']);
    dataFormForScheme.append('description', data['description']);
    dataFormForScheme.append('pointRequired', data['pointRequired']);
  }

  getAllSchemes(countryId?) {
    const params = {
      countryId: countryId,
      page: null
    }
    return this.http.get(this.baseService.baseUrl + 'admin/rewardScheme',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllRewardsSchemesPerId(id) {
    return this.http.get(this.baseService.baseUrl + 'admin/rewardScheme/detail/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  addRewardSchemes(data) {
    const dataFormForScheme = new FormData();
    this.createDataFormForSchemes(dataFormForScheme, data)
    return this.http.post(this.baseService.baseUrl + 'admin/rewardScheme', dataFormForScheme).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  deleteRewardScheme(id) {
    return this.http.delete(this.baseService.baseUrl + 'admin/rewardScheme/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  updateRewardSchemeStatus(statusData: { id: Number; status: Number }) {
    return this.http.put(this.baseService.baseUrl + 'admin/rewardScheme', statusData)
      .pipe(catchError(this.errorHandler.handleError));
  }

  getAllUserRedemption(countryId?) {
    const params = {
      countryId: countryId,
      page: null
    }
    return this.http.get(this.baseService.baseUrl + 'admin/rewardRedemption',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  cancelRedemption(id) {
    return this.http.get(this.baseService.baseUrl + 'customer/cancelRewardRedemption/' + id).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  updateRedemptionsStatus(statusData: { id: Number; status: boolean }) {
    return this.http.put(this.baseService.baseUrl + 'admin/rewardRedemption', statusData)
      .pipe(catchError(this.errorHandler.handleError));
  }

}