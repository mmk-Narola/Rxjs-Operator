import { TestBed } from '@angular/core/testing';

import { AbandonedCartsService } from './abandoned-carts.service';

describe('AbandonedCartsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AbandonedCartsService = TestBed.get(AbandonedCartsService);
    expect(service).toBeTruthy();
  });
});
