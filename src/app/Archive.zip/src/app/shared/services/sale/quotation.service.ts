import { Injectable } from '@angular/core';
import { BaseService } from '../base.service';
import { ErrorHandlerService } from '../error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class QuotationService {
  baseUrl: string;
  constructor(
    private baseService: BaseService,
    private errorHandler: ErrorHandlerService,
    private http: HttpClient
  ) {
    this.baseUrl = this.baseService.baseUrl;
   }
   getAllProductsData(countryId){
    const params = {countryId: countryId}
    return this.http.get(this.baseUrl + 'admin/productListForOrder', { params: params }
  ).pipe(
      catchError(this.errorHandler.handleError)
    );
  }
   getAllquotationSearch(page?, searchKey?, quotationStatus?, countryId?,dateFrom?, dateTo?) 
  {
    const params = { page: page, searchKey: searchKey  ,countryId: countryId,quotationStatus: quotationStatus,dateFrom: dateFrom,dateTo: dateTo
     }
    return this.http.get(this.baseUrl + 'admin/quotation',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
}
getAllquotation(page) 
{
  
  const params = { page: page }
  return this.http.get(this.baseUrl + 'admin/quotation',
    { params: params }).pipe(
      
      catchError(this.errorHandler.handleError)
    );
}
getQuotationdetails(id) {
  return this.http.get(this.baseUrl + 'admin/quotation/' + id)
    .pipe(
      
      
      catchError(this.errorHandler.handleError)
    );
}
deleteQuotation(id) {
  return this.http.delete(this.baseUrl + 'admin/quotation/' + id)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}
updateproductStatus(statusData: {id: Number; quotationStatus: Number }){
  return this.http.put(this.baseUrl + 'admin/quotation', statusData)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}

printQoutation(id){
  let url = "https://www.lumiere32.my/testapi/v1/admin/quotationPdf/OTQ="
  return this.http.get(this.baseUrl + 'admin/quotationPdf/' + id).pipe(
    catchError(this.errorHandler.handleError)
  );
}

onSubmitAddQuotationForm(data)
{
  return this.http.post(this.baseUrl + 'admin/quotation', data)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}
onSubmitUpdateQuotationForm(data)
{
  return this.http.post(this.baseUrl + 'admin/quotation', data)
  .pipe(
    
    catchError(this.errorHandler.handleError)
  );
}
}
