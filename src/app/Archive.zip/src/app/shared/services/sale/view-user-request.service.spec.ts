import { TestBed } from '@angular/core/testing';

import { ViewUserRequestService } from './view-user-request.service';

describe('ViewUserRequestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewUserRequestService = TestBed.get(ViewUserRequestService);
    expect(service).toBeTruthy();
  });
});
