import { Injectable } from "@angular/core";
import { ErrorHandlerService } from "./error-handler.service";
import { HttpClient } from "@angular/common/http";
import { BaseService } from "./base.service";
import { Router } from "@angular/router";
import { catchError, takeUntil } from "rxjs/operators";
import { CustomerService } from "./customers/customer.service";
import { Subject } from "rxjs";
import { PaymentDetailService } from "./sale/payment-detail.service";

@Injectable({
  providedIn: "root",
})
export class CommonServiceService {
  baseUrl: string;
  relatedParams: any;
  isAlpha: boolean;
  arrayData: any = [];
  countryMapIsAlpha = new Map();
  countryMinLenMap = new Map();
  countryMaxLenMap = new Map();
  private _unsubscribe = new Subject<boolean>();
  billingPincodeValid: boolean = true;
  shippingPincodeValid: boolean = true;
  maxLength: number;
  selectedCountry: number;
  billingPincode: number;
  shippingPincode: number;
  minLength: number;
  billingStateStatus: boolean = false;
  shippingStateStatus: boolean = false
  billingBuildingNameStatus: boolean = false;
  shippingBuildingNameStatus: boolean = false;
  billingPincodeStatus: boolean = false;
  shippingPincodeStatus: boolean = false;
  billingClinicNameStatus: boolean = false;
  shippingClinicNameStatus: boolean = false;
  billingStateFlag: boolean = false;
  shippingStateFlag: boolean = false
  billingBuildingNameFlag: boolean = false;
  shippingBuildingNameFlag: boolean = false;
  billingPincodeFlag: boolean = false;
  shippingPincodeFlag: boolean = false;
  billingClinicNameFlag: boolean = false;
  shippingClinicNameFlag: boolean = false;
  countryEditable: boolean = true;
  countryEditableQuotation: boolean = true;
  cancelledOrder: boolean = false
  valueChanged: boolean = false;
  taxAdminStatus: boolean = true
  goToEditTax: boolean = false
  defaultTax: boolean = false
  newImage: boolean = false
  deliveryAdminStatus: boolean = true
  goToEditDelivery: boolean = false
  defaultDelivery: boolean = true

  constructor(
    private errorHandler: ErrorHandlerService,
    private http: HttpClient,
    private baseSevice: BaseService,
    private router: Router,
    private customerService: CustomerService,
    private paymentService: PaymentDetailService
  ) {
    this.baseUrl = this.baseSevice.baseUrl;
  }

  getCountry() {
    return this.http.get(this.baseUrl + 'admin/country')
      .pipe(

        catchError(this.errorHandler.handleError)
      );

  }
  getCountryOrigin() {
    return this.http.get(this.baseUrl + 'admin/getCountryOrigin')
      .pipe(

        catchError(this.errorHandler.handleError)
      );

  }
  getparentCategory(languageId, countryId) {
    const params = { languageId: languageId, countryId: countryId }
    return this.http.get(this.baseUrl + 'admin/parentCategoryList', { params: params })
      .pipe(

        catchError(this.errorHandler.handleError)
      );

  }

  getCategory(languageId, countryId) //
  {
    const params = { languageId: languageId, countryId: countryId } //
    return this.http.get(this.baseUrl + 'admin/categoryList', { params: params })
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }
  getRelatedProducts(languageId?, countryId?, searchKey?, relatedId?) {

    if (relatedId == undefined) {
      this.relatedParams = { languageId: languageId, countryId: countryId, searchKey: searchKey }
    }
    else {
      this.relatedParams = { languageId: languageId, countryId: countryId, searchKey: searchKey, relatedId: JSON.stringify(relatedId) }
    }
    console.log(relatedId)
    console.log("param", this.relatedParams)
    return this.http.get(this.baseUrl + 'admin/productList', { params: this.relatedParams })
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getSupplyType(country) {
    const params = { countryId: country }
    return this.http.get(this.baseUrl + 'admin/supplyTypeList',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getAllCountries() {
    return this.http.get(this.baseUrl + 'web/countries')
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getLanguage() {
    return this.http.get(this.baseUrl + 'admin/language').pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getCountryLanguage(country) {
    return this.http.get(this.baseUrl + 'admin/getCountryLanguage/' + country).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getCountryCurrency(country) {

    return this.http.get(this.baseUrl + 'admin/getCountryCurrency/' + country).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  getManufacturerList(country) {
    const params = { countryId: country }

    return this.http.get(this.baseUrl + 'admin/manufacturerList/', { params: params }).pipe(

      catchError(this.errorHandler.handleError)
    );
  }

  getSellerList(country) {

    const params = { countryId: country }

    return this.http.get(this.baseUrl + 'admin/sellerList/', { params: params }).pipe(

      catchError(this.errorHandler.handleError)
    );
  }
  getSeller() {


    return this.http.get(this.baseUrl + 'admin/sellerList').pipe(

      catchError(this.errorHandler.handleError)
    );
  }
  getCategoryList() {

    return this.http.get(this.baseUrl + 'admin/categoryList')
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  getCurrency() {
    return this.http.get(this.baseUrl + 'admin/currency').pipe(

      catchError(this.errorHandler.handleError)
    );
  }
  getSpeciality() {

    return this.http
      .get(this.baseUrl + 'customer/speciality')
      .pipe(

      );
  }

  getRole() {
    return this.http
      .get(this.baseUrl + "admin/role")
      .pipe(catchError(this.errorHandler.handleError));
  }

  // Populate maps based on country Id parameters 
  getCountryInfo() {
    const newArray = [];
    this.customerService
      .getCountryInfo()
      .pipe(takeUntil(this._unsubscribe))
      .subscribe(
        (success: any) => {
          if (success.data != []) {
            success.data.forEach((element) => {
              newArray.push({
                isAlpha: element.countries.isAlpha,
                id: element.id,
                max_length: element.countries.pncodeLength,
                min_length: element.countries.minpncodeLength,
              });
            }),
              newArray.forEach((element, index, array) => {
                this.countryMapIsAlpha.set(element.id, element.isAlpha);
                this.countryMaxLenMap.set(element.id, element.max_length);
                this.countryMinLenMap.set(element.id, element.min_length);
              });
          }
        },
        (error) => { }
      );
  }

  // Get parameters based on country Id
  getCountryParams(selectedCountryId: number) {
    this.isAlpha = this.countryMapIsAlpha.get(selectedCountryId);
    this.maxLength = this.countryMaxLenMap.get(selectedCountryId);
  }

  // Check billing address pincode value
  checkvalueBillingAdd(pincode, countryCode) {
    this.getCountryInfo();
    this.getMaxLength();
    this.maxLength = this.countryMaxLenMap.get(Number(countryCode));
    const isalphaPincode = this.countryMapIsAlpha.get(Number(countryCode))
    if ((pincode.toString().length > this.countryMaxLenMap.get(Number(countryCode)) || (pincode.toString().length < this.countryMinLenMap.get(Number(countryCode))) || (!isalphaPincode && !this.validateIsAlpha(pincode)))) {
      this.billingPincodeValid = false;
      this.selectedCountry = countryCode
    }
    else {
      this.billingPincodeValid = true;
      return true;
    }
  }

  // Check shipping address pincode value
  checkvalueShippingAdd(pincode, countryCode) {
    this.getCountryInfo();
    this.maxLength = this.countryMaxLenMap.get(Number(countryCode))
    this.getMaxLength();
    const isalphaPincode = this.countryMapIsAlpha.get(Number(countryCode))
    if ((pincode.toString().length > this.countryMaxLenMap.get(Number(countryCode)))
      || (pincode.toString().length < this.countryMinLenMap.get(Number(countryCode))) || (!isalphaPincode && !this.validateIsAlpha(pincode))) {
      this.shippingPincodeValid = false;
      this.selectedCountry = countryCode
    }

    else {
      this.shippingPincodeValid = true;
      return true;
    }
  }


  // To check if pincode is alphanumeric or not
  validateIsAlpha(pincode) {
    if (pincode.toString().match(/^[0-9]+$/))
      return true;
    else
      return false;
  }

  // To get the max length of pincode field based on Country Id
  getMaxLength() {
    return this.maxLength;
  }

  // To apply validations on empty fields
  checkIsEmptyFields(field) {
    if (field == "" || field == undefined) {
      return true;
    }
    else {
      return false;
    }
  }

  onNewOrder() {
    this.billingStateStatus = false
    this.billingPincodeStatus = false
    this.billingBuildingNameStatus = false
    this.billingPincodeValid = true
    this.shippingPincodeValid = true
    this.billingClinicNameStatus = false
    this.billingPincodeFlag = true
    this.shippingBuildingNameStatus = false
    this.shippingClinicNameStatus = false
    this.shippingPincodeStatus = false

    this.shippingStateStatus = false
    this.shippingPincodeFlag = false
    this.billingStateFlag = false;
    this.billingBuildingNameFlag = false;
    this.shippingStateFlag = false;
    this.shippingBuildingNameFlag = false;
    this.shippingClinicNameFlag = false;
    this.billingClinicNameFlag = false;
  }

  fieldValidations() {
    if (!this.checkIsEmptyFields(this.paymentService.billingAddress.billingPostcode)) {
      if (this.checkvalueBillingAdd(this.paymentService.billingAddress.billingPostcode, this.selectedCountry)) {
        this.billingPincodeFlag = true
        this.billingPincodeStatus = false;
      }
      else {
        this.billingPincodeFlag = false;
        this.billingPincodeStatus = false;
      }
    }
    else {
      this.billingPincodeStatus = true;
    }
    if (!this.checkIsEmptyFields(this.paymentService.shippingAddress.shippingPostcode)) {
      if (this.checkvalueShippingAdd(this.paymentService.shippingAddress.shippingPostcode, this.selectedCountry)) {
        this.shippingPincodeFlag = true
        this.shippingPincodeStatus = false;
      }
      else {
        this.shippingPincodeFlag = false;
        this.shippingPincodeStatus = false;
      }
    }
    else {
      this.shippingPincodeStatus = true;
    }
    if (this.checkIsEmptyFields(this.paymentService.billingAddress.billingState)) {
      this.billingStateStatus = true;
      this.billingStateFlag = false;
    }
    else {
      this.billingStateStatus = false;
      this.billingStateFlag = true;
    }
    if (this.checkIsEmptyFields(this.paymentService.billingAddress.billingBuildingName)) {
      this.billingBuildingNameFlag = false;
      this.billingBuildingNameStatus = true;
    }
    else {
      this.billingBuildingNameFlag = true;
      this.billingBuildingNameStatus = false;
    }
    if (this.checkIsEmptyFields(this.paymentService.shippingAddress.shippingState)) {
      this.shippingStateFlag = false;
      this.shippingStateStatus = true;
    }
    else {
      this.shippingStateFlag = true;
      this.shippingStateStatus = false;
    }
    if (this.checkIsEmptyFields(this.paymentService.shippingAddress.shippingBuildingName)) {
      this.shippingBuildingNameFlag = false;
      this.shippingBuildingNameStatus = true;
    }
    else {
      this.shippingBuildingNameFlag = true;
      this.shippingBuildingNameStatus = false;
    }
    if (this.checkIsEmptyFields(this.paymentService.billingAddress.billingClinicName)) {
      this.billingClinicNameFlag = false;
      this.billingClinicNameStatus = true;
    }
    else {
      this.billingClinicNameFlag = true;
      this.billingClinicNameStatus = false;
    }
    if (this.checkIsEmptyFields(this.paymentService.shippingAddress.shippingClinicName)) {
      this.shippingClinicNameFlag = false;
      this.shippingClinicNameStatus = true;
    }
    else {
      this.shippingClinicNameFlag = true;
      this.shippingClinicNameStatus = false;
    }
  }

  emptyFieldsCheck() {
    if (this.shippingBuildingNameFlag && this.shippingClinicNameFlag && this.shippingPincodeFlag && this.shippingStateFlag
      && this.billingPincodeFlag && this.billingStateFlag && this.billingBuildingNameFlag
      && this.billingClinicNameFlag)
      return true;
    else
      return false;
  }

  setIsDisabled() {
    if (this.countryEditableQuotation == false)
      return false
    else
      return true;
  }

  getCategoryForParentCategory(languageId, countryId, parentCategoryId) {
    const params = { languageId: languageId, countryId: countryId, parentCategoryId: parentCategoryId } //
    return this.http.get(this.baseUrl + 'admin/categoryList', { params: params })
      .pipe(

        catchError(this.errorHandler.handleError)
      );
  }

  getAllCronEmails(page) {
    const params = { page: page }
    return this.http.get(this.baseUrl + 'admin/cronAction', { params: params })
      .pipe(catchError(this.errorHandler.handleError)
      );
  }

  deleteCronEmail(id) {
    return this.http.delete(this.baseUrl + 'admin/cronAction/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  exportSellers(sellerId) {
    return this.http.get(this.baseUrl + 'seller/exportCSVProducts/' + sellerId)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  createDataForm(dataForm, data, id) {
    if (data.id != null) {
      dataForm.append('id', data['id']);
    }

    if ((data.file != "" && data['image'] != null && this.newImage) || (data.file != undefined && data['image'] != "" && this.newImage)) {
      dataForm.append('file', data['image']);
    }
    else if (!this.newImage && data['image'] == '' && data['image'].length != 0) {
      dataForm.append('image', '');
    }

    if (data.brochure != "" && data.brochure != null && data.brochure.length != 0) {
      dataForm.append('brochure', data['brochure']);
    }
    else {
      dataForm.append('brochure', '');
    }

    if (data['min_qty'] != '') {
      data['qty'] = data['min_qty'];
    }
    dataForm.append('name', data['name']);

    dataForm.append('price', data['price']);

    if (data['mrp'] != '' && data['mrp'] != null)
      dataForm.append('mrp', data['mrp']);

    dataForm.append('category', data['category']);

    if (data['min_qty'] != '')
      dataForm.append('min_qty', data['min_qty']);

    if (data['max_qty'] != '')
      dataForm.append('max_qty', data['max_qty']);

    dataForm.append('qty', data['min_qty']);

    dataForm.append('request_quote', data['request_quote']);

    if (data['sort_order'] != null && data['sort_order'].length != 0)
      dataForm.append('sort_order', data['sort_order']);

    if (data['warranty'] != null && data['warranty'].length != 0)
      dataForm.append('warranty', data['warranty']);
  }

  getMicroProductdetail(id) {
    return this.http.get(this.baseUrl + 'admin/oxygenMicrosite/detail/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  addMicroProduct(body) {
    const dataForm = new FormData();
    this.createDataForm(dataForm, body, undefined)
    return this.http.post(this.baseUrl + 'admin/oxygenMicrosite', dataForm).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  updateMicroProduct(id, body) {
    const dataForm = new FormData();
    this.createDataForm(dataForm, body, id)
    return this.http.post(this.baseUrl + 'admin/oxygenMicrosite', dataForm).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  getAllMicrositeProducts() {
    return this.http.get(this.baseUrl + 'admin/oxygenMicrosite')
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  deleteMicrositeProduct(id) {
    return this.http.delete(this.baseUrl + 'admin/oxygenMicrosite/' + id)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  updateMicroProductStatus(statusData: { id: Number; status: Number }) {
    return this.http.put(this.baseUrl + 'admin/oxygenMicrosite', statusData)
      .pipe(catchError(this.errorHandler.handleError));
  }

  getAllUploadedFiles(searchKey?) {
    const params = {
      searchKey: searchKey
    }
    return this.http.get(this.baseUrl + 'admin/uploadFile',
      { params: params }).pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  createDataFormForUpload(dataForm, data) {
    dataForm.append('file', data['file']);
    dataForm.append('name', data['name']);
  }

  uploadNewFile(data) {
    const dataForm = new FormData();
    this.createDataFormForUpload(dataForm, data)
    return this.http.post(this.baseUrl + 'admin/uploadFile', dataForm).pipe(
      catchError(this.errorHandler.handleError)
    );
  }

  removeFile(data: { file: string, id: string }) {
    return this.http.post(this.baseUrl + 'admin/removeFile', data)
      .pipe(
        catchError(this.errorHandler.handleError)
      );
  }

  getExportOrder(countryId) {
    const params = { countryId: countryId }
    return this.http.get(this.baseUrl + 'admin/exportOrders', { params: params })
      .pipe(catchError(this.errorHandler.handleError)
      );
  }
}
