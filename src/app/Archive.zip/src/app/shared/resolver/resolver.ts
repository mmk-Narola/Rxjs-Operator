import { Injectable } from '@angular/core';
import { Resolve,ActivatedRouteSnapshot,RouterStateSnapshot  } from '@angular/router';
import { Observable } from 'rxjs';
import {PaymentDetailService} from '../services/sale/payment-detail.service';
@Injectable()
export class Resolver implements Resolve<Observable<string>> {
  constructor(private api: PaymentDetailService) { }
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any>|Promise<any>|any {
      console.log("check",route.paramMap.get('id'))
    return this.api.getSingleOrder(route.paramMap.get('id'));
  }

}