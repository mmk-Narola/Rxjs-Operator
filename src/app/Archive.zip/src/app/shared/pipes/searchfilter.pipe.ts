import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {


  transform(data:any, searchvalue: string): any {
    
    if(!searchvalue){
      return data;
    }
    return data.filter(d=>
      d.billingClinicName.toLocaleLowerCase().includes(searchvalue.toLocaleLowerCase()) ||
      d.orderId.toString().toLocaleLowerCase().includes(searchvalue.toLocaleLowerCase())
      );
  }

}
