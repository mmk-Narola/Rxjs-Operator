import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from '../../../app/shared/services/base.service';
import { ErrorHandlerService } from '../../../app/shared/services/error-handler.service';
import { retry, catchError } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })

export class DashboardService{
    constructor(
    private baseService: BaseService,
    private http: HttpClient,
    private errorHandler: ErrorHandlerService
    ){

    }

    // get matrices details
    getDashboardMetrices(startDate, endDate, countryId){

      let url = "http://localhost:3000/api/v1/admin/dashboard?start_date=${start_date}&end_date=${end_date}";
        
      return this.http.get(this.baseService.baseUrl + `admin/dashboard?` + `start_date=${startDate}&end_date=${endDate}&countryId=${countryId}`).pipe(
            catchError(this.errorHandler.handleError)
          )

    }

    // get charts details
    getDashboardCharts(startDate, endDate, currentYear, countryId){

        let url = 'http://localhost:3000/api/v1/admin/dashboardChart?start_date=${start_date}&end_date=${end_date}&year=${current_year}&countryId=${countryId}'
        return this.http.get(this.baseService.baseUrl + `admin/dashboardChart` + `?start_date=${startDate}&end_date=${endDate}&year=${currentYear}&countryId=${countryId}`).pipe(
            catchError(this.errorHandler.handleError)
        )
    }
}