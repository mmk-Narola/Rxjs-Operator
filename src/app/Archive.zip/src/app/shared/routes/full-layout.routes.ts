import { Routes, RouterModule } from '@angular/router';
import {
  AuthGuardService as AuthGuard
} from '../../shared/services/auth/auth-guard.service';

// Route for content layout with sidebar, navbar and footer.

export const Full_ROUTES: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/dashboard/dashboard.module#DashboardModule'

    //loadChildren:  () => import('../../dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'sellerdashboard',
    loadChildren: 'app/sellerdashboard/sellerdashboard.module#SellerdashboardModule'

    //loadChildren:  () => import('../../dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  // // {
  // //   path: 'orders',
  // //   //loadChildren: './sale/sale.module#SaleModule'
  // //   loadChildren : ()=> import('../../sale/sale.module').then(m =>m.SaleModule)
  // // },
  // // {
  // //   path: 'orders',
  // //   loadChildren: './sale/sale.module#SaleModule'
  // // },
  {
    path: 'customer',
    loadChildren: 'app/customer/customer.module#CustomerModule',
    //loadChildren: () => import('../../customer/customer.module').then(m => m.CustomerModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'seller',
    loadChildren: 'app/seller/seller.module#SellerModule',
    //loadChildren: () => import('../../seller/seller.module').then(m => m.SellerModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'catalogues',
    loadChildren: 'app/catalogue/catalogue.module#CatalogueModule',
    //loadChildren: () => import('../../catalogue/catalogue.module').then(m => m.CatalogueModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'systemsetting',
    loadChildren: 'app/system-setting/system-setting.module#SystemSettingModule',
    //loadChildren: () => import('../../system-setting/system-setting.module').then(m => m.SystemSettingModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'user-permissions',
    loadChildren: 'app/users-permissions/users-permissions.module#UsersPermissionsModule',
    //loadChildren: () => import('../../users-permissions/users-permissions.module').then(m => m.UsersPermissionsModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'website-elements',
    loadChildren: 'app/website-elements/website-elements.module#WebsiteElementsModule',
    //loadChildren: () => import('../../website-elements/website-elements.module').then(m => m.WebsiteElementsModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'companies',
    loadChildren: 'app/companies/companies.module#CompaniesModule',
    //loadChildren: () => import('../../companies/companies.module').then(m => m.CompaniesModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'skill',
    loadChildren: 'app/skill/skill.module#SkillModule',
    //loadChildren: () => import('../../skill/skill.module').then(m => m.SkillModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'experience',
    loadChildren: 'app/experience/experience.module#ExperienceModule',

    //loadChildren: () => import('../../experience/experience.module').then(m => m.ExperienceModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'setting',
    loadChildren: 'app/setting/setting.module#SettingModule',
    //loadChildren: () => import('../../setting/setting.module').then(m => m.SettingModule),
    canActivate: [AuthGuard]

  },
  {
    path: 'event',
    loadChildren: 'app/event/event.module#EventModule',
    //loadChildren: () => import('../../event/event.module').then(m => m.EventModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'questions',
    loadChildren: 'app/questions/questions.module#QuestionsModule',
    //loadChildren: () => import('../../questions/questions.module').then(m => m.QuestionsModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'sale',
    // loadChildren: './questions/questions.module#QuestionsModule'
    loadChildren: 'app/sale/sale.module#SaleModule'
    //loadChildren: () => import('../../sale/sale.module').then(m => m.SaleModule ),

  },
  {
    path: 'pay',
    // loadChildren: './questions/questions.module#QuestionsModule'
    loadChildren: 'app/pay32/pay32.module#Pay32Module'
    //loadChildren: () => import('../../sale/sale.module').then(m => m.SaleModule ),

  },
  {
    path: 'seller/sellersale',
    // loadChildren: './questions/questions.module#QuestionsModule'
    loadChildren: 'app/sellersale/sellersale.module#SellersaleModule'
    //loadChildren: () => import('../../sale/sale.module').then(m => m.SaleModule ),

  },

  {
    path: 'seller/sellerproducts',
    // loadChildren: './questions/questions.module#QuestionsModule'
    loadChildren: 'app/sellerproducts/sellerproducts.module#SellerproductsModule'
    //loadChildren: () => import('../../sale/sale.module').then(m => m.SaleModule ),

  },
  {
    path: 'promotion',
    // loadChildren: './questions/questions.module#QuestionsModule'
    loadChildren: 'app/promotions/promotions.module#PromotionsModule',
    canActivate: [AuthGuard]

    //loadChildren: () => import('../../sale/sale.module').then(m => m.SaleModule ),

  },
  {
    path: 'email-logs',
    loadChildren: 'app/email-logs/email-logs.module#EmailLogsModule'
  },
  {
    path: 'microsite-products',
    loadChildren: 'app/microsite-products/microsite-products.module#MicrositeProductsModule'
  },
];
