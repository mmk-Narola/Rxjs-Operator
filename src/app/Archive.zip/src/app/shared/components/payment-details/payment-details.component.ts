import { Component, OnInit } from '@angular/core';
import {PaymentDetailService} from '../../services/sale/payment-detail.service';
import { Router,ActivatedRoute } from '@angular/router';
import {Tax} from '../tax.module';
@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.scss']
})
export class PaymentDetailsComponent implements OnInit {
data:any={}
fetchOrderDetails:any;
href:any;
tax = new Tax();


  constructor(public paymentService :PaymentDetailService 
    ,private router:Router,
    private route:ActivatedRoute,
    ) {
 
    // this.href = this.router.url;
    // console.log("url is", this.href);
    // if (this.href !== '/orders/new-order'){
    //     this.fetchOrderDetails= this.route.snapshot.data['order']
    //     console.log(this.fetchOrderDetails, "hua?")
        
    // }
   }
   changeDelieveryType(value){
     console.log("delievery value change",value)
     //console.log("delievery charge is,", this.paymentService.taxDetailsData.delieveryCharge)
     this.DATA.pop(this.paymentService.taxDetailsData.delieveryCharge)
     this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.total - parseFloat(this.paymentService.taxDetailsData.delieveryCharge)
      console.log("total amount is",this.paymentService.taxDetailsData.total)
 
     this.paymentService.delieveryData.some((elem)=>{
       if(elem.id == value){
         console.log(elem)
         this.DATA.push(elem.deliveryCharge);
         this.paymentService.taxDetailsData.delieveryCharge = elem.deliveryCharge
         this.paymentService.taxDetailsData.delieveryType = elem.title
         this.paymentService.finalDelType = elem.title
         this.paymentService.taxDetailsData.delieveryType = elem.id
       }
     })
     console.log(this.DATA, "data is")
     this.paymentService.taxDetailsData.delieveryCharge = this.DATA[0]
     this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.total + parseFloat(this.DATA[0])
     console.log(this.paymentService.taxDetailsData.delieveryCharge)
     console.log("total is ....",this.paymentService.taxDetailsData.total)

   }
   DATA:any = []
  ngOnInit() {
   Promise.all([this.getTaxDetails()])
    this.DATA.push(this.paymentService.taxDetailsData.delieveryCharge)
    console.log(this.DATA, "data is...")
  }
  taxData:any
  getTaxDetails(){
    this.paymentService.getAllTaxDetail().subscribe((response)=>{
      this.paymentService.taxDetailsData.taxCode = 5
      this.paymentService.taxDetailsData.taxpercent =10
      this.taxData = response;
      this.taxData = this.taxData.data.results
      console.log(this.taxData,"data")
      // this.paymentService.taxDetailsData = response;
      // this.paymentService.taxDetailsData = this.paymentService.taxDetailsData.data.results
      // console.log(this.paymentService.taxDetailsData, 'tax data')
    },(error)=>{
      console.log(error)
    })
  }

  taxChangeDetect(value){
    console.log(value, "this is value")
    this.taxData.some((elem)=>{
      if(elem.id == value){
        this.paymentService.taxDetailsData.taxpercent =  elem.taxRate    
        this.paymentService.taxDetailsData.taxCode = elem.id
      }
    })
    //this.paymentService.taxDetailsData.taxpercent=value.taxRate;
    //this.paymentService.taxDetailsData.taxCode =value.taxCode
    console.log(this.paymentService.taxDetailsData.taxAmount,'..........')
    console.log(this.paymentService.taxDetailsData.taxpercent,".sass")
    if (this.paymentService.taxDetailsData){
      console.log("entery");
      this.paymentService.taxDetailsData.taxAmount = this.paymentService.taxDetailsData.productTotal  * this.paymentService.taxDetailsData.taxpercent / 100
      this.paymentService.taxDetailsData.total = this.paymentService.taxDetailsData.taxAmount + this.paymentService.taxDetailsData.productTotal 
      console.log('......................',this.paymentService.taxDetailsData.taxAmount)
    }
  }
}
