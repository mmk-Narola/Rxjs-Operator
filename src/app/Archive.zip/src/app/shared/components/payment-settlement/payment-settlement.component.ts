import { Component, OnInit } from '@angular/core';
import { PaymentDetailService } from '../../../shared/services/sale/payment-detail.service';
import { Router, ActivatedRoute } from '@angular/router';
import { payment } from '../pay.model';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-payment-settlement',
  templateUrl: './payment-settlement.component.html',
  styleUrls: ['./payment-settlement.component.scss']
})
export class PaymentSettlementComponent implements OnInit {
  data = ['Payement Mode', 'Amount'];
  payment = new payment();
  dataarray = [];
  sub
  page
  constructor(public paymentService: PaymentDetailService,private toast:ToastrService,
    private route: ActivatedRoute,
    private router: Router
    ) {

    this.sub = this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      this.page = +params['order'] || 0;
      console.log(this.page,"page it is" ,typeof this.page)
    });
    if (this.page > 0 ){
      let methodOfPay = JSON.parse(localStorage.getItem('orderdata'))
      this.dataarray = [
        { modeOfPayment: 'card', amount: methodOfPay.walletPayment.card},
        { modeOfPayment: 'wallet', amount: methodOfPay.walletPayment.wallet }
      ]
    }
   }
  display = true;
  counter = 0;

  objectKeys: any
  ngOnInit() {
    console.log("this is payment section")
    this.getPaymentType()
    this.checkData()
  }
  checkMethod(value,i){
    
      console.log("check method",value);
      console.log("check method data array",this.dataarray);
  }
  checkAmount(value){
    console.log("check value",value)
    console.log("this data array",this.dataarray)
    this.dataarray.forEach((elem) => {
      if (elem.modeOfPayment === "card") {
        this.paymentService.orderData.walletPayment.card = parseFloat(elem.amount)
      } else if (elem.modeOfPayment === "wallet") {
        this.paymentService.orderData.walletPayment.wallet = parseFloat(elem.amount)
      } else if (elem.modeOfPayment == "cod") {
        this.paymentService.orderData.walletPayment.cod = parseFloat(elem.amount)
      }
    })
  }
  checkData() {
    if (this.paymentService.editActive == true) {
      this.dataarray = [
        { modeOfPayment: 'card', amount: this.paymentService.orderData.walletPayment.card },
        { modeOfPayment: 'wallet', amount: this.paymentService.orderData.walletPayment.wallet }
      ]
      console.log(this.dataarray, 'aaaaaaa')
    }
    // if (this.paymentService.editActive == false) {
    //   console.log("false status",this.dataarray)
    // if ( this.paymentService.taxDetailsData.total > this.paymentService.walletData ) {
    //   console.log("enter in comparison",this.modeOfPayment)
    //   this.dataarray = [
    //     { modeOfPayment: 'card', amount: this.paymentService.orderData.walletPayment.card }
    //   ]
  
    //  }
    // }
  }

  deleteFieldValue(index) {
    console.log(index,"index")
    this.paymentService.paySettlementFieldArray.splice(index, 1);
    this.counter = this.counter - 1;
    this.display = true;
  }

  modeOfPayment: any
  getPaymentType() {
    this.paymentService.getModeOfPayment()
      .subscribe((response) => {
        this.modeOfPayment = response
        this.modeOfPayment = this.modeOfPayment.response.result

        /* to do */
        /*
        paymentService.walletData  < total
          remove  wallet from dropdown
        */
       console.log(this.paymentService.taxDetailsData.total)
       console.log(this.paymentService.walletData)
       if ( this.paymentService.taxDetailsData.total > this.paymentService.walletData ) {
        // this.modeOfPayment = this.modeOfPayment.filter(o => o.typeOfPayment !== "wallet" )
         console.log("response", this.modeOfPayment)
        }
        
      })
  }


  addFieldHome() {
    if (this.dataarray.length == 0) {
      this.payment = new payment()
      this.dataarray.push(this.payment)
    }

    console.log("this home", this.dataarray)
    console.log(this.paymentService.taxDetailsData.total);
    if (this.paymentService.taxDetailsData.total > 0) {
      let remainBalance = null
      this.dataarray.forEach((elem) => {
       
        if (elem.modeOfPayment == "card") {
          console.log("enter card");
          remainBalance = this.paymentService.taxDetailsData.total - elem.amount
          if (remainBalance.toFixed(2) > 0 ){
            this.dataarray.push({ modeOfPayment: "wallet", amount: remainBalance.toFixed(2) })
          } 
          
        } 
        if (elem.modeOfPayment == "wallet") {
          console.log("enter wallet");
          remainBalance = this.paymentService.taxDetailsData.total - elem.amount
        
          if (remainBalance.toFixed(2) > 0 ){
            this.dataarray.push({ modeOfPayment: "card", amount: remainBalance.toFixed(2) })
          } 
          
        }  
      
      })
    }
   // this.paymentService.paymentSettleArray = this.dataarray;
    this.dataarray.forEach((elem) => {
      if (elem.modeOfPayment === "card") {
        this.paymentService.orderData.walletPayment.card = parseFloat(elem.amount)
      } else if (elem.modeOfPayment === "wallet") {
        this.paymentService.orderData.walletPayment.wallet = parseFloat(elem.amount)
      } else if (elem.modeOfPayment == "cod") {
        this.paymentService.orderData.walletPayment.cod = parseFloat(elem.amount)
      }
    })
  }
  removeHome(index) {
    console.log(index,"index is")
   
    this.dataarray.splice(index)
    this.dataarray.forEach((elem)=>{
      console.log(elem)
      if(elem.modeOfPayment == "card") {
        console.log('enter in card')
        this.paymentService.orderData.walletPayment.wallet = 0
      } else if (elem.modeOfPayment == "waller"){
        console.log('enter in wallet')
        this.paymentService.orderData.walletPayment.card = 0
      }
    })
    console.log("data array is",this.dataarray)
    this.paymentService.paymentSettleArray = this.dataarray;
  }

  checkCOD(value){
    console.log("value",value)
  }
  saveTrans() {
    console.log("pay data array", this.dataarray)
    let card = null
    let wallet = null
    let cod = null
    this.dataarray.forEach((elem) => {
      if (elem.modeOfPayment === "card") {
        card = parseInt(elem.amount)
        this.paymentService.orderData.walletPayment.card = card
      } else if (elem.modeOfPayment === "wallet") {
        wallet = parseInt(elem.amount)
        this.paymentService.orderData.walletPayment.wallet = wallet
      } else if (elem.modeOfPayment == "cod") {
        cod = parseInt(elem.amount)
        this.paymentService.orderData.walletPayment.cod = cod
      }
    })
  }

}
