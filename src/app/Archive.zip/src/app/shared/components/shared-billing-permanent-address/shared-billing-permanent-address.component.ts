import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { CommonServiceService } from '../../services/common-service.service';
import { PaymentDetailService } from '../../services/sale/payment-detail.service';
@Component({
  selector: 'app-shared-billing-permanent-address',
  templateUrl: './shared-billing-permanent-address.component.html',
  styleUrls: ['./shared-billing-permanent-address.component.scss']
})
export class SharedBillingPermanentAddressComponent implements OnInit, OnDestroy {

  data: any = {
    shippingAddress: {},
    billingAddress: {},
  }
  shippingStateList = [];
  shippingCityList = [];
  billingStateList = [];
  billingCityList = [];
  unsubscribe$: any;

  constructor(
    public service: PaymentDetailService,
    public commonService: CommonServiceService) {
    this.unsubscribe$ = this.service.selectedCustomer.subscribe(async (data) => {
      if (data && data['billingAdd']['pincode']) {
        await this.onBillingPincodeChange(data['billingAdd']['pincode'], true, data['billingAdd']['countryId']);
        this.service.billingAddress.billingState = data['billingAdd']['state'];
        if (this.service.billingAddress.billingState) {
          await this.changeBillingState(data['billingAdd']['state'], true);
          this.service.billingAddress.billingCity = data['billingAdd']['city'];
        }
      }
      if (data && data['delivaryAdd']['pincode']) {
        await this.onShippingPincodeChange(data['delivaryAdd']['pincode'], true, data['delivaryAdd']['countryId']);
        this.service.shippingAddress.shippingState = data['delivaryAdd']['state'];
        if (this.service.shippingAddress.shippingState) {
          await this.changeShippingState(data['delivaryAdd']['state'], true);
          this.service.shippingAddress.shippingCity = data['delivaryAdd']['city'];
        }
      }
    });
  }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    if (this.unsubscribe$) { this.unsubscribe$.unsubscribe(); }
  }

  isActive = false
  verifyLength = true

  /* check if address is similar or not */
  async addressSimilar(value) {
    this.isActive = value;
    this.service.isActive = value;
    if (value == true) {
      await this.onShippingPincodeChange(this.service.billingAddress.billingPostcode, true, null);
      await this.changeShippingState(this.service.billingAddress.billingState, true);

      this.service.shippingAddress.shippingClinicName = this.service.billingAddress.billingClinicName
      this.service.shippingAddress.shippingBuildingName = this.service.billingAddress.billingBuildingName
      this.service.shippingAddress.shippingBlockNo = this.service.billingAddress.billingBlockNo
      this.service.shippingAddress.shippingFloorNo = this.service.billingAddress.billingFloorNo
      this.service.shippingAddress.shippingUnitNo = this.service.billingAddress.billingUnitNo
      this.service.shippingAddress.shippingStreetName = this.service.billingAddress.billingStreetName
      this.service.shippingAddress.shippingPostcode = this.service.billingAddress.billingPostcode
      this.service.shippingAddress.shippingCountry = this.service.billingAddress.billingCountry
      this.service.shippingAddress.shippingState = this.service.billingAddress.billingState
      this.service.shippingAddress.shippingCity = this.service.billingAddress.billingCity

    } else if (value !== true) {
      this.service.shippingAddress = {};
    }
  }

  checkPincodeLength(pincode) {
    this.commonService.getCountryInfo();
    this.getMaxLength();
    this.verifyLength = (pincode.toString().length <= this.commonService.countryMaxLenMap.get(Number(this.commonService.selectedCountry))) ||
      (pincode.toString().length >= this.commonService.countryMinLenMap.get(Number(this.commonService.selectedCountry)))
  }

  validateBillingPincode(e) {
    this.checkPincodeLength(e)
    if (this.verifyLength)
      this.commonService.billingPincodeValid = true;
  }

  validateShippingPincode(e) {
    this.checkPincodeLength(e)
    if (this.verifyLength)
      this.commonService.shippingPincodeValid = true;
  }

  // Get max length of pincode field based on country id
  getMaxLength() {
    return this.commonService.countryMaxLenMap.get(Number(this.commonService.selectedCountry))
  }

  // Get min length of pincode field based on country id
  getMinLength(e) {
    if (e.toString().length >= this.commonService.countryMinLenMap.get(Number(this.commonService.selectedCountry))) {
      this.commonService.billingPincodeValid = true;
    }
  }

  onChange(event) {
    this.commonService.valueChanged = true
    if (this.service.billingAddress.billingPostcode) {
      this.onBillingPincodeChange(this.service.billingAddress.billingPostcode, true, null);
      if (this.service.billingAddress.billingState) {
        this.changeBillingState(this.service.billingAddress.billingState, true);
      }
    }
  }

  onBillingPincodeChange(event, isDefault, selectedCountry) {
    return new Promise((resolve, reject) => {
      const pincode = isDefault ? event : event.target.value;
      this.service.getStateByPincode((selectedCountry || this.commonService.selectedCountry), pincode).toPromise().then(res => {
        if (res && res['data'].length > 0) {
          this.billingStateList = res['data'];
        } else {
          this.billingStateList = [];
        }
        resolve(200);
      }).catch(err => { resolve(200); });
    });
  }

  onShippingPincodeChange(event, isDefault, selectedCountry) {
    return new Promise((resolve, reject) => {
      const pincode = isDefault ? event : event.target.value;
      this.service.getStateByPincode((selectedCountry || this.commonService.selectedCountry), pincode).toPromise().then(res => {
        if (res && res['data'].length > 0) {
          this.shippingStateList = res['data'];
        } else {
          this.shippingStateList = [];
        }
        resolve(200);
      }).catch(err => { resolve(200); });
    });
  }

  changeBillingState(event, isDefault) {
    this.billingCityList = [];
    const stateValue = isDefault ? event : event.target.value;
    if (stateValue) {
      this.service.billingAddress.billingState = stateValue;
      this.billingStateList.forEach(element => {
        if (element && element['title'] == stateValue) {
          this.billingCityList = element.cityList;
        }
      });
    } else {
      this.billingCityList = [];
    }
  }

  changeShippingState(event, isDefault) {
    return new Promise((resolve, reject) => {
      this.shippingCityList = [];
      const stateValue = isDefault ? event : event.target.value;
      if (stateValue) {
        this.service.shippingAddress.billingState = stateValue;
        this.shippingStateList.forEach(element => {
          if (element && element['title'] == stateValue) {
            this.shippingCityList = element.cityList;
            if (isDefault && this.shippingCityList.length > 0) {
              setTimeout(() => {
                this.service.shippingAddress['shippingCity'] = this.service.shippingAddress.shippingCity;
              }, 0);
            }
          }
        });
        resolve(200);
      } else {
        resolve(200);
        this.shippingCityList = [];
      }
    });
  }


}
