import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedBillingPermanentAddressComponent } from './shared-billing-permanent-address.component';

describe('SharedBillingPermanentAddressComponent', () => {
  let component: SharedBillingPermanentAddressComponent;
  let fixture: ComponentFixture<SharedBillingPermanentAddressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharedBillingPermanentAddressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedBillingPermanentAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
