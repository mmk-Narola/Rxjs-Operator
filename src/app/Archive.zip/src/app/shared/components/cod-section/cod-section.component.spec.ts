import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CodSectionComponent } from './cod-section.component';

describe('CodSectionComponent', () => {
  let component: CodSectionComponent;
  let fixture: ComponentFixture<CodSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CodSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CodSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
