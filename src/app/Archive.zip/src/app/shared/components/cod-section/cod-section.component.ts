import { Component, OnInit } from '@angular/core';
import {PaymentDetailService} from '../../services/sale/payment-detail.service';
@Component({
  selector: 'app-cod-section',
  templateUrl: './cod-section.component.html',
  styleUrls: ['./cod-section.component.scss']
})
export class CodSectionComponent implements OnInit {

  constructor(public service : PaymentDetailService) { }

  ngOnInit() {
    this.service.cod = null
  }

}
 