import { Component, OnInit } from '@angular/core';
import {PaymentDetailService} from '../../services/sale/payment-detail.service';
@Component({
  selector: 'app-order-record',
  templateUrl: './order-record.component.html',
  styleUrls: ['./order-record.component.scss']
})
export class OrderRecordComponent implements OnInit {

  constructor(public service : PaymentDetailService) { }

  ngOnInit() {
    console.log("record table",this.service.orderRecordTable);
  }

}
