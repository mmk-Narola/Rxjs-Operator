export class Tax {
    delieveryType:any;
    taxAmount:any;
    taxCode:any;
    total:any
}