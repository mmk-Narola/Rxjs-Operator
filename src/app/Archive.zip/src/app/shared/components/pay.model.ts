export class payment {
    amount:any;
    modeOfPayment:any;
}