export class PaymentSettlement{
    date:any;
    paymentMode:any;
    balance:any;
    amount:any;
}