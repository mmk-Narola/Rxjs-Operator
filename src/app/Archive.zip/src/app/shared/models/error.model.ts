export interface APIError {
  statusCode: number;
  message: string;
}
