# Lumiere32 - Admin Panel

Admin panel for Lumiere32

# Branch info

- Production Branch -> **main**
- Staging Branch -> **staging**


## Installation

- Clone the repo
- npm install
- ng serve

# URLs
- Malaysia Production -> [Link](https://lumiere32.my/admin/auth/login)
- Malaysia Staging -> [Link](https://adminstaging.lumiere32.my/auth/login)


# API Docs
[Swagger Link](http://175.41.182.101/api/admin-docs/)

## Technologies

Node - 10.16.0  
Angular - 7.0.2  
NPM - 6.9.0


## License

[MIT](https://choosealicense.com/licenses/mit/)
